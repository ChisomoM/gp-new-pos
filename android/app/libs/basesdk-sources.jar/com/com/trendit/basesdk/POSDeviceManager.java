package com.trendit.basesdk;

import android.app.Application;
import android.content.Context;
import android.util.Log;

import com.trendit.basesdk.device.beeper.BeeperDevice;
import com.trendit.basesdk.device.emv.EMVDevice;
import com.trendit.basesdk.device.hsm.HSMDevice;
import com.trendit.basesdk.device.led.LedDevice;
import com.trendit.basesdk.device.msr.MSRDevice;
import com.trendit.basesdk.device.pinpad.PINPadDevice;
import com.trendit.basesdk.device.printer.PrinterDevice;
import com.trendit.basesdk.device.psam.PSAMDevice;
import com.trendit.basesdk.device.picc.PICCCardDevice;
import com.trendit.basesdk.device.scanner.ScannerDevice;
import com.trendit.basesdk.device.icc.ICCCardDevice;
import com.trendit.basesdk.device.terminal.TerminalDevice;
import com.trendit.basesdk.device.serialport.SerialPortDevice;

import java.io.File;
import java.lang.reflect.Method;

import dalvik.system.DexClassLoader;

/**
 * Device Manager<b>POSDeviceManager</b> Is to obtain access to each device
 * <p>
 * The caller cannot create the object through new
 */
public abstract class POSDeviceManager {

    private static POSDeviceManager sInstance;

    /**
     * The path to the SDK implementation jar package.
     */
    private static final String LOAD_JAR_PATH = "/data/basesdk/basesdkimpl.jar";

    private static final String DEFAULT_IMPL_CLASSNAME = "com.trendit.basesdk_link.POSDeviceManagerImpl";

    private static Object getActivityThread() {
        Object activityThread = null;
        try {
            Method method = Class.forName("android.app.ActivityThread").getMethod("currentActivityThread");
            method.setAccessible(true);
            activityThread = method.invoke(null);
        } catch (final Exception e) {
            e.printStackTrace();
            Log.e("basesdk", "error to get currentActivityThread");
        }
        return activityThread;
    }

    private static Context getCurrentApplicationContext() {
        Object activityThread = getActivityThread();
        try {
            Object app = activityThread.getClass().getMethod("getApplication").invoke(activityThread);
            if (app == null || !(app instanceof Application)) {
                return null;
            }
            return ((Application) app).getApplicationContext();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * @return POS Device Manager instance
     */
    public static POSDeviceManager getInstance() {
        if (sInstance == null) {
            synchronized (POSDeviceManager.class) {
                try {
                    Object terminalObj;
                    Context context = getCurrentApplicationContext();
                    if (context == null) {
                        return null;
                    }
                    File dexOutputDir = context.getDir("dex", Context.MODE_PRIVATE);
                    DexClassLoader dexClassLoader = new DexClassLoader(LOAD_JAR_PATH, dexOutputDir.getAbsolutePath(), null, POSDeviceManager.class.getClassLoader());// success
                    Class<?> clazz = dexClassLoader.loadClass(DEFAULT_IMPL_CLASSNAME);
                    terminalObj = clazz.newInstance();
                    if (terminalObj instanceof POSDeviceManager) {
                        sInstance = (POSDeviceManager) terminalObj;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Log.e(POSDeviceManager.class.getSimpleName(), "can not find " + DEFAULT_IMPL_CLASSNAME + " form System ClassPath");
                }
            }
        }
        return sInstance;
    }

    /**
     * Get objects capable of operating with the secure chip device.
     * @return secure chip device
     * @see HSMDevice
     */
    public abstract HSMDevice getHSMDevice();

    /**
     * Get objects capable of operating with the buzzer device.
     * @return BeeperDevice
     * @see BeeperDevice
     */
    public abstract BeeperDevice getBeeperDevice();


    /**
     * Get objects related to the EMV (Europay, Mastercard, Visa) process.
     * @return EMVDevice
     * @see EMVDevice
     */
    public abstract EMVDevice getEmvDevice();


    /**
     * Get objects capable of operating with the LED (Light Emitting Diode) light device.
     * @return LedDevice
     * @see LedDevice
     */
    public abstract LedDevice getLedDevice();


    /**
     * Get objects capable of operating with the Mag (Magnetic) device.
     * @return MSRDevice
     * @see MSRDevice
     */
    public abstract MSRDevice getMsrDevice();


    /**
     * Get objects related to key operations.
     * @return PINPadDevice
     * @see PINPadDevice
     */
    public abstract PINPadDevice getPINPadDevice();


    /**
     * Get objects capable of operating with the printer device.
     * @return PrinterDevice
     * @see PrinterDevice
     */
    public abstract PrinterDevice getPrinterDevice();


    /**
     * Get objects capable of operating with the RF (Radio Frequency) card device.
     * @return PICCCardDevice
     * @see PICCCardDevice
     */
    public abstract PICCCardDevice getPICCCardDevice();


    /**
     * Get objects capable of operating with the IC card device.
     * @return ICCCardDevice
     * @see ICCCardDevice
     */
    public abstract ICCCardDevice getICCCardDevice();


    /**
     * Get objects related to barcode scanning operations.
     * @return ScannerDevice
     * @see ScannerDevice
     */
    public abstract ScannerDevice getScannerDevice();


    /**
     * Get objects capable of operating with terminal devices.
     * @return TerminalDevice
     * @see TerminalDevice
     */
    public abstract TerminalDevice getTerminalDevice();

    /**
     * Get objects capable of operating with the PSAM card device.
     * @return PSAMDevice
     * @see PSAMDevice
     */
    public abstract PSAMDevice getPSAMDevice();

    /**
     * Get objects related to serial port operations.
     * @return SerialPortDevice
     * @see SerialPortDevice
     */
    public abstract SerialPortDevice getSerialPortDevice();

}
