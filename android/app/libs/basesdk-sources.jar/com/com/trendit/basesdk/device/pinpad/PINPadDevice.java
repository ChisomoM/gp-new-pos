package com.trendit.basesdk.device.pinpad;

/**
 * <b>PINPadDevice</b>Define the interface for the PinPad operation.。
 * <pre>
 * PINPadDevice device = POSDeviceManager.getInstance().getPINPadDevice();
 * </pre>
 * The caller cannot create the object through new
 */
public abstract class PINPadDevice {

    /**
     * Write the terminal secure key
     *
     * @param keyAlgorithmType key algorithm type form {@link PINPadConstants#KEY_ALGORITHM_TYPE_DES_1} to {@link PINPadConstants#KEY_ALGORITHM_TYPE_AES_256}
     * @param keyType          the write key type form {@link PINPadConstants#KEY_TYPE_TLK} to {@link PINPadConstants#KEY_TYPE_TIK}
     * @param srcKeyIndex      source key index (The tlk key index can only be 0, and other key ranges are 0-9)
     * @param destKeyIndex     dest key index (The tlk key index can only be 0, and other key ranges are 0-9)
     * @param key              key data
     * @param checkMode        the mode of the check key. {@link PINPadConstants#CHECK_VALUE_MODE_NULL} to {@link PINPadConstants#CHECK_VALUE_MODE_AES_0}
     * @param checkValue       the check value when checkMode is {@link PINPadConstants#CHECK_VALUE_MODE_NULL}, the checkValue is null
     * @return Returns 0 as success, others as errors
     */
    public abstract int writeKey(int keyAlgorithmType, int keyType, int srcKeyIndex, int destKeyIndex, byte[] key, int checkMode, byte[] checkValue);

    /**
     * Write Dukpt key
     *
     * @param keyAlgorithmType key algorithm type form {@link PINPadConstants#KEY_ALGORITHM_TYPE_DES_1} to {@link PINPadConstants#KEY_ALGORITHM_TYPE_AES_256}
     * @param tlkIndex         source TLK index (can only be 0)
     * @param dukptIndex       Dukpt key index (0-9)
     * @param ksn              Dukpt key serial number
     * @param dukpt            Dukpt key
     * @param checkMode        the mode of the check key. {@link PINPadConstants#CHECK_VALUE_MODE_DUKPT_DES_0} to {@link PINPadConstants#CHECK_VALUE_MODE_DUKPT_AES_0}
     * @param checkValue       the check value
     * @return Returns 0 as success, others as errors
     */
    public abstract int writeDukptKey(int keyAlgorithmType, int tlkIndex, int dukptIndex, byte[] ksn, byte[] dukpt, int checkMode, byte[] checkValue);

    /**
     * encrypt data by TDK
     *
     * @param keyAlgorithmType key algorithm type form {@link PINPadConstants#KEY_ALGORITHM_TYPE_DES_1} to {@link PINPadConstants#KEY_ALGORITHM_TYPE_AES_256}
     * @param tdkIndex         TDK index {@link PINPadConstants#KEY_TYPE_TDK} (0-9)
     * @param data             Data that requires encryption
     * @return Encrypted data
     */
    public abstract byte[] encrypt(int keyAlgorithmType, int tdkIndex, byte[] data);

    /**
     * encrypt data
     *
     * @param keyAlgorithmType key algorithm type form {@link PINPadConstants#KEY_ALGORITHM_TYPE_DES_1} to {@link PINPadConstants#KEY_ALGORITHM_TYPE_AES_256}
     * @param keyType          key type form {@link PINPadConstants#KEY_TYPE_TLK} to {@link PINPadConstants#KEY_TYPE_TDK}
     * @param keyIndex         key index (0-9)
     * @param data             Data that requires encryption
     * @return Encrypted data
     */
    public abstract byte[] encrypt(int keyAlgorithmType, int keyType, int keyIndex, byte[] data);

    /**
     * encrypt data by dukpt key
     *
     * @param keyAlgorithmType key algorithm type form {@link PINPadConstants#KEY_ALGORITHM_TYPE_DES_1} to {@link PINPadConstants#KEY_ALGORITHM_TYPE_AES_256}
     * @param tikIndex         TIK index {@link PINPadConstants#KEY_TYPE_TIK} (0-9)
     * @param deriveType       derive type only aes dukpt key need to use {@link PINPadConstants#DUKPT_AES_DERIVE_KEY_TYPE_DES2} to {@link PINPadConstants#DUKPT_AES_DERIVE_KEY_TYPE_AES256}
     * @param usage            {@link PINPadConstants#DUKPT_AES_USAGE_Key_Encryption_Key} to {@link PINPadConstants#DUKPT_AES_USAGE_Key_Derivation_Initial_Key} or {@link PINPadConstants#DUKPT_DES_USAGE_PIN_Encryption} to {@link PINPadConstants#DUKPT_DES_USAGE_Data_Encryption_encrypt}
     * @param data             Data that requires encryption
     * @return Encrypted data
     */
    public abstract DukptCalcInfo encryptDukpt(int keyAlgorithmType, int tikIndex, int deriveType, int usage, byte[] data);

    /**
     * decrypt data by TDK
     *
     * @param keyAlgorithmType key algorithm type form {@link PINPadConstants#KEY_ALGORITHM_TYPE_DES_1} to {@link PINPadConstants#KEY_ALGORITHM_TYPE_AES_256}
     * @param tdkIndex         TDK index {@link PINPadConstants#KEY_TYPE_TDK} (0-9)
     * @param data             Data that needs to be decrypted
     * @return Decrypted data
     */
    public abstract byte[] decrypt(int keyAlgorithmType, int tdkIndex, byte[] data);

    /**
     * decrypt data
     *
     * @param keyAlgorithmType key algorithm type form {@link PINPadConstants#KEY_ALGORITHM_TYPE_DES_1} to {@link PINPadConstants#KEY_ALGORITHM_TYPE_AES_256}
     * @param keyType          key type form {@link PINPadConstants#KEY_TYPE_TLK} to {@link PINPadConstants#KEY_TYPE_TDK}
     * @param keyIndex         key index (0-9)
     * @param data             Data that needs to be decrypted
     * @return Decrypted data
     */
    public abstract byte[] decrypt(int keyAlgorithmType, int keyType, int keyIndex, byte[] data);

    /**
     * decrypt data by dukpt key
     *
     * @param keyAlgorithmType key algorithm type form {@link PINPadConstants#KEY_ALGORITHM_TYPE_DES_1} to {@link PINPadConstants#KEY_ALGORITHM_TYPE_AES_256}
     * @param tikIndex         TIK index {@link PINPadConstants#KEY_TYPE_TIK} (0-9)
     * @param deriveType       derive type only aes dukpt key need to use {@link PINPadConstants#DUKPT_AES_DERIVE_KEY_TYPE_DES2} to {@link PINPadConstants#DUKPT_AES_DERIVE_KEY_TYPE_AES256}
     * @param usage            {@link PINPadConstants#DUKPT_AES_USAGE_Key_Encryption_Key} to {@link PINPadConstants#DUKPT_AES_USAGE_Key_Derivation_Initial_Key} or {@link PINPadConstants#DUKPT_DES_USAGE_PIN_Encryption} to {@link PINPadConstants#DUKPT_DES_USAGE_Data_Encryption_encrypt}
     * @param data             data Data that needs to be decrypted
     * @return Decrypted data
     */
    public abstract DukptCalcInfo decryptDukpt(int keyAlgorithmType, int tikIndex, int deriveType, int usage, byte[] data);

    /**
     * calc mac
     *
     * @param keyAlgorithmType key algorithm type form {@link PINPadConstants#KEY_ALGORITHM_TYPE_DES_1} to {@link PINPadConstants#KEY_ALGORITHM_TYPE_AES_256}
     * @param takIndex         TAK index {@link PINPadConstants#KEY_TYPE_TAK} (0-9)
     * @param macMode          the mode of calc mac {@link PINPadConstants#MAC_MODE_X99} to {@link PINPadConstants#MAC_MODE_AES_ECB}
     * @param data             Data that requires to calc mac
     * @return mac
     */
    public abstract byte[] getMac(int keyAlgorithmType, int takIndex, int macMode, byte[] data);

    /**
     * calc mac by dukpt key
     *
     * @param keyAlgorithmType key algorithm type form {@link PINPadConstants#KEY_ALGORITHM_TYPE_DES_1} to {@link PINPadConstants#KEY_ALGORITHM_TYPE_AES_256}
     * @param tikIndex         TIK index {@link PINPadConstants#KEY_TYPE_TIK} (0-9)
     * @param macMode          the mode of calc mac {@link PINPadConstants#MAC_MODE_X99} to {@link PINPadConstants#MAC_MODE_AES_ECB}
     * @param deriveType       derive type only aes dukpt key need to use {@link PINPadConstants#DUKPT_AES_DERIVE_KEY_TYPE_DES2} to {@link PINPadConstants#DUKPT_AES_DERIVE_KEY_TYPE_AES256}
     * @param usage            {@link PINPadConstants#DUKPT_AES_USAGE_Key_Encryption_Key} to {@link PINPadConstants#DUKPT_AES_USAGE_Key_Derivation_Initial_Key} or {@link PINPadConstants#DUKPT_DES_USAGE_PIN_Encryption} to {@link PINPadConstants#DUKPT_DES_USAGE_Data_Encryption_encrypt}
     * @param data             Data that requires to calc mac
     * @return mac data
     */
    public abstract DukptCalcInfo getMacDukpt(int keyAlgorithmType, int tikIndex, int macMode, int deriveType, int usage, byte[] data);

    /**
     * calc pinblock
     *
     * @param keyAlgorithmType key algorithm type form {@link PINPadConstants#KEY_ALGORITHM_TYPE_DES_1} to {@link PINPadConstants#KEY_ALGORITHM_TYPE_AES_256}
     * @param tpkIndex         TPK index {@link PINPadConstants#KEY_TYPE_TPK} (0-9)
     * @param pinMode          calc pinBlock mode {@link PINPadConstants#PINBLOCK_MODE_ISO_9564_0} to {@link PINPadConstants#PINBLOCK_MODE_ISO_9564_4}
     * @param data             PANBLOCK. Refer to the way of calculating PAN when PIN encryption algorithm of different formats is used.
     * @return pinblock
     */
    public abstract byte[] getPinBloclk(int keyAlgorithmType, int tpkIndex, int pinMode, byte[] data);

    /**
     * calc pinblock by dukpt key
     *
     * @param keyAlgorithmType key algorithm type form {@link PINPadConstants#KEY_ALGORITHM_TYPE_DES_1} to {@link PINPadConstants#KEY_ALGORITHM_TYPE_AES_256}
     * @param tikIndex         TIK index {@link PINPadConstants#KEY_TYPE_TIK} (0-9)
     * @param pinMode          calc pinBlock mode {@link PINPadConstants#PINBLOCK_MODE_ISO_9564_0} to {@link PINPadConstants#PINBLOCK_MODE_ISO_9564_4}
     * @param deriveType       derive type only aes dukpt key need to use {@link PINPadConstants#DUKPT_AES_DERIVE_KEY_TYPE_DES2} to {@link PINPadConstants#DUKPT_AES_DERIVE_KEY_TYPE_AES256}
     * @param data             PANBLOCK. Refer to the way of calculating PAN when PIN encryption algorithm of different formats is used.
     * @return pinblock
     */
    public abstract DukptCalcInfo getPinBlockDukpt(int keyAlgorithmType, int tikIndex, int pinMode, int deriveType, byte[] data);

    /**
     * Obtain the KCV value of the key for key verification by both sides of the conversation, encrypt a piece of data with the specified key and the algorithm, and return part of the data ciphertext.
     *
     * @param keyAlgorithmType key algorithm type form {@link PINPadConstants#KEY_ALGORITHM_TYPE_DES_1} to {@link PINPadConstants#KEY_ALGORITHM_TYPE_AES_256}
     * @param keyType          key type form {@link PINPadConstants#KEY_TYPE_TLK} to {@link PINPadConstants#KEY_TYPE_TIK}
     * @param keyIndex         key index (0-9)
     * @return part of the data ciphertext. The key performs DES encryption on 0 of 8 bytes, and the first 4 bytes of the generated ciphertext are KCV. or The key uses this key to perform AES encryption on 0 of 16 bytes, and the first 4 bytes of the generated ciphertext are KCV.
     */
    public abstract byte[] getCheckValue(int keyAlgorithmType, int keyType, int keyIndex);

    /**
     * Obtain the KCV value of the key for key verification by both sides of the conversation, encrypt a piece of data with the specified key and the algorithm, and return part of the data ciphertext.
     *
     * @param keyAlgorithmType key algorithm type form {@link PINPadConstants#KEY_ALGORITHM_TYPE_DES_1} to {@link PINPadConstants#KEY_ALGORITHM_TYPE_AES_256}
     * @param dukptIndex       dukpt key index(0-9)
     * @return part of the data ciphertext. The key performs DES encryption on 0 of 8 bytes, and the first 4 bytes of the generated ciphertext are KCV. or The key uses this key to perform AES encryption on 0 of 16 bytes, and the first 4 bytes of the generated ciphertext are KCV.
     */
    public abstract byte[] getCheckValueDukpt(int keyAlgorithmType, int dukptIndex);

    /**
     * When using AES DUKPT, each time you start a transaction you have to first disperse the key associated with this transaction.
     *
     * @param keyAlgorithmType key algorithm type form {@link PINPadConstants#KEY_ALGORITHM_TYPE_DES_1} to {@link PINPadConstants#KEY_ALGORITHM_TYPE_AES_256}
     * @param tikIndex         TIK index {@link PINPadConstants#KEY_TYPE_TIK}(0-9)
     * @return Returns 0 as success, others as errors
     */
    public abstract int regenDukptKey(int keyAlgorithmType, int tikIndex);

    /**
     * Start the process of obtaining pinBlock, which includes entering a password（Use the default password input View）
     *
     * @param build    Some parameters required for calculating pinblock
     * @param listener Callback when entering passwords
     * @param timeout  timeout (millisecond)
     */
    public abstract void listenForPinBlock(PinBlockBuildInfo build, final OnPinPadEventListener listener, int timeout);

    /**
     * Enter password input mode, which is required for customizing the password keyboard，At the end, {@link #exitPinInputMode()} needs to be called, otherwise the touch screen will not be usable
     *
     * @param keyAlgorithmType key algorithm type form {@link PINPadConstants#KEY_ALGORITHM_TYPE_DES_1} to {@link PINPadConstants#KEY_ALGORITHM_TYPE_AES_256}
     * @param isDukptKey       Is it a dukpt secret key
     * @param keyIndex         key index (0-9)
     * @param calcMode         pinBlock mode  {@link PINPadConstants#PINBLOCK_MODE_ISO_9564_0} to {@link PINPadConstants#PINBLOCK_MODE_ISO_9564_4}
     * @param minInputLen      min input password len
     * @param maxInputLen      max input password len
     * @param enableByPass     enable to pass input password
     * @param timeout          timeout (millisecond)
     * @return Returns 0 as success, others as errors
     */
    public abstract int enterPinInputMode(int keyAlgorithmType, boolean isDukptKey, int keyIndex, int calcMode, int minInputLen, int maxInputLen, boolean enableByPass, int timeout);

    /**
     * Exit the password input mode, which is required for customizing the password keyboard. If you do not exit, the touch screen will not be able to be used
     *
     * @return Returns 0 as success, others as errors
     */
    public abstract int exitPinInputMode();

    /**
     * Obtain password keyboard random number
     * the randoms show view layout as follows
     * NUM0(randoms[0])     NUM1(randoms[1])    NUM2(randoms[2])
     * NUM3(randoms[3])     NUM4(randoms[4])    NUM5(randoms[5])
     * NUM7(randoms[6])     NUM8(randoms[7])    NUM8(randoms[8])
     * ESC KEY              NUM9(randoms[9])    CONFIRM KEY
     *
     * @return Random numbers displayed on the keyboard
     */
    public abstract byte[] getKeyBoardRandoms();

    /**
     * Set custom password keyboard location information
     *
     * @param position location information
     * @return Returns 0 as success, others as errors
     */
    public abstract int setKeyBoardInfo(KeyboardPosition position);

    /**
     * Clear the input password data cache and call this interface before starting password input
     */
    public abstract void clearKeyValueCaches();

    /**
     * Obtain the current input key value
     *
     * @return key value {@link PINPadConstants#KEYCODE_NULL} to {@link PINPadConstants#KEYCODE_BY_PASS_PIN}
     */
    public abstract int getPinKeyValue();

}
