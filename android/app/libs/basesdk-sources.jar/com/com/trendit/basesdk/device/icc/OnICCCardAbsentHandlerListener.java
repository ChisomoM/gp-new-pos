package com.trendit.basesdk.device.icc;

/**
 * IC card remove card callback
 */
public abstract class OnICCCardAbsentHandlerListener {
    /**
     * Call back this interface when card search is successful or error occurs
     *
     * @param retCode card check result {@link com.trendit.basesdk.card.CardConstants#RESULT_SUCCESS} to {@link com.trendit.basesdk.card.CardConstants#RESULT_ERR_READFAIL}
     */
    public abstract void handleCardReaderResult(int retCode);

}
