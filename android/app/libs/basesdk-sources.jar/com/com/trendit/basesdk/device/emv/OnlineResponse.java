package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * relative data for contacting card second GAC or paywave IUP processing
 */
public class OnlineResponse extends BaseParcelable implements Parcelable {

    /**
     * Authorization response code, 2 bytes.Set RspCode[0] as 0 in case of online failed.
     */
    @FieldNumber(1)
    private byte[] rspCode;
    /**
     * Authorization code，6 bytes, Set it as null when there is no AuthCode.
     */
    @FieldNumber(2)
    private byte[] authCode;
    /**
     * Issuer authentication data returned from host.Set it as null when there is no IAuthData
     */
    @FieldNumber(3)
    private byte[] authData;
    /**
     * Issuer 71 script.Set it as null when there is no 71 script.
     */
    @FieldNumber(4)
    private byte[] script71;
    /**
     * Issuer 72 script.Set it as null when there is no 72 script.
     */
    @FieldNumber(5)
    private byte[] script72;

    /**
     * Get the Authorization response code
     *
     * @return response code
     */
    public byte[] getRspCode() {
        return rspCode;
    }

    /**
     * Set the Authorization response code, 2 bytes. Set RspCode[0] as 0 in case of online failed.
     *
     * @param rspCode response code
     */
    public void setRspCode(byte[] rspCode) {
        this.rspCode = rspCode;
    }

    /**
     * Get the Authorization code
     *
     * @return Authorization code
     */
    public byte[] getAuthCode() {
        return authCode;
    }

    /**
     * Set the Authorization code 6 bytes, Set it as null when there is no AuthCode.
     *
     * @param authCode Authorization code
     */
    public void setAuthCode(byte[] authCode) {
        this.authCode = authCode;
    }

    /**
     * Get the Issuer authentication data returned from host.
     *
     * @return Issuer authentication data
     */
    public byte[] getAuthData() {
        return authData;
    }

    /**
     * Set the Issuer authentication data returned from host, Set it as null when there is no IAuthData.
     *
     * @param authData Issuer authentication data
     */
    public void setAuthData(byte[] authData) {
        this.authData = authData;
    }

    /**
     * Get the Issuer 71 script.
     *
     * @return Issuer 71 script.
     */
    public byte[] getScript71() {
        return script71;
    }

    /**
     * Set the Issuer 71 script.Set it as null when there is no 71 script.
     *
     * @param script71 Issuer 71 script.
     */
    public void setScript71(byte[] script71) {
        this.script71 = script71;
    }

    /**
     * Get the Issuer 72 script.
     *
     * @return Issuer 72 script.
     */
    public byte[] getScript72() {
        return script72;
    }

    /**
     * Set the Issuer 72 script.Set it as null when there is no 72 script.
     *
     * @param script72 Issuer 72 script.
     */
    public void setScript72(byte[] script72) {
        this.script72 = script72;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }
    public OnlineResponse() {
    }

    protected OnlineResponse(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<OnlineResponse> CREATOR = new Parcelable.Creator<OnlineResponse>() {
        @Override
        public OnlineResponse createFromParcel(Parcel source) {
            return new OnlineResponse(source);
        }

        @Override
        public OnlineResponse[] newArray(int size) {
            return new OnlineResponse[size];
        }
    };

    @Override
    public String toString() {
        return "OnlineResponse{" +
                "rspCode=" + ByteUtils.byteArray2HexString(rspCode) +
                ", authCode=" + ByteUtils.byteArray2HexString(authCode) +
                ", authData=" + ByteUtils.byteArray2HexString(authData) +
                ", script71=" + ByteUtils.byteArray2HexString(script71) +
                ", script72=" + ByteUtils.byteArray2HexString(script72) +
                '}';
    }
}
