package com.trendit.basesdk.device.psam;

/**
 * <b>PSAMDevice</b>Defined the interface for PSMA devices.
 * <pre>
 * PSAMDevice device = POSDeviceManager.getInstance().getPSAMDevice();
 * </pre>
 * The caller cannot create the object through new
 */
public abstract class PSAMDevice {

    /**
     * open device
     */
    public abstract void open();

    /**
     * close device
     */
    public abstract void close();

    /**
     * @return Does the PSAM card exist
     */
    public abstract boolean isCardExist();

    /**
     * Establish a connection with the card
     *
     * @return Card power on return data， if null connect error.
     */
    public abstract byte[] connect();

    /**
     * Disconnect from card
     */
    public abstract void disconnect();

    /**
     * APDU instruction interaction
     *
     * @param apdu apdu instruction
     * @return Card return data
     */
    public abstract byte[] exchangeAPDU(byte[] apdu);
}
