package com.trendit.basesdk.device.printer.format;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * Image Printing Format
 */
public class BitmapFormat extends BaseParcelable implements Parcelable {
    @FieldNumber(1)
    private PrintAlign align = PrintAlign.FORMAT_ALIGN_LEFT;
    @FieldNumber(2)
    private int width;
    @FieldNumber(3)
    private int height;

    /**
     * Obtain printing location
     *
     * @return printing location
     */
    public PrintAlign getAlign() {
        return align;
    }

    /**
     * Set printing location
     *
     * @param align printing location
     */
    public void setAlign(PrintAlign align) {
        this.align = align;
    }


    /**
     * Get image printing width
     *
     * @return image printing width
     */
    public int getWidth() {
        return width;
    }

    /**
     * Set image printing width
     *
     * @param width image printing width
     */
    public void setWidth(int width) {
        this.width = width;
    }

    /**
     * Get image printing height
     *
     * @return image printing height
     */
    public int getHeight() {
        return height;
    }

    /**
     * Set image printing height
     *
     * @param height image printing height
     */
    public void setHeight(int height) {
        this.height = height;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public BitmapFormat() {
    }

    protected BitmapFormat(Parcel in) {
        readFromParcelable(in);
    }

    public static final Creator<BitmapFormat> CREATOR = new Creator<BitmapFormat>() {
        @Override
        public BitmapFormat createFromParcel(Parcel source) {
            return new BitmapFormat(source);
        }

        @Override
        public BitmapFormat[] newArray(int size) {
            return new BitmapFormat[size];
        }
    };

    @Override
    public String toString() {
        return "BitmapFormat{" +
                "align=" + align +
                ", width=" + width +
                ", height=" + height +
                '}';
    }
}
