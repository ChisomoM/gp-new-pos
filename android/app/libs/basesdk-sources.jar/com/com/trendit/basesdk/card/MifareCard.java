package com.trendit.basesdk.card;

import com.trendit.basesdk.device.picc.PICCCardConstants;

/**
 * <b>MifareCard</b>MifareCard。
 * <pre>
 * MifareCard card = POSDeviceManager.getInstance().getPICCCardDevice().getMifareCardHandler();
 * </pre>
 */
public abstract class MifareCard {


    /**
     * Verify the Key of the given partition
     * <p>
     * Regardless of whether the verification fails or succeeds, the partition where the previous card was opened will be closed.
     * <p>
     *
     * @param cardProtocol {@link PICCCardConstants#PROTOCOL_RFCARD_TYPE_A} {@link PICCCardConstants#PROTOCOL_RFCARD_TYPE_B}
     * @param blockNo      Block number
     * @param serial       CARD SERIAL NUMBER
     * @param key          A 6-byte key.
     * @return {@code true} Success，{@code false} Fail.
     */
    public abstract boolean verifyKey(int cardProtocol, int blockNo, byte[] serial, byte[] key);


    /**
     * Reading data from a block in a partition.
     *
     * @param blockNo Block number
     * @return block data
     */
    public abstract byte[] readBlock(int blockNo);


    /**
     * Write a block for a partition.
     * <p>
     *
     * @param blockNo Block number
     * @param buffer  write data
     * @return {@code true} Success，{@code false} Fail.
     */
    public abstract boolean writeBlock(int blockNo, byte[] buffer);


    /**
     * Write wallet data and user data into the electronic wallet.
     * <p>
     *
     * @param blockNo Block number.
     * @param value   Wallet data and user data
     * @return {@code true} Success，{@code false} Fail.
     */
    public abstract boolean writeValue(int blockNo, MoneyValue value);


    /**
     * Read wallet data and user data from the electronic wallet.
     * <p>
     *
     * @param blockNo Block number.
     * @return Wallet data and user data.
     */
    public abstract MoneyValue readValue(int blockNo);


    /**
     * Set the data value of the electronic wallet and perform addition.
     *
     * @param blockNo Block number.
     * @param value   Wallet data, added value
     * @return {@code true} Success，{@code false} Fail.
     */
    public abstract boolean increaseValue(int blockNo, int value);


    /**
     * Set the data value of the electronic wallet and perform subtraction.
     *
     * @param blockNo Block number.
     * @param value   Wallet data, subtracted value
     * @return {@code true} Success，{@code false} Fail.
     */
    public abstract boolean decreaseValue(int blockNo, int value);


    /**
     * Cancel the previous appreciation or impairment operation
     *
     * @return {@code true} Success，{@code false} Fail.
     */
    public abstract boolean cancel();


    /**
     * Returns the ID of the card.
     * <p>
     *
     * @return Byte stream of card ID
     */
    public abstract byte[] getID();


    /**
     * Returns a constant that represents the current card slot and card communication protocol.
     * <p>
     * This method is a synchronous method. When a card exists in the card slot and is successfully opened, the card object can be read at any time.
     * {@link PICCCardConstants#PROTOCOL_RFCARD_TYPE_A} {@link PICCCardConstants#PROTOCOL_RFCARD_TYPE_B}
     * <p>
     *
     * @return Constant for card communication protocol
     */
    public abstract int getProtocol();


    /**
     * Returns the status of the card operation result object.
     * {@link CardConstants}
     *
     * @return card status
     */
    public abstract int getCardStatus();
}
