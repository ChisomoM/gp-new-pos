package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

import java.util.Arrays;

/**
 * User Interface Request Data
 */
public class EntryPointUserInterfaceReqData extends BaseParcelable implements Parcelable {

    @FieldNumber(1)
    private byte messageID;
    @FieldNumber(2)
    private byte status;
    @FieldNumber(3)
    private byte[] holdTime;
    @FieldNumber(4)
    private byte[] languagePreference;
    @FieldNumber(5)
    private byte valueQualifier;
    @FieldNumber(6)
    private byte[] value;
    @FieldNumber(7)
    private byte[] currencyCode;

    public EntryPointUserInterfaceReqData() {

    }

    protected EntryPointUserInterfaceReqData(Parcel in) {
        readFromParcelable(in);
    }

    public static final Creator<EntryPointUserInterfaceReqData> CREATOR = new Creator<EntryPointUserInterfaceReqData>() {
        @Override
        public EntryPointUserInterfaceReqData createFromParcel(Parcel in) {
            return new EntryPointUserInterfaceReqData(in);
        }

        @Override
        public EntryPointUserInterfaceReqData[] newArray(int size) {
            return new EntryPointUserInterfaceReqData[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    /**
     * Get the Message Identifier
     *
     * @return Message Identifier
     */
    public byte getMessageID() {
        return messageID;
    }

    /**
     * Set the Message Identifier
     *
     * @param messageID Message Identifier
     */
    public void setMessageID(byte messageID) {
        this.messageID = messageID;
    }

    /**
     * Get the Status
     *
     * @return Status
     */
    public byte getStatus() {
        return status;
    }

    /**
     * Set the Status
     *
     * @param status status
     */
    public void setStatus(byte status) {
        this.status = status;
    }

    /**
     * Get the Hold Time
     *
     * @return Hold Time
     */
    public byte[] getHoldTime() {
        return holdTime;
    }

    /**
     * Set the Hold Time
     *
     * @param holdTime Hold Time
     */
    public void setHoldTime(byte[] holdTime) {
        this.holdTime = holdTime;
    }

    /**
     * Get the Language Preference
     *
     * @return Language Preference
     */
    public byte[] getLanguagePreference() {
        return languagePreference;
    }

    /**
     * Set the Language Preference
     *
     * @param languagePreference Language Preference
     */
    public void setLanguagePreference(byte[] languagePreference) {
        this.languagePreference = languagePreference;
    }

    /**
     * Get the Value Qualifier
     *
     * @return Value Qualifier
     */
    public byte getValueQualifier() {
        return valueQualifier;
    }

    /**
     * Set the Value Qualifier
     *
     * @param valueQualifier Value Qualifier
     */
    public void setValueQualifier(byte valueQualifier) {
        this.valueQualifier = valueQualifier;
    }

    /**
     * Get the value
     *
     * @return value
     */
    public byte[] getValue() {
        return value;
    }

    /**
     * Set the value
     *
     * @param value value
     */
    public void setValue(byte[] value) {
        this.value = value;
    }

    /**
     * Get the Currency Code
     *
     * @return Currency Code
     */
    public byte[] getCurrencyCode() {
        return currencyCode;
    }

    /**
     * Set the Currency Code
     *
     * @param currencyCode Currency Code
     */
    public void setCurrencyCode(byte[] currencyCode) {
        this.currencyCode = currencyCode;
    }

    @Override
    public String toString() {
        return "EntryPointUserInterfaceReqData{" +
                "messageID=" + (messageID & 0xFF) +
                ", status=" + (status & 0xFF) +
                ", holdTime=" + ByteUtils.byteArray2HexString(holdTime) +
                ", languagePreference=" + ByteUtils.byteArray2HexString(languagePreference) +
                ", valueQualifier=" + (valueQualifier & 0xFF) +
                ", value=" + ByteUtils.byteArray2HexString(value) +
                ", currencyCode=" + ByteUtils.byteArray2HexString(currencyCode) +
                '}';
    }
}
