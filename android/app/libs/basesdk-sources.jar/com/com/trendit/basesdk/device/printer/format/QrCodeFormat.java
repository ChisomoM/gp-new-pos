package com.trendit.basesdk.device.printer.format;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * Print QR code format
 */
public class QrCodeFormat extends BaseParcelable implements Parcelable {
    @FieldNumber(1)
    private PrintAlign align = PrintAlign.FORMAT_ALIGN_LEFT;
    @FieldNumber(2)
    private int width;
    @FieldNumber(3)
    private int height;

    /**
     * Obtain printing location
     *
     * @return printing location
     */
    public PrintAlign getAlign() {
        return align;
    }

    /**
     * Set printing location
     *
     * @param align printing location
     */
    public void setAlign(PrintAlign align) {
        this.align = align;
    }

    /**
     * Get Qrcode printing width
     *
     * @return Qrcode printing width
     */
    public int getWidth() {
        return width;
    }

    /**
     * Set Qrcode printing width
     *
     * @param width Qrcode printing width
     */
    public void setWidth(int width) {
        this.width = width;
    }

    /**
     * Get Qrcode printing height
     *
     * @return Qrcode printing height
     */
    public int getHeight() {
        return height;
    }

    /**
     * Set Qrcode printing height
     *
     * @param height Qrcode printing height
     */
    public void setHeight(int height) {
        this.height = height;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public QrCodeFormat() {
    }

    protected QrCodeFormat(Parcel in) {
        readFromParcelable(in);
    }

    public static final Creator<QrCodeFormat> CREATOR = new Creator<QrCodeFormat>() {
        @Override
        public QrCodeFormat createFromParcel(Parcel source) {
            return new QrCodeFormat(source);
        }

        @Override
        public QrCodeFormat[] newArray(int size) {
            return new QrCodeFormat[size];
        }
    };

    @Override
    public String toString() {
        return "QrCodeFormat{" +
                "align=" + align +
                ", width=" + width +
                ", height=" + height +
                '}';
    }
}
