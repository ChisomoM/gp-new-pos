package com.trendit.basesdk.card;


public class CardConstants {

    /**
     * The current card slot is in<b>connected</b> status. pass through <code>getCardStatus()</code> method return。
     */
    public static final int STATUS_CONNECTED = 0;

    /**
     * The current card slot is in<b>disconnected</b>status。pass through <code>getCardStatus()</code> method return。
     */
    public static final int STATUS_DISCONNECTED = 1;

    /**
     * The current card slot is in<b>removed</b>status。pass through<code>getCardStatus()</code> method return。
     */
    public static final int STATUS_ABSENT = 2;


    /**
     * SUCCESS
     */
    public static final int RESULT_SUCCESS = 1;

    /**
     * CANCEL
     */
    public static final int RESULT_ERR_CANCEL = 2;

    /**
     * ERROR
     */
    public static final int RESULT_ERR_GENERAL_ERROR = -1;

    /**
     * TIMEOUT
     */
    public static final int RESULT_ERR_TIMEOUT = -4;

    /**
     * READ CARD FAIL
     */
    public static final int RESULT_ERR_READFAIL = -101;

    /**
     * Multiple cards present
     */
    public static final int RESULT_ERROR_MULTI_CARD = -102;

}
