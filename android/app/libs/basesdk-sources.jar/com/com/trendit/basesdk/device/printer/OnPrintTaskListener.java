package com.trendit.basesdk.device.printer;

/**
 * Print Task Callback
 */
public abstract class OnPrintTaskListener {
    /**
     * Print Task result Callback
     *
     * @param retCode {@link PrinterConstants#TASK_STATUS_CANCEL} {@link PrinterConstants#TASK_STATUS_SUCCESS} {@link PrinterConstants#TASK_STATUS_FAIL}
     */
    public abstract void onPrintResult(int retCode);
}
