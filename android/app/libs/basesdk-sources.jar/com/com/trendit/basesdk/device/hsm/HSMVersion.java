package com.trendit.basesdk.device.hsm;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * Security chip version information
 */
public class HSMVersion extends BaseParcelable implements Parcelable {
    @FieldNumber(1)
    private String bootVersion;
    @FieldNumber(2)
    private String coreVersion;
    @FieldNumber(3)
    private String appVersion;
    @FieldNumber(4)
    private String hwVersion;

    public HSMVersion(String bootVersion, String coreVersion, String appVersion, String hwVersion) {
        this.bootVersion = bootVersion;
        this.coreVersion = coreVersion;
        this.appVersion = appVersion;
        this.hwVersion = hwVersion;
    }

    /**
     * @return Security chip Boot version
     */
    public String getBootVersion() {
        return bootVersion;
    }

    /**
     * @return Security chip Core version
     */
    public String getCoreVersion() {
        return coreVersion;
    }

    /**
     * @return Security chip App version
     */
    public String getAppVersion() {
        return appVersion;
    }

    /**
     * @return Hardware Version
     */
    public String getHwVersion() {
        return hwVersion;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    protected HSMVersion(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<HSMVersion> CREATOR = new Parcelable.Creator<HSMVersion>() {
        @Override
        public HSMVersion createFromParcel(Parcel source) {
            return new HSMVersion(source);
        }

        @Override
        public HSMVersion[] newArray(int size) {
            return new HSMVersion[size];
        }
    };

    @Override
    public String toString() {
        return "HSMVersion{" +
                "bootVersion='" + bootVersion + '\'' +
                ", coreVersion='" + coreVersion + '\'' +
                ", appVersion='" + appVersion + '\'' +
                ", hwVersion='" + hwVersion + '\'' +
                '}';
    }
}
