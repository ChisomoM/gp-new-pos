package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * AID list provide for select
 * {@link EMVTransListener#onWaitAppSelect}
 */
public class AIDSelect extends BaseParcelable implements Parcelable {
    /**
     * Application ID
     */
    @FieldNumber(1)
    private byte[] aid;
    /**
     * Application Label
     */
    @FieldNumber(2)
    private String appLabel;
    /**
     * Application Preferred Name
     */
    @FieldNumber(3)
    private String preferName;
    /**
     * Application Priority Indicator
     */
    @FieldNumber(4)
    private int priority;

    /**
     * Get the Select Application ID
     *
     * @return Application ID
     */
    public byte[] getAid() {
        return aid;
    }

    /**
     * Set the Application ID
     *
     * @param aid Application ID
     */
    public void setAid(byte[] aid) {
        this.aid = aid;
    }

    /**
     * Get the Application Label
     *
     * @return Application Label
     */
    public String getAppLabel() {
        return appLabel;
    }

    /**
     * Set the Application Label
     *
     * @param appLabel Application Label
     */
    public void setAppLabel(String appLabel) {
        this.appLabel = appLabel;
    }

    /**
     * Get the Application Preferred Name
     *
     * @return Application Preferred Name
     */
    public String getPreferName() {
        return preferName;
    }

    /**
     * Set the Application Preferred Name
     *
     * @param preferName Application Preferred Name
     */
    public void setPreferName(String preferName) {
        this.preferName = preferName;
    }

    /**
     * Get the Application Priority Indicator
     *
     * @return Application Priority Indicator
     */
    public int getPriority() {
        return priority;
    }

    /**
     * Set the Application Priority Indicator
     *
     * @param priority Application Priority Indicator
     */
    public void setPriority(int priority) {
        this.priority = priority;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public AIDSelect() {
    }
    protected AIDSelect(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<AIDSelect> CREATOR = new Parcelable.Creator<AIDSelect>() {
        @Override
        public AIDSelect createFromParcel(Parcel source) {
            return new AIDSelect(source);
        }

        @Override
        public AIDSelect[] newArray(int size) {
            return new AIDSelect[size];
        }
    };

    @Override
    public String toString() {
        return "AIDSelect{" +
                "aid=" + ByteUtils.byteArray2HexString(aid) +
                ", appLabel='" + appLabel + '\'' +
                ", preferName='" + preferName + '\'' +
                ", priority=" + priority +
                '}';
    }
}
