package com.trendit.basesdk.device.printer.format;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Barcode printing type
 */
public enum PrintBarCodeType implements Parcelable {

    /**
     * UPC-A  Barcode
     */
    BARCODE_TYPE_UPC_A(0),

    /**
     * UPC-E  Barcode
     */
    BARCODE_TYPE_UPC_E(1),

    /**
     * JAN13  Barcode
     */
    BARCODE_TYPE_JAN13(2),

    /**
     * JAN8  Barcode
     */
    BARCODE_TYPE_JAN8(3),

    /**
     * CODE39 Barcode
     */
    BARCODE_TYPE_CODE39(4),

    /**
     * TIF Barcode
     */
    BARCODE_TYPE_ITF(5),

    /**
     * CODABAR Barcode
     */
    BARCODE_TYPE_CODABAR(6),

    /**
     * CODE93 Barcode
     */
    BARCODE_TYPE_CODE93(7),

    /**
     * CODE128 Barcode
     */
    BARCODE_TYPE_CODE128(8);

    private int barcodeType;


    PrintBarCodeType(int barcodeType) {
        this.barcodeType = barcodeType;
    }

    public int getBarcodeType() {
        return this.barcodeType;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeInt(ordinal());
    }

    public static final Creator<PrintBarCodeType> CREATOR = new Creator<PrintBarCodeType>() {

        @Override
        public PrintBarCodeType createFromParcel(Parcel parcel) {
            int ordinal = parcel.readInt();
            for (PrintBarCodeType barCodeType : PrintBarCodeType.values()) {
                if (barCodeType.ordinal() == ordinal) {
                    return barCodeType;
                }
            }
            return null;
        }

        @Override
        public PrintBarCodeType[] newArray(int size) {
            return new PrintBarCodeType[size];
        }
    };
}
