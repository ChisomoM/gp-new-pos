package com.trendit.basesdk.device.serialport;

public class SerialPortConstants {

    /**
     * Success
     */
    public static final int ERROR_OK = 0;

    /**
     * Failed to disconnect service program
     */
    public static final int ERR_BIND_SERVER = -101;

    /**
     * Service exception
     */
    public static final int ERR_EXCEPTION_SERVER = -102;

    /**
     * Find device error
     */
    public static final int ERR_NO_DEVICE = -103;

    /**
     * Device busy
     */
    public static final int ERR_BUSY = -104;


}
