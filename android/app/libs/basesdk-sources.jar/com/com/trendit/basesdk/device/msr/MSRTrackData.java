package com.trendit.basesdk.device.msr;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * Magnetic card track info
 */
public class MSRTrackData extends BaseParcelable implements Parcelable {
    @FieldNumber(1)
    private byte[] track1;
    @FieldNumber(2)
    private byte[] track2;
    @FieldNumber(3)
    private byte[] track3;
    @FieldNumber(4)
    private int track1ErrorCode;
    @FieldNumber(5)
    private int track2ErrorCode;
    @FieldNumber(6)
    private int track3ErrorCode;

    // Card number
    @FieldNumber(7)
    private String cardNo = null;
    // Card validity period
    @FieldNumber(8)
    private String expiryDate = null;
    // service code
    @FieldNumber(9)
    private String serviceCode = null;
    //CARD SERIAL NUMBER
    @FieldNumber(10)
    private String serialNum = null;
    //Card type (debit or credit card)
    @FieldNumber(11)
    private String cardType = null;
    //Card Area (Domestic or Overseas Cards)
    @FieldNumber(12)
    private String cardArea = null;

    /**
     * @return track1
     */
    public byte[] getTrack1() {
        return track1;
    }

    /**
     * @param track1 track1
     */
    public void setTrack1(byte[] track1) {
        this.track1 = track1;
    }

    /**
     * @return track2
     */
    public byte[] getTrack2() {
        return track2;
    }

    /**
     * @param track2 track2
     */
    public void setTrack2(byte[] track2) {
        this.track2 = track2;
    }

    /**
     * @return track3
     */
    public byte[] getTrack3() {
        return track3;
    }

    /**
     * @param track3 track3
     */
    public void setTrack3(byte[] track3) {
        this.track3 = track3;
    }

    /**
     * @return Track 1 error code
     * @see MSRConstants#NO_ERROR , etc
     */
    public int getTrack1ErrorCode() {
        return track1ErrorCode;
    }

    /**
     * Set Track 1 Error Code
     * @param track1ErrorCode track1 error code
     */
    public void setTrack1ErrorCode(int track1ErrorCode) {
        this.track1ErrorCode = track1ErrorCode;
    }

    /**
     * @return Track 2 error code
     * @see MSRConstants#NO_ERROR , etc
     */
    public int getTrack2ErrorCode() {
        return track2ErrorCode;
    }

    /**
     * Set Track 2 Error Code
     * @param track2ErrorCode track2 error code
     */
    public void setTrack2ErrorCode(int track2ErrorCode) {
        this.track2ErrorCode = track2ErrorCode;
    }

    /**
     * @return Track 3 error code
     * @see MSRConstants#NO_ERROR , etc
     */
    public int getTrack3ErrorCode() {
        return track3ErrorCode;
    }

    /**
     * Set Track 3 Error Code
     * @param track3ErrorCode track3 error code
     */
    public void setTrack3ErrorCode(int track3ErrorCode) {
        this.track3ErrorCode = track3ErrorCode;
    }

    /**
     * @return Magnetic stripe card number
     */
    public String getCardNo() {
        return cardNo;
    }

    /**
     * Set magnetic stripe card number
     *
     * @param cardNo card number
     */
    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    /**
     * Get card validity period
     *
     * @return validity period
     */
    public String getExpiryDate() {
        return expiryDate;
    }

    /**
     * Set Card Validity Period
     *
     * @param expiryDate Validity Period
     */
    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    /**
     * Obtain Card Service Code
     *
     * @return Service Code
     */
    public String getServiceCode() {
        return serviceCode;
    }

    /**
     * Set Card Service Code
     *
     * @param serviceCode Service Code
     */
    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    /**
     * Obtain card serial number
     *
     * @return card serial number
     */
    public String getSerialNum() {
        return serialNum;
    }

    /**
     * Set card serial number
     *
     * @param serialNum card serial number
     */
    public void setSerialNum(String serialNum) {
        this.serialNum = serialNum;
    }

    /**
     * Obtain Card Type
     *
     * @return Card Type
     */
    public String getCardType() {
        return cardType;
    }

    /**
     * Set Card Type
     *
     * @param cardType Card Type
     */
    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    /**
     * Obtain Card Area
     *
     * @return Card Area
     */
    public String getCardArea() {
        return cardArea;
    }

    /**
     * Set Card Area
     *
     * @param cardArea Card Area
     */
    public void setCardArea(String cardArea) {
        this.cardArea = cardArea;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public MSRTrackData() {
    }

    protected MSRTrackData(Parcel in) {
        readFromParcelable(in);
    }

    public static final Creator<MSRTrackData> CREATOR = new Creator<MSRTrackData>() {
        @Override
        public MSRTrackData createFromParcel(Parcel source) {
            return new MSRTrackData(source);
        }

        @Override
        public MSRTrackData[] newArray(int size) {
            return new MSRTrackData[size];
        }
    };

    @Override
    public String toString() {
        return "MSRTrackData{" +
                "track1=" + ByteUtils.byteArray2HexString(track1) +
                ", track2=" + ByteUtils.byteArray2HexString(track2) +
                ", track3=" + ByteUtils.byteArray2HexString(track3) +
                ", track1ErrorCode=" + track1ErrorCode +
                ", track2ErrorCode=" + track2ErrorCode +
                ", track3ErrorCode=" + track3ErrorCode +
                ", cardNo='" + cardNo + '\'' +
                ", expiryDate='" + expiryDate + '\'' +
                ", serviceCode='" + serviceCode + '\'' +
                ", serialNum='" + serialNum + '\'' +
                ", cardType='" + cardType + '\'' +
                ", cardArea='" + cardArea + '\'' +
                '}';
    }
}
