package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

import java.util.Arrays;

/**
 * EMV Terminal Config
 */
public class EMVTermConfig extends BaseParcelable implements Parcelable {

    /**
     * '9F1E' Interface Device (IFD) Serial Number (Refer to EMV Book 3)
     */
    @FieldNumber(1)
    private String IFDSerialNo;

    /**
     * '9F1C' Terminal Identification (Refer to EMV Book 3)
     */
    @FieldNumber(2)
    private String terminalNo;

    /**
     * '9F15' 2 bytes Merchant Category Code (Refer to EMV Book 3)
     */
    @FieldNumber(3)
    private byte[] merchantCateCode;

    /**
     * '9F16' Merchant Identifier (Refer to EMV Book 3)
     */
    @FieldNumber(4)
    private String merchantNo;
    /**
     * '9F4E' Merchant Name and Location (Refer to EMV Book 3)
     */
    @FieldNumber(5)
    private String merchantName;

    /**
     * '9F1A' 2 bytes Terminal Country Code (Refer to EMV Book 3)
     */
    @FieldNumber(6)
    private byte[] countryCode;

    /**
     * 5F2A' 2 bytes Transaction Currency Code (Refer to EMV Book 3)
     */
    @FieldNumber(7)
    private byte[] transCurrencyCode;

    /**
     * '5F36' Transaction Currency Exponent (Refer to EMV Book 3)
     */
    @FieldNumber(8)
    private byte transCurrencyExp;

    /**
     * '9F66' 4 bytes Terminal Transaction Qualifiers. (Refer to VCPS Spec)
     */
    @FieldNumber(9)
    private byte[] terminalTransPredicable;

    /**
     * '9F33' 3bytes Terminal Capabilities (Refer to EMV Book 3)
     */
    @FieldNumber(10)
    private byte[] terminalCapabilities;

    /**
     * 9F40' 5 bytes Additional Terminal Capabilities (Refer to EMV Book 3)
     */
    @FieldNumber(11)
    private byte[] terminalAddCapabilities;

    /**
     * 9F3C' 2 bytes Transaction Reference Currency Code (Refer to EMV Book 3)
     */
    @FieldNumber(12)
    private byte[] transReferCurrencyCode;

    /**
     * '9F3D' Transaction Reference Currency Exponent (Refer to EMV Book 3)
     */
    @FieldNumber(13)
    private byte transReferCurrencyExp;

    /**
     * Force online flag, Recommended application set this flag to true
     */
    @FieldNumber(14)
    private boolean forceOnline;

    /**
     * "9F35"  terminal type set to 0x22
     */
    @FieldNumber(15)
    private int terminalType;

    /**
     * set true If the application need support unionpay qUICS(EMV contactless kernel 7)
     */
    @FieldNumber(16)
    private boolean supportQPBOC;

    /**
     * set true If the application need support VISA PAYWAVE(EMV contactless kernel 3)
     */
    @FieldNumber(17)
    private boolean supportPAYWAVE;

    /**
     * set true If the application need support Master PAYPASS(EMV contactless kernel 2)
     */
    @FieldNumber(18)
    private boolean supportPAYPASS;

    /**
     * '9F7C' Merchant Custom Data (Refer to EMV C-2-Kernel-2 book)
     */
    @FieldNumber(19)
    private byte[] payPassMerchantCustomData;

    /**
     * 'DF8117' Card Data Input Capability (Refer to EMV C-2-Kernel-2 book)
     */
    @FieldNumber(20)
    private byte payPassCardDataInputCapability;

    /**
     * 'DF811F' Security Capability (Refer to EMV C-2-Kernel-2 book)
     */
    @FieldNumber(21)
    private byte payPassSecurityCapability;

    /**
     * DF8118' CVM Capability – CVM Required (Refer to EMV C-2-Kernel-2 book)
     */
    @FieldNumber(22)
    private byte CVMCap_CVMReq;

    /**
     * DF8119' CVM Capability – No CVM Required (Refer to EMV C-2-Kernel-2 book)
     */
    @FieldNumber(23)
    private byte CVMCap_NoCVMReq;

    /**
     * 'DF811E' Mag-stripe CVM Capability – CVM Required (Refer to EMV C-2-Kernel-2 book)
     */
    @FieldNumber(24)
    private byte magCVMCap_CVMReq;

    /**
     * 'DF812C' Mag-stripe CVM Capability – No CVM Required(Refer to EMV C-2-Kernel-2 book)
     */
    @FieldNumber(25)
    private byte magCVMCap_NoCVMReq;

    /**
     * 'DF811B' Kernel Configuration (Refer to EMV C-2-Kernel-2 book)
     */
    @FieldNumber(26)
    private byte payPassKernelCfg;

    /**
     * Paywave Dynamic Limit Sets Check enableflag (Refer to VCPS Spec)
     */
    @FieldNumber(27)
    private boolean supportPaywaveDRLCheck;

    @FieldNumber(28)
    private boolean supportDISCOVERDPAS;

    @FieldNumber(29)
    private boolean supportEXPRESSPAY;

    @FieldNumber(30)
    private boolean supportPUREPAY;

    @FieldNumber(31)
    private boolean supportDeferAuthor;

    @FieldNumber(32)
    private byte[] discoverTermTransPredicable;

    @FieldNumber(33)
    private byte[] expressEnhancedCtlRdCap;

    @FieldNumber(34)
    private byte[] pureTermClsCap;

    /**
     * Get the '9F1E' Interface Device (IFD) Serial Number (Refer to EMV Book 3)
     *
     * @return ifd
     */
    public String getIFDSerialNo() {
        return IFDSerialNo;
    }

    /**
     * Set the '9F1E' Interface Device (IFD) Serial Number (Refer to EMV Book 3)
     *
     * @param IFDSerialNo ifd
     */
    public void setIFDSerialNo(String IFDSerialNo) {
        this.IFDSerialNo = IFDSerialNo;
    }

    /**
     * Get the '9F1C' Terminal Identification (Refer to EMV Book 3)
     *
     * @return terminal no
     */
    public String getTerminalNo() {
        return terminalNo;
    }

    /**
     * Set the '9F1C' Terminal Identification (Refer to EMV Book 3)
     *
     * @param terminalNo terminal no
     */
    public void setTerminalNo(String terminalNo) {
        this.terminalNo = terminalNo;
    }

    /**
     * Get the '9F15' 2 bytes Merchant Category Code (Refer to EMV Book 3)
     *
     * @return merchant cate code
     */
    public byte[] getMerchantCateCode() {
        return merchantCateCode;
    }

    /**
     * Set the '9F15' 2 bytes Merchant Category Code (Refer to EMV Book 3)
     *
     * @param merchantCateCode merchant cate code
     */
    public void setMerchantCateCode(byte[] merchantCateCode) {
        this.merchantCateCode = merchantCateCode;
    }

    /**
     * Get the '9F16' Merchant Identifier (Refer to EMV Book 3)
     *
     * @return merchant no
     */
    public String getMerchantNo() {
        return merchantNo;
    }

    /**
     * Set the '9F16' Merchant Identifier (Refer to EMV Book 3)
     *
     * @param merchantNo merchant no
     */
    public void setMerchantNo(String merchantNo) {
        this.merchantNo = merchantNo;
    }

    /**
     * Get the '9F4E' Merchant Name and Location (Refer to EMV Book 3)
     *
     * @return merchant Name
     */
    public String getMerchantName() {
        return merchantName;
    }

    /**
     * Set the '9F4E' Merchant Name and Location (Refer to EMV Book 3)
     *
     * @param merchantName merchant Name
     */
    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    /**
     * Get the '9F1A' 2 bytes Terminal Country Code (Refer to EMV Book 3)
     *
     * @return country code
     */
    public byte[] getCountryCode() {
        return countryCode;
    }

    /**
     * Set the '9F1A' 2 bytes Terminal Country Code (Refer to EMV Book 3)
     *
     * @param countryCode country code
     */
    public void setCountryCode(byte[] countryCode) {
        this.countryCode = countryCode;
    }

    /**
     * Get the '5F36' Transaction Currency Exponent (Refer to EMV Book 3)
     *
     * @return trans currency code
     */
    public byte[] getTransCurrencyCode() {
        return transCurrencyCode;
    }

    /**
     * Set the '5F36' Transaction Currency Exponent (Refer to EMV Book 3)
     *
     * @param transCurrencyCode trans currency code
     */
    public void setTransCurrencyCode(byte[] transCurrencyCode) {
        this.transCurrencyCode = transCurrencyCode;
    }

    /**
     * Get the'5F36' Transaction Currency Exponent (Refer to EMV Book 3)
     *
     * @return trans currency code
     */
    public byte getTransCurrencyExp() {
        return transCurrencyExp;
    }

    /**
     * Set the '5F36' Transaction Currency Exponent (Refer to EMV Book 3)
     *
     * @param transCurrencyExp trans currency code
     */
    public void setTransCurrencyExp(byte transCurrencyExp) {
        this.transCurrencyExp = transCurrencyExp;
    }

    /**
     * Get the '9F66' 4 bytes Terminal Transaction Qualifiers. (Refer to VCPS Spec)
     *
     * @return Terminal Transaction Qualifiers
     */
    public byte[] getTerminalTransPredicable() {
        return terminalTransPredicable;
    }

    /**
     * Set the '9F66' 4 bytes Terminal Transaction Qualifiers. (Refer to VCPS Spec)
     *
     * @param terminalTransPredicable Terminal Transaction Qualifiers
     */
    public void setTerminalTransPredicable(byte[] terminalTransPredicable) {
        this.terminalTransPredicable = terminalTransPredicable;
    }

    /**
     * Get the '9F33' 3bytes Terminal Capabilities (Refer to EMV Book 3)
     *
     * @return Terminal Capabilities
     */
    public byte[] getTerminalCapabilities() {
        return terminalCapabilities;
    }

    /**
     * Set the '9F33' 3bytes Terminal Capabilities (Refer to EMV Book 3)
     *
     * @param terminalCapabilities Terminal Capabilities
     */
    public void setTerminalCapabilities(byte[] terminalCapabilities) {
        this.terminalCapabilities = terminalCapabilities;
    }

    /**
     * Get the 9F40' 5 bytes Additional Terminal Capabilities (Refer to EMV Book 3)
     *
     * @return 5 bytes Additional Terminal Capabilities
     */
    public byte[] getTerminalAddCapabilities() {
        return terminalAddCapabilities;
    }

    /**
     * Set the 9F40' 5 bytes Additional Terminal Capabilities (Refer to EMV Book 3)
     *
     * @param terminalAddCapabilities Additional Terminal Capabilities
     */
    public void setTerminalAddCapabilities(byte[] terminalAddCapabilities) {
        this.terminalAddCapabilities = terminalAddCapabilities;
    }

    /**
     * Get the 9F3C' 2 bytes Transaction Reference Currency Code (Refer to EMV Book 3)
     *
     * @return Transaction Reference Currency Code
     */
    public byte[] getTransReferCurrencyCode() {
        return transReferCurrencyCode;
    }

    /**
     * Set the 9F3C' 2 bytes Transaction Reference Currency Code (Refer to EMV Book 3)
     *
     * @param transReferCurrencyCode Transaction Reference Currency Code
     */
    public void setTransReferCurrencyCode(byte[] transReferCurrencyCode) {
        this.transReferCurrencyCode = transReferCurrencyCode;
    }

    /**
     * Get the '9F3D' Transaction Reference Currency Exponent (Refer to EMV Book 3)
     *
     * @return Transaction Reference Currency Exponent
     */
    public byte getTransReferCurrencyExp() {
        return transReferCurrencyExp;
    }

    /**
     * Set the '9F3D' Transaction Reference Currency Exponent (Refer to EMV Book 3)
     *
     * @param transReferCurrencyExp Transaction Reference Currency Exponent
     */
    public void setTransReferCurrencyExp(byte transReferCurrencyExp) {
        this.transReferCurrencyExp = transReferCurrencyExp;
    }

    /**
     * Set the Force online flag, Recommended application set this flag to true
     *
     * @return force online
     */
    public boolean isForceOnline() {
        return forceOnline;
    }

    /**
     * Get the Force online flag, Recommended application set this flag to true
     *
     * @param forceOnline force online
     */
    public void setForceOnline(boolean forceOnline) {
        this.forceOnline = forceOnline;
    }

    /**
     * Get the  "9F35"  terminal type set to 0x22
     *
     * @return terminal type
     */
    public TerminalType getTerminalType() {
        return TerminalType.valueOf(terminalType);
    }

    /**
     * Set the  "9F35"  terminal type set to 0x22
     *
     * @param terminalType terminal type
     */
    public void setTerminalType(TerminalType terminalType) {
        this.terminalType = terminalType.getType();
    }

    /**
     * return If the application support unionpay qUICS(EMV contactless kernel 7)
     *
     * @return true or false
     */
    public boolean isSupportQPBOC() {
        return supportQPBOC;
    }

    /**
     * set true If the application need support unionpay qUICS(EMV contactless kernel 7)
     *
     * @param supportQPBOC support or not
     */
    public void setSupportQPBOC(boolean supportQPBOC) {
        this.supportQPBOC = supportQPBOC;
    }

    /**
     * return If the application support VISA PAYWAVE(EMV contactless kernel 3)
     *
     * @return support or not
     */
    public boolean isSupportPAYWAVE() {
        return supportPAYWAVE;
    }

    /**
     * set true If the application need support VISA PAYWAVE(EMV contactless kernel 3)
     *
     * @param supportPAYWAVE support or not
     */
    public void setSupportPAYWAVE(boolean supportPAYWAVE) {
        this.supportPAYWAVE = supportPAYWAVE;
    }

    /**
     * return If the application support Master PAYPASS(EMV contactless kernel 2)
     *
     * @return support or not
     */
    public boolean isSupportPAYPASS() {
        return supportPAYPASS;
    }

    /**
     * set true If the application need support Master PAYPASS(EMV contactless kernel 2)
     *
     * @param supportPAYPASS support or not
     */
    public void setSupportPAYPASS(boolean supportPAYPASS) {
        this.supportPAYPASS = supportPAYPASS;
    }

    /**
     * Get the '9F7C' Merchant Custom Data (Refer to EMV C-2-Kernel-2 book)
     *
     * @return Merchant Custom Data
     */
    public byte[] getPayPassMerchantCustomData() {
        return payPassMerchantCustomData;
    }

    /**
     * Set the '9F7C' Merchant Custom Data (Refer to EMV C-2-Kernel-2 book)
     *
     * @param payPassMerchantCustomData Merchant Custom Data
     */
    public void setPayPassMerchantCustomData(byte[] payPassMerchantCustomData) {
        this.payPassMerchantCustomData = payPassMerchantCustomData;
    }

    /**
     * Get the 'DF8117' Card Data Input Capability (Refer to EMV C-2-Kernel-2 book)
     *
     * @return Card Data Input Capability
     */
    public byte getPayPassCardDataInputCapability() {
        return payPassCardDataInputCapability;
    }

    /**
     * Set the 'DF8117' Card Data Input Capability (Refer to EMV C-2-Kernel-2 book)
     *
     * @param payPassCardDataInputCapability Card Data Input Capability
     */
    public void setPayPassCardDataInputCapability(byte payPassCardDataInputCapability) {
        this.payPassCardDataInputCapability = payPassCardDataInputCapability;
    }

    /**
     * Get the 'DF811F' Security Capability (Refer to EMV C-2-Kernel-2 book)
     *
     * @return Security Capability
     */
    public byte getPayPassSecurityCapability() {
        return payPassSecurityCapability;
    }

    /**
     * Set the 'DF811F' Security Capability (Refer to EMV C-2-Kernel-2 book)
     *
     * @param payPassSecurityCapability Security Capability
     */
    public void setPayPassSecurityCapability(byte payPassSecurityCapability) {
        this.payPassSecurityCapability = payPassSecurityCapability;
    }

    /**
     * Get the DF8118' CVM Capability – CVM Required (Refer to EMV C-2-Kernel-2 book)
     *
     * @return CVM Capability – CVM Required
     */
    public byte getCVMCap_CVMReq() {
        return CVMCap_CVMReq;
    }

    /**
     * Set the DF8118' CVM Capability – CVM Required (Refer to EMV C-2-Kernel-2 book)
     *
     * @param CVMCap_CVMReq CVM Capability – CVM Required
     */
    public void setCVMCap_CVMReq(byte CVMCap_CVMReq) {
        this.CVMCap_CVMReq = CVMCap_CVMReq;
    }

    /**
     * Get the DF8119' CVM Capability – No CVM Required (Refer to EMV C-2-Kernel-2 book)
     *
     * @return CVM Capability – No CVM Required
     */
    public byte getCVMCap_NoCVMReq() {
        return CVMCap_NoCVMReq;
    }

    /**
     * Set the DF8119' CVM Capability – No CVM Required (Refer to EMV C-2-Kernel-2 book)
     *
     * @param CVMCap_NoCVMReq CVM Capability – No CVM Required
     */
    public void setCVMCap_NoCVMReq(byte CVMCap_NoCVMReq) {
        this.CVMCap_NoCVMReq = CVMCap_NoCVMReq;
    }

    /**
     * Get the 'DF811E' Mag-stripe CVM Capability – CVM Required (Refer to EMV C-2-Kernel-2 book)
     *
     * @return Mag-stripe CVM Capability – CVM Required
     */
    public byte getMagCVMCap_CVMReq() {
        return magCVMCap_CVMReq;
    }

    /**
     * Set the 'DF811E' Mag-stripe CVM Capability – CVM Required (Refer to EMV C-2-Kernel-2 book)
     *
     * @param magCVMCap_CVMReq Mag-stripe CVM Capability – CVM Required
     */
    public void setMagCVMCap_CVMReq(byte magCVMCap_CVMReq) {
        this.magCVMCap_CVMReq = magCVMCap_CVMReq;
    }

    /**
     * Get the 'DF812C' Mag-stripe CVM Capability – No CVM Required(Refer to EMV C-2-Kernel-2 book)
     *
     * @return Mag-stripe CVM Capability – No CVM Required
     */
    public byte getMagCVMCap_NoCVMReq() {
        return magCVMCap_NoCVMReq;
    }

    /**
     * Set the 'DF812C' Mag-stripe CVM Capability – No CVM Required(Refer to EMV C-2-Kernel-2 book)
     *
     * @param magCVMCap_NoCVMReq Mag-stripe CVM Capability – No CVM Required
     */
    public void setMagCVMCap_NoCVMReq(byte magCVMCap_NoCVMReq) {
        this.magCVMCap_NoCVMReq = magCVMCap_NoCVMReq;
    }

    /**
     * Get the 'DF811B' Kernel Configuration (Refer to EMV C-2-Kernel-2 book)
     *
     * @return Kernel Configuration
     */
    public byte getPayPassKernelCfg() {
        return payPassKernelCfg;
    }

    /**
     * Set the 'DF811B' Kernel Configuration (Refer to EMV C-2-Kernel-2 book)
     *
     * @param payPassKernelCfg Kernel Configuration
     */
    public void setPayPassKernelCfg(byte payPassKernelCfg) {
        this.payPassKernelCfg = payPassKernelCfg;
    }

    /**
     * return if Paywave Dynamic Limit Sets Check enableflag (Refer to VCPS Spec)
     *
     * @return check or not
     */
    public boolean isSupportPaywaveDRLCheck() {
        return supportPaywaveDRLCheck;
    }

    /**
     * Paywave Dynamic Limit Sets Check enableflag (Refer to VCPS Spec)
     *
     * @param supportPaywaveDRLCheck check
     */
    public void setSupportPaywaveDRLCheck(boolean supportPaywaveDRLCheck) {
        this.supportPaywaveDRLCheck = supportPaywaveDRLCheck;
    }

    public void setTerminalType(int terminalType) {
        this.terminalType = terminalType;
    }

    /**
     * Check if DISCOVERDPAS is supported.
     *
     * @return return true if support
     */
    public boolean isSupportDISCOVERDPAS() {
        return supportDISCOVERDPAS;
    }

    /**
     * Set whether DISCOVERDPAS is supported.
     *
     * @param supportDISCOVERDPAS support
     */
    public void setSupportDISCOVERDPAS(boolean supportDISCOVERDPAS) {
        this.supportDISCOVERDPAS = supportDISCOVERDPAS;
    }

    /**
     * Check if EXPRESSPAY is supported.
     *
     * @return return true if support
     */
    public boolean isSupportEXPRESSPAY() {
        return supportEXPRESSPAY;
    }

    /**
     * Set whether EXPRESSPAY is supported.
     *
     * @param supportEXPRESSPAY support
     */
    public void setSupportEXPRESSPAY(boolean supportEXPRESSPAY) {
        this.supportEXPRESSPAY = supportEXPRESSPAY;
    }

    /**
     * Check if PUREPAY is supported.
     *
     * @return return true if support
     */
    public boolean isSupportPUREPAY() {
        return supportPUREPAY;
    }

    /**
     * Set whether PUREPAY is supported.
     *
     * @param supportPUREPAY support
     */
    public void setSupportPUREPAY(boolean supportPUREPAY) {
        this.supportPUREPAY = supportPUREPAY;
    }

    /**
     * Check if DeferAuthor is supported.
     *
     * @return return true if support
     */
    public boolean isSupportDeferAuthor() {
        return supportDeferAuthor;
    }

    /**
     * Set whether DeferAuthor is supported.
     *
     * @param supportDeferAuthor
     */
    public void setSupportDeferAuthor(boolean supportDeferAuthor) {
        this.supportDeferAuthor = supportDeferAuthor;
    }

    /**
     * Get the discover terminal transaction predicable "9F66"
     *
     * @return discover terminal transaction predicable "9F66"
     */
    public byte[] getDiscoverTermTransPredicable() {
        return discoverTermTransPredicable;
    }

    /**
     * Set the discover terminal transaction predicable "9F66"
     *
     * @param discoverTermTransPredicable discover terminal transaction predicable "9F66"
     */
    public void setDiscoverTermTransPredicable(byte[] discoverTermTransPredicable) {
        this.discoverTermTransPredicable = discoverTermTransPredicable;
    }

    /**
     * Get the express Enhanced Contactless Reader Capabilities
     *
     * @return express Enhanced Contactless Reader Capabilities
     */
    public byte[] getExpressEnhancedCtlRdCap() {
        return expressEnhancedCtlRdCap;
    }

    /**
     * Set the express Enhanced Contactless Reader Capabilities
     *
     * @param expressEnhancedCtlRdCap express Enhanced Contactless Reader Capabilities
     */
    public void setExpressEnhancedCtlRdCap(byte[] expressEnhancedCtlRdCap) {
        this.expressEnhancedCtlRdCap = expressEnhancedCtlRdCap;
    }

    /**
     * Get the pure Contactless Application/Kernel Capabilities
     *
     * @return pure Contactless Application/Kernel Capabilities
     */
    public byte[] getPureTermClsCap() {
        return pureTermClsCap;
    }

    /**
     * Set the pure Contactless Application/Kernel Capabilities
     *
     * @param pureTermClsCap pure Contactless Application/Kernel Capabilities
     */
    public void setPureTermClsCap(byte[] pureTermClsCap) {
        this.pureTermClsCap = pureTermClsCap;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public EMVTermConfig() {
    }

    protected EMVTermConfig(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<EMVTermConfig> CREATOR = new Parcelable.Creator<EMVTermConfig>() {
        @Override
        public EMVTermConfig createFromParcel(Parcel source) {
            return new EMVTermConfig(source);
        }

        @Override
        public EMVTermConfig[] newArray(int size) {
            return new EMVTermConfig[size];
        }
    };


    @Override
    public String toString() {
        return "EMVTermConfig{" +
                "IFDSerialNo='" + IFDSerialNo + '\'' +
                ", terminalNo='" + terminalNo + '\'' +
                ", merchantCateCode=" + ByteUtils.byteArray2HexString(merchantCateCode) +
                ", merchantNo='" + merchantNo + '\'' +
                ", merchantName='" + merchantName + '\'' +
                ", countryCode=" + ByteUtils.byteArray2HexString(countryCode) +
                ", transCurrencyCode=" + ByteUtils.byteArray2HexString(transCurrencyCode) +
                ", transCurrencyExp=" + (transCurrencyExp & 0xFF) +
                ", terminalTransPredicable=" + ByteUtils.byteArray2HexString(terminalTransPredicable) +
                ", terminalCapabilities=" + ByteUtils.byteArray2HexString(terminalCapabilities) +
                ", terminalAddCapabilities=" + ByteUtils.byteArray2HexString(terminalAddCapabilities) +
                ", transReferCurrencyCode=" + ByteUtils.byteArray2HexString(transReferCurrencyCode) +
                ", transReferCurrencyExp=" + (transReferCurrencyExp & 0xFF) +
                ", forceOnline=" + forceOnline +
                ", terminalType=" + terminalType +
                ", supportQPBOC=" + supportQPBOC +
                ", supportPAYWAVE=" + supportPAYWAVE +
                ", supportPAYPASS=" + supportPAYPASS +
                ", payPassMerchantCustomData=" + ByteUtils.byteArray2HexString(payPassMerchantCustomData) +
                ", payPassCardDataInputCapability=" + (payPassCardDataInputCapability & 0xFF) +
                ", payPassSecurityCapability=" + (payPassSecurityCapability & 0xFF) +
                ", CVMCap_CVMReq=" + (CVMCap_CVMReq & 0xFF) +
                ", CVMCap_NoCVMReq=" + (CVMCap_NoCVMReq & 0xFF) +
                ", magCVMCap_CVMReq=" + (magCVMCap_CVMReq & 0xFF) +
                ", magCVMCap_NoCVMReq=" + (magCVMCap_NoCVMReq & 0xFF) +
                ", payPassKernelCfg=" + (payPassKernelCfg & 0xFF) +
                ", supportPaywaveDRLCheck=" + supportPaywaveDRLCheck +
                ", supportDISCOVERDPAS=" + supportDISCOVERDPAS +
                ", supportEXPRESSPAY=" + supportEXPRESSPAY +
                ", supportPUREPAY=" + supportPUREPAY +
                ", supportDeferAuthor=" + supportDeferAuthor +
                ", discoverTermTransPredicable=" + ByteUtils.byteArray2HexString(discoverTermTransPredicable) +
                ", expressEnhancedCtlRdCap=" + ByteUtils.byteArray2HexString(expressEnhancedCtlRdCap) +
                ", pureTermClsCap=" + ByteUtils.byteArray2HexString(pureTermClsCap) +
                '}';
    }
}
