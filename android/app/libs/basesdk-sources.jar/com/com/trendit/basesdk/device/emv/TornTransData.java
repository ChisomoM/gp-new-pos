package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * When application need support paypass torn transaction,Pls define the call back function of
 * onTornTransRecoverData in EMVTransListener,and transcaiton information will return
 * by the callback function to application,and application need to check the TornTransData
 * data.If the torn transaction is complete and the transaction is change ,the application need to
 * to make corresponding processing.
 */
public class TornTransData extends BaseParcelable implements Parcelable {
    /**
     * Authorize amount, for cash back, the amount required to include the amount of ulAmntOther.
     */
    @FieldNumber(1)
    private long amountAuth;
    /**
     * Other amount
     */
    @FieldNumber(2)
    private long amountOther;
    /**
     * Transaction type'9C', 0-Consumer/Services 1-Cash/Cash back
     */
    @FieldNumber(3)
    private int transType;
    /**
     * Transaction Date YYMMDD
     */
    @FieldNumber(4)
    private String transDate;
    /**
     * Transaction time HHMMSS
     */
    @FieldNumber(5)
    private String transTime;

    /**
     * Get the Authorize amount, for cash back
     *
     * @return Authorize amount
     */
    public long getAmountAuth() {
        return amountAuth;
    }

    /**
     * Set the Authorize amount, for cash back
     *
     * @param amountAuth Authorize amount
     */
    public void setAmountAuth(long amountAuth) {
        this.amountAuth = amountAuth;
    }

    /**
     * Get the Other amount
     *
     * @return Other amount
     */
    public long getAmountOther() {
        return amountOther;
    }

    /**
     * Set the Other amount
     *
     * @param amountOther Other amount
     */
    public void setAmountOther(long amountOther) {
        this.amountOther = amountOther;
    }

    /**
     * Get the Transaction type'9C', 0-Consumer/Services 1-Cash/Cash back
     *
     * @return Transaction type
     */
    public TransType getTransType() {
        return TransType.valueOf(transType);
    }

    /**
     * Set the Transaction type'9C', 0-Consumer/Services 1-Cash/Cash back
     *
     * @param transType Transaction type
     */
    public void setTransType(TransType transType) {
        this.transType = transType.getType();
    }

    /**
     * Get the Transaction Date YYMMDD
     *
     * @return Transaction Date YYMMDD
     */
    public String getTransDate() {
        return transDate;
    }

    /**
     * Set the Transaction Date YYMMDD
     *
     * @param transDate Transaction Date YYMMDD
     */
    public void setTransDate(String transDate) {
        this.transDate = transDate;
    }

    /**
     * Get the Transaction time HHMMSS
     *
     * @return Transaction time HHMMSS
     */
    public String getTransTime() {
        return transTime;
    }

    /**
     * Set the Transaction time HHMMSS
     *
     * @param transTime Transaction time HHMMSS
     */
    public void setTransTime(String transTime) {
        this.transTime = transTime;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public TornTransData() {
    }

    protected TornTransData(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<TornTransData> CREATOR = new Parcelable.Creator<TornTransData>() {
        @Override
        public TornTransData createFromParcel(Parcel source) {
            return new TornTransData(source);
        }

        @Override
        public TornTransData[] newArray(int size) {
            return new TornTransData[size];
        }
    };

    @Override
    public String toString() {
        return "TornTransData{" +
                "amountAuth=" + amountAuth +
                ", amountOther=" + amountOther +
                ", transType=" + transType +
                ", transDate='" + transDate + '\'' +
                ", transTime='" + transTime + '\'' +
                '}';
    }
}
