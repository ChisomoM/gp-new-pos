package com.trendit.basesdk.device.terminal;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * Terminal Info
 */
public class TerminalSpec extends BaseParcelable implements Parcelable {
    @FieldNumber(1)
    private String manufacturer;
    @FieldNumber(2)
    private String model;
    @FieldNumber(3)
    private String OSVersion;
    @FieldNumber(4)
    private String APILevel;
    @FieldNumber(5)
    private String serialNumber;
    @FieldNumber(6)
    private String moduleVersion;
    @FieldNumber(7)
    private int sdkVersion;

    /**
     * Return manufacturer name
     *
     * @return manufacturer name
     */
    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    /**
     * Return Terminal Name
     *
     * @return Terminal Name
     */
    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    /**
     * Return system version
     *
     * @return system version
     */
    public String getOSVersion() {
        return OSVersion;
    }

    public void setOSVersion(String OSVersion) {
        this.OSVersion = OSVersion;
    }

    /**
     * Return API version level
     *
     * @return API version level
     */
    public String getAPILevel() {
        return APILevel;
    }

    public void setAPILevel(String APILevel) {
        this.APILevel = APILevel;
    }

    /**
     * Get Terminal SN
     *
     * @return Terminal SN
     */
    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    /**
     * Return security chip version
     *
     * @return security chip version
     */
    public String getModuleVersion() {
        return moduleVersion;
    }

    public void setModuleVersion(String moduleVersion) {
        this.moduleVersion = moduleVersion;
    }

    /**
     * Return SDK version
     *
     * @return SDK version
     */
    public int getSdkVersion() {
        return sdkVersion;
    }

    public void setSdkVersion(int sdkVersion) {
        this.sdkVersion = sdkVersion;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public TerminalSpec() {
    }

    protected TerminalSpec(Parcel in) {
        readFromParcelable(in);
    }

    public static final Creator<TerminalSpec> CREATOR = new Creator<TerminalSpec>() {
        @Override
        public TerminalSpec createFromParcel(Parcel source) {
            return new TerminalSpec(source);
        }

        @Override
        public TerminalSpec[] newArray(int size) {
            return new TerminalSpec[size];
        }
    };

    @Override
    public String toString() {
        return "TerminalSpec{" +
                "manufacturer='" + manufacturer + '\'' +
                ", model='" + model + '\'' +
                ", OSVersion='" + OSVersion + '\'' +
                ", APILevel='" + APILevel + '\'' +
                ", serialNumber='" + serialNumber + '\'' +
                ", moduleVersion='" + moduleVersion + '\'' +
                ", sdkVersion=" + sdkVersion +
                '}';
    }
}
