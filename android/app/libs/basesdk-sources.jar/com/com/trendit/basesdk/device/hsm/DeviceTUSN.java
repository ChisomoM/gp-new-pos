package com.trendit.basesdk.device.hsm;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;


/**
 * Equipment serial number (can be used for content related to file 21)
 */
public class DeviceTUSN extends BaseParcelable implements Parcelable {

    @FieldNumber(1)
    private String tusn;
    @FieldNumber(2)
    private byte[] encryptFactor;


    /**
     * Obtain device hardware serial number
     *
     * @return Device hardware serial number
     */
    public String getTUSN() {
        return tusn;
    }

    /**
     * Set the device hardware serial number (third-party applications do not need to call)
     *
     * @param tusn Device hardware serial number
     */
    public void setTUSN(String tusn) {
        this.tusn = tusn;
    }

    /**
     * Obtaining encrypted factors
     *
     * @return Encrypted factor
     */
    public byte[] getEncryptFactor() {
        return encryptFactor;
    }

    /**
     * Set encryption factor
     *
     * @param encryptFactor Encrypted factor
     */
    public void setEncryptFactor(byte[] encryptFactor) {
        this.encryptFactor = encryptFactor;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public DeviceTUSN() {
    }

    protected DeviceTUSN(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<DeviceTUSN> CREATOR = new Parcelable.Creator<DeviceTUSN>() {
        @Override
        public DeviceTUSN createFromParcel(Parcel source) {
            return new DeviceTUSN(source);
        }

        @Override
        public DeviceTUSN[] newArray(int size) {
            return new DeviceTUSN[size];
        }
    };

    @Override
    public String toString() {
        return "DeviceTUSN{" +
                "tusn='" + tusn + '\'' +
                ", encryptFactor=" + ByteUtils.byteArray2HexString(encryptFactor) +
                '}';
    }
}
