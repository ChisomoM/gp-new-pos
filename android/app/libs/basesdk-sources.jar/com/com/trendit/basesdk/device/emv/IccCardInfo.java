package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * Icc Card track info
 */
public class IccCardInfo extends BaseParcelable implements Parcelable {
    @FieldNumber(1)
    private byte[] uid;
    @FieldNumber(2)
    private String cardNO;
    @FieldNumber(3)
    private String expiredDate;
    @FieldNumber(4)
    private byte[] track1;
    @FieldNumber(5)
    private byte[] track2;
    @FieldNumber(6)
    private byte[] track3;

    /**
     * Get the card uid
     *
     * @return uid
     */
    public byte[] getUid() {
        return uid;
    }

    public void setUid(byte[] uid) {
        this.uid = uid;
    }

    /**
     * Get the card no
     *
     * @return card no
     */
    public String getCardNO() {
        return cardNO;
    }

    public void setCardNO(String cardNO) {
        this.cardNO = cardNO;
    }

    /**
     * Get the card expired date
     *
     * @return expired date
     */
    public String getExpiredDate() {
        return expiredDate;
    }

    public void setExpiredDate(String expiredDate) {
        this.expiredDate = expiredDate;
    }

    /**
     * Get the card track1
     *
     * @return track1
     */
    public byte[] getTrack1() {
        return track1;
    }

    public void setTrack1(byte[] track1) {
        this.track1 = track1;
    }

    /**
     * Get the card track2
     *
     * @return track2
     */
    public byte[] getTrack2() {
        return track2;
    }

    public void setTrack2(byte[] track2) {
        this.track2 = track2;
    }

    /**
     * Get the card track3
     *
     * @return track3
     */
    public byte[] getTrack3() {
        return track3;
    }

    public void setTrack3(byte[] track3) {
        this.track3 = track3;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
       writeFromParcel(dest, flags);
    }

    public IccCardInfo() {
    }

    protected IccCardInfo(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<IccCardInfo> CREATOR = new Parcelable.Creator<IccCardInfo>() {
        @Override
        public IccCardInfo createFromParcel(Parcel source) {
            return new IccCardInfo(source);
        }

        @Override
        public IccCardInfo[] newArray(int size) {
            return new IccCardInfo[size];
        }
    };

    @Override
    public String toString() {
        return "IccCardInfo{" +
                "uid=" + ByteUtils.byteArray2HexString(uid) +
                ", cardNO='" + cardNO + '\'' +
                ", expiredDate='" + expiredDate + '\'' +
                ", track1=" + ByteUtils.byteArray2HexString(track1) +
                ", track2=" + ByteUtils.byteArray2HexString(track2) +
                ", track3=" + ByteUtils.byteArray2HexString(track3) +
                '}';
    }
}
