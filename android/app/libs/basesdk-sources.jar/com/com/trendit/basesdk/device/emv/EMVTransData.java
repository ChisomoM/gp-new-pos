package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * The Emv process parameter needs to be passed to the EMV kernel when conducting EMV transactions
 */
public class EMVTransData extends BaseParcelable implements Parcelable {

    public static final int Channel_Type_IC = 0;
    public static final int Channel_Type_RF = 1;

    @FieldNumber(1)
    private int channelType;
    @FieldNumber(2)
    private long amount;
    @FieldNumber(3)
    private long otherAmount;
    @FieldNumber(4)
    private int kernelID;
    @FieldNumber(5)
    private int transType;
    @FieldNumber(6)
    private int flow;
    @FieldNumber(7)
    private String transDate;
    @FieldNumber(8)
    private String transTime;
    @FieldNumber(9)
    private String traceNo;
    @FieldNumber(10)
    private byte[] fixAID;

    /**
     * get the channel type
     * {@link EMVTransData#Channel_Type_IC} {@link  EMVTransData#Channel_Type_RF}
     *
     * @return chanel type
     */
    public int getChannelType() {
        return channelType;
    }

    /**
     * set the channel type
     * {@link EMVTransData#Channel_Type_IC} {@link  EMVTransData#Channel_Type_RF}
     *
     * @param channelType type
     */
    public void setChannelType(int channelType) {
        this.channelType = channelType;
    }

    /**
     * Get the Authorize amount for cash back
     *
     * @return amount
     */
    public long getAmount() {
        return amount;
    }

    /**
     * Set the Authorize amount for cash back
     *
     * @param amount amount
     */
    public void setAmount(long amount) {
        this.amount = amount;
    }

    /**
     * Get the Other amount
     *
     * @return Other amount
     */
    public long getOtherAmount() {
        return otherAmount;
    }

    /**
     * Set the Other amount
     *
     * @param otherAmount Other amount
     */
    public void setOtherAmount(long otherAmount) {
        this.otherAmount = otherAmount;
    }

    /**
     * Get the kernel ID This value will refresh by kernel after application final select
     *
     * @return kernel ID
     */
    public KernelID getKernelID() {
        return KernelID.valueOf(this.kernelID);
    }

    /**
     * Set the kernel ID This value will refresh by kernel after application final select
     *
     * @param kernelID kernel ID
     */
    public void setKernelID(KernelID kernelID) {
        this.kernelID = kernelID.getId();
    }

    /**
     * Get the trans type
     *
     * @return trans type
     */
    public TransType getTransType() {
        return TransType.valueOf(this.transType);
    }

    /**
     * Set the trans type
     *
     * @param transType trans type
     */
    public void setTransType(TransType transType) {
        this.transType = transType.getType();
    }

    /**
     * Get the Trans Flow
     *
     * @return trans flow
     */
    public TransFlow getFlow() {
        return TransFlow.valueOf(flow);
    }

    /**
     * Set the Trans flow
     *
     * @param flow flow
     */
    public void setFlow(TransFlow flow) {
        this.flow = flow.getFlow();
    }

    /**
     * Get the trans date(YYMMDD)
     *
     * @return trans date
     */
    public String getTransDate() {
        return transDate;
    }

    /**
     * Set the trans date(YYMMDD)
     *
     * @param transDate trans date
     */
    public void setTransDate(String transDate) {
        this.transDate = transDate;
    }

    /**
     * Get the trans time (HHMMSS)
     *
     * @return time
     */
    public String getTransTime() {
        return transTime;
    }

    /**
     * Set the trans time (HHMMSS)
     *
     * @param transTime time
     */
    public void setTransTime(String transTime) {
        this.transTime = transTime;
    }

    /**
     * Get the '9F41' Transaction Sequence Counter (Refer to EMV Book 3)
     *
     * @return trace no
     */
    public String getTraceNo() {
        return traceNo;
    }

    /**
     * Set the '9F41' Transaction Sequence Counter (Refer to EMV Book 3)
     *
     * @param traceNo trace no
     */
    public void setTraceNo(String traceNo) {
        this.traceNo = traceNo;
    }

    /**
     * Get the specific aid select
     *
     * @return specific aid select
     */
    public byte[] getFixAID() {
        return fixAID;
    }

    /**
     * Set the specific aid select
     *
     * @param fixAID specific aid select
     */
    public void setFixAID(byte[] fixAID) {
        this.fixAID = fixAID;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public EMVTransData() {
    }

    protected EMVTransData(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<EMVTransData> CREATOR = new Parcelable.Creator<EMVTransData>() {
        @Override
        public EMVTransData createFromParcel(Parcel source) {
            return new EMVTransData(source);
        }

        @Override
        public EMVTransData[] newArray(int size) {
            return new EMVTransData[size];
        }
    };

    @Override
    public String toString() {
        return "EMVTransData{" +
                "channelType=" + channelType +
                ", amount=" + amount +
                ", otherAmount=" + otherAmount +
                ", kernelID=" + kernelID +
                ", transType=" + transType +
                ", flow=" + flow +
                ", transDate='" + transDate + '\'' +
                ", transTime='" + transTime + '\'' +
                ", traceNo='" + traceNo + '\'' +
                ", fixAID=" + ByteUtils.byteArray2HexString(fixAID) +
                '}';
    }
}
