package com.trendit.basesdk.device.serialport;

/**
 * <b>SerialPortDevice</b>Defined interfaces for serial devices。
 * <pre>
 * TerminalDevice device = POSDeviceManager.getInstance().getTerminalDevice();
 * </pre>
 * The caller cannot create the object through new
 */
public abstract class SerialPortDevice {

    /**
     * Open serial device
     *
     * @param device             The serial device that needs to be opened, such as：/dev/ttyxxx
     * @param baudrate           BAUD
     * @param supportFlowControl Does it support flow control
     * @return If the return value is greater than zero the return value is device fd, other failures，@see SerialPortConstants
     */
    public abstract int open(String device, int baudrate, boolean supportFlowControl);

    /**
     * Close serial device
     *
     * @param fd (The fd obtained when opening the device)
     * @return Close Results @see SerialPortConstants
     */
    public abstract int close(int fd);

    /**
     * Reset serial device
     *
     * @param fd (The fd obtained when opening the device)
     * @return result @see SerialPortConstants
     */
    public abstract int reset(int fd);

    /**
     * Write data to serial device
     *
     * @param fd   (The fd obtained when opening the device)
     * @param data the write data
     * @return If the return value is greater than zero the return value is the length written, otherwise it is the error code for @see SerialPortConstants
     */
    public abstract int write(int fd, byte[] data);

    /**
     * Read serial device
     *
     * @param fd         (The fd obtained when opening the device)
     * @param readMaxLen max read len
     * @param timeout    Time out, in ms
     * @return Serial port data read
     */
    public abstract byte[] read(int fd, int readMaxLen, int timeout);
}
