package com.trendit.basesdk.device.hsm;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Terminal safety detection status
 */
public enum PreventState implements Parcelable {
    /**
     * Terminal safety
     */
    TRANSFER_PREVENT_STATE_PASS,
    /**
     * The local information of the terminal does not exist
     */
    TRANSFER_PREVENT_STATE_LOCAL_INFO_NOT_EXIST,
    /**
     * Terminal local information validation failed
     */
    TRANSFER_PREVENT_STATE_LOCAL_INFO_VERIFY_FAILED,
    /**
     * The terminal public key does not exist
     */
    TRANSFER_PREVENT_STATE_PK_NOT_EXIST,
    /**
     * Terminal public key verification failed
     */
    TRANSFER_PREVENT_STATE_PK_VERIFY_FAILED,
    /**
     * Terminal random number verification failed
     */
    TRANSFER_PREVENT_STATE_RANDOM_VERIFY_FAILED,
    /**
     * Terminal security chip verification failed
     */
    TRANSFER_PREVENT_STATE_SP_VERIFY_FAILED,
    /**
     * Terminal serialization does not exist
     */
    TRANSFER_PREVENT_STATE_SN_NOT_EXIST,

    TRANSFER_PREVENT_STATE_SP_NOT_RESPONSE,

    TRANSFER_PREVENT_STATE_ID_NOT_RESPONSE,

    TRANSFER_PREVENT_STATE_EXCEPTION;

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(ordinal());
    }

    public static final Creator<PreventState> CREATOR = new Creator<PreventState>() {
        @Override
        public PreventState createFromParcel(Parcel parcel) {
            int ordinal = parcel.readInt();
            for (PreventState state : PreventState.values()) {
                if (state.ordinal() == ordinal) {
                    return state;
                }
            }
            return null;
        }

        @Override
        public PreventState[] newArray(int size) {
            return new PreventState[size];
        }
    };

}
