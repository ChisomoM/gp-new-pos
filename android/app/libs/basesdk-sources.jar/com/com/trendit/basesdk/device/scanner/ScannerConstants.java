package com.trendit.basesdk.device.scanner;

public class ScannerConstants {

    /**
     * timeout
     */
    public static final int READ_TIMEOUT = 0;

    /**
     * fail
     */
    public static final int READ_FAIL = 1;

    /**
     * cancellation
     */
    public static final int READ_CANCEL = 2;

    /**
     * Front Camera
     */
    public static final int FRONT = 0;
    /**
     * Back Camera
     */
    public static final int BACK = 1;
}
