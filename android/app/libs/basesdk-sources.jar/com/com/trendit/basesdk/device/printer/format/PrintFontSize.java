package com.trendit.basesdk.device.printer.format;

/**
 * Print Font Size
 */
public class PrintFontSize {

    /**
     * Extra small
     */
    public static final int FORMAT_FONT_SIZE_EXTRA_SMALL = 8;

    /**
     * Small
     */
    public static final int FORMAT_FONT_SIZE_SMALL = 16;

    /**
     * Medium
     */
    public static final int FORMAT_FONT_SIZE_MEDIUM = 24;

    /**
     * Large
     */
    public static final int FORMAT_FONT_SIZE_LARGE = 32;

    /**
     * Extra large
     */
    public static final int FORMAT_FONT_SIZE_EXTRA_LARGE = 40;

}
