package com.trendit.basesdk.device.hsm;

/**
 * <b>HSMDevice</b>Defined the interface for the security chip device
 * <pre>
 * HSMDevice hsmDevice = POSDeviceManager.getInstance().getHSMDevice();
 * </pre>
 * The caller cannot create the object through new
 */
public abstract class HSMDevice {

    /**
     * @return Terminal serial number
     */
    public abstract String getSN();

    /**
     * @return Customer customized terminal serial number
     */
    public abstract String getCSN();

    /**
     * Get hardware random numbers
     *
     * @param length random length
     * @return Generated Random Numbers
     */
    public abstract byte[] getRandom(int length);

    /**
     * @return Terminal safety detection status
     */
    public abstract PreventState getPreventState();

    /**
     * @return Terminal trigger information
     */
    public abstract TriggerInfo getTriggerInfo();

    /**
     * Terminal open trigger
     */
    public abstract void enableTrigger();

    /**
     * @return security chip version information
     */
    public abstract HSMVersion getVersion();

    /**
     * Get the machine hardware serial number (UnionPay No. 21 document)
     *
     * @param factor Encryption factor (for bank cards, take the last 6 digits of the card number and the last 6 digits of the QR code)
     * @return Encrypted hardware serial number
     */
    public abstract DeviceTUSN getDeviceTUSN(byte[] factor);
}
