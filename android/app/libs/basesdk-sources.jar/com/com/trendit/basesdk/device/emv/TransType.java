package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

public enum TransType implements Parcelable {

    TRANS_TYPE_PURCHASE(0x00),

    TRANS_TYPE_CASH(0x01),

    TRANS_TYPE_ADJUSTMENT(0x02),

    TRANS_TYPE_PURCHASE_WITH_CASHBACK(0x09),

    TRANS_TYPE_CASH_DISBURSEMENT(0x17),

    TRANS_TYPE_REFUND(0x20),

    TRANS_TYPE_BALANCE_INQUIRY(0x31),

    TRANS_TYPE_IGNORE(0xFF);

    private final int type;

    TransType(int type) {
        this.type = type;
    }

    public int getType() {
        return this.type;
    }

    public static TransType valueOf(int value) {
        TransType[] transTypes = TransType.values();
        for (TransType transType : transTypes) {
            if (transType.getType() == value) {
                return transType;
            }
        }
        return TRANS_TYPE_PURCHASE;
    }
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(ordinal());
    }

    public static final Parcelable.Creator<TransType> CREATOR = new Parcelable.Creator<TransType>() {
        @Override
        public TransType createFromParcel(Parcel parcel) {
            int ordinal = parcel.readInt();
            for (TransType transType : TransType.values()) {
                if (transType.ordinal() == ordinal) {
                    return transType;
                }
            }
            return null;
        }

        @Override
        public TransType[] newArray(int size) {
            return new TransType[size];
        }
    };
}
