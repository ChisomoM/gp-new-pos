package com.trendit.basesdk.device.terminal;


/**
 * <b>TerminalDevice</b>Defined the interface of Terminal
 * <pre>
 * TerminalDevice device = POSDeviceManager.getInstance().getTerminalDevice();
 * </pre>
 * The caller cannot create the object through new
 */
public abstract class TerminalDevice {

    /**
     * Obtain terminal related information
     *
     * @return terminal info
     * @see TerminalSpec
     */
    public abstract TerminalSpec getTerminalSpec();

    /**
     * Set device system time
     *
     * @param time time
     * @return Success or Failure
     */
    public abstract boolean setDeviceTime(long time);

    /**
     * Obtain device system time
     *
     * @return system time
     */
    public abstract long getDeviceTime();

    /**
     * Device restart
     *
     * @return reboot result
     */
    public abstract boolean reboot();

    /**
     * Device shutdown
     *
     * @return shutdown result
     */
    public abstract boolean shutdown();

    /**
     * Background installation
     *
     * @param filePath APK absolute path
     * @return Installation Results
     */
    public abstract boolean silentInstall(String filePath);

    /**
     * Background uninstallation
     *
     * @param packageName Package Name
     * @return Uninstall Results
     */
    public abstract boolean silentUninstall(String packageName);

    /**
     * Set whether the status bar and virtual buttons are available
     *
     * @param enable True - the status bar and virtual buttons can be used normally, false - the status bar and virtual buttons cannot be clicked
     */
    public abstract void setStatusBarEnable(boolean enable);

    /*
     *  Set system status bar status
     * public static final int STATUS_BAR_DISABLE_HOME = 0x00200000;
     * public static final int STATUS_BAR_DISABLE_BACK = 0x00400000;
     * public static final int STATUS_BAR_DISABLE_RECENT = 0x01000000;
     * public static final int STATUS_BAR_DISABLE_EXPAND = 0x00010000;
     * public static final int STATUS_BAR_DISABLE_NONE = 0x00000000;
     *
     * @param status status bar status you can use like this---"0x00200000 | 0x00400000"
     */
    public abstract void setStatusBarStatus(int status);

    /**
     * Set whether the pageIndicatorView in status bar show
     * @param enable True - the pageIndicatorView show,
     *               false - the pageIndicatorView hide
     */
    public abstract void updateStatusBarPageIndicatorState(boolean enable);

    /**
     * update pageIndicatorView data,
     * @param curPage curPageIndex will show in the pageIndicatorView,curPageIndex/totalPage
     * @param totalPage totalPage will show in the pageIndicatorView,curPageIndex/totalPage
     */
    public abstract void updateStatusBarPageIndicatorData(int curPage, int totalPage);
}
