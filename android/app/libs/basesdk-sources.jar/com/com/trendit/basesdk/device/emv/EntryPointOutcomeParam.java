package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

import java.util.Arrays;

/**
 * Outcome Parameter Set Information
 * More detailed information, please refer to < EMV C-2-Kernel-2 book >
 */
public class EntryPointOutcomeParam extends BaseParcelable implements Parcelable {

    @FieldNumber(1)
    private byte[] outcomeParSet;
    @FieldNumber(2)
    private byte status;
    @FieldNumber(3)
    private byte start;
    @FieldNumber(4)
    private byte CVM;
    @FieldNumber(5)
    private byte UIRequestOnOutPresent;
    @FieldNumber(6)
    private byte UIRequestOnRestartPresent;
    @FieldNumber(7)
    private byte DataRecordPresent;
    @FieldNumber(8)
    private byte DisDataPresent;
    @FieldNumber(9)
    private byte ReceiptInoutParameter;
    @FieldNumber(10)
    private byte AIPInoutParameter;
    @FieldNumber(11)
    private byte FieldOffInoutParameter;
    @FieldNumber(12)
    private byte[] RemovalTimeoutInoutParameter;
    @FieldNumber(13)
    private byte OnlineResDataInoutParameter;


    public EntryPointOutcomeParam() {

    }

    protected EntryPointOutcomeParam(Parcel in) {
        readFromParcelable(in);
    }

    public static final Creator<EntryPointOutcomeParam> CREATOR = new Creator<EntryPointOutcomeParam>() {
        @Override
        public EntryPointOutcomeParam createFromParcel(Parcel in) {
            return new EntryPointOutcomeParam(in);
        }

        @Override
        public EntryPointOutcomeParam[] newArray(int size) {
            return new EntryPointOutcomeParam[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        writeFromParcel(parcel, i);
    }

    /**
     * Get the Byte arrays of Outcome Parameter Set
     *
     * @return Byte arrays of Outcome Parameter Set
     */
    public byte[] getOutcomeParSet() {
        return outcomeParSet;
    }

    /**
     * Set the Byte arrays of Outcome Parameter Set
     *
     * @param outcomeParSet Byte arrays of Outcome Parameter Set
     */
    public void setOutcomeParSet(byte[] outcomeParSet) {
        this.outcomeParSet = outcomeParSet;
    }

    /**
     * Get the Status
     *
     * @return Status
     */
    public byte getStatus() {
        return status;
    }

    /**
     * Set the status
     *
     * @param status status
     */
    public void setStatus(byte status) {
        this.status = status;
    }

    /**
     * Get the start
     *
     * @return start
     */
    public byte getStart() {
        return start;
    }

    /**
     * Set the start
     *
     * @param start start
     */
    public void setStart(byte start) {
        this.start = start;
    }

    /**
     * Get the CVM
     *
     * @return CVM
     */
    public byte getCVM() {
        return CVM;
    }

    /**
     * Set the CVM
     *
     * @param CVM CVM
     */
    public void setCVM(byte CVM) {
        this.CVM = CVM;
    }

    /**
     * Get the User Interface Request on Outcome Present
     *
     * @return User Interface Request on Outcome Present
     */
    public byte getUIRequestOnOutPresent() {
        return UIRequestOnOutPresent;
    }

    /**
     * Set the User Interface Request on Outcome Present
     *
     * @param UIRequestOnOutPresent User Interface Request on Outcome Present
     */
    public void setUIRequestOnOutPresent(byte UIRequestOnOutPresent) {
        this.UIRequestOnOutPresent = UIRequestOnOutPresent;
    }

    /**
     * Get the User Interface Request on Restart Present
     *
     * @return User Interface Request on Restart Present
     */
    public byte getUIRequestOnRestartPresent() {
        return UIRequestOnRestartPresent;
    }

    /**
     * Set the User Interface Request on Restart Present
     *
     * @param UIRequestOnRestartPresent User Interface Request on Restart Present
     */
    public void setUIRequestOnRestartPresent(byte UIRequestOnRestartPresent) {
        this.UIRequestOnRestartPresent = UIRequestOnRestartPresent;
    }

    /**
     * Get the Data Record Present
     *
     * @return Data Record Present
     */
    public byte getDataRecordPresent() {
        return DataRecordPresent;
    }

    /**
     * Set the Data Record Present
     *
     * @param dataRecordPresent Data Record Present
     */
    public void setDataRecordPresent(byte dataRecordPresent) {
        DataRecordPresent = dataRecordPresent;
    }

    /**
     * Get the Discretionary Data Present
     *
     * @return Discretionary Data Present
     */
    public byte getDisDataPresent() {
        return DisDataPresent;
    }

    /**
     * Set the Discretionary Data Present
     *
     * @param disDataPresent Discretionary Data Present
     */
    public void setDisDataPresent(byte disDataPresent) {
        DisDataPresent = disDataPresent;
    }

    /**
     * Get the Receipt
     *
     * @return Receipt
     */
    public byte getReceiptInoutParameter() {
        return ReceiptInoutParameter;
    }

    /**
     * Set the Receipt
     *
     * @param receiptInoutParameter Receipt
     */
    public void setReceiptInoutParameter(byte receiptInoutParameter) {
        ReceiptInoutParameter = receiptInoutParameter;
    }

    /**
     * Get the Alternate Interface Preference
     *
     * @return Alternate Interface Preference
     */
    public byte getAIPInoutParameter() {
        return AIPInoutParameter;
    }

    /**
     * Set the Alternate Interface Preference
     *
     * @param AIPInoutParameter Alternate Interface Preference
     */
    public void setAIPInoutParameter(byte AIPInoutParameter) {
        this.AIPInoutParameter = AIPInoutParameter;
    }

    /**
     * Get the Field Off Request
     *
     * @return Field Off Request
     */
    public byte getFieldOffInoutParameter() {
        return FieldOffInoutParameter;
    }

    /**
     * Set the Field Off Request
     *
     * @param fieldOffInoutParameter Field Off Request
     */
    public void setFieldOffInoutParameter(byte fieldOffInoutParameter) {
        FieldOffInoutParameter = fieldOffInoutParameter;
    }

    /**
     * Get the Removal Timeout
     *
     * @return Removal Timeout
     */
    public byte[] getRemovalTimeoutInoutParameter() {
        return RemovalTimeoutInoutParameter;
    }

    /**
     * Set the Removal Timeout
     *
     * @param removalTimeoutInoutParameter Removal Timeout
     */
    public void setRemovalTimeoutInoutParameter(byte[] removalTimeoutInoutParameter) {
        RemovalTimeoutInoutParameter = removalTimeoutInoutParameter;
    }

    /**
     * Get the Online Response Data
     *
     * @return Online Response Data
     */
    public byte getOnlineResDataInoutParameter() {
        return OnlineResDataInoutParameter;
    }

    /**
     * Set the Online Response Data
     *
     * @param onlineResDataInoutParameter Online Response Data
     */
    public void setOnlineResDataInoutParameter(byte onlineResDataInoutParameter) {
        OnlineResDataInoutParameter = onlineResDataInoutParameter;
    }

    @Override
    public String toString() {
        return "EntryPointOutcomeParam{" +
                "outcomeParSet=" + ByteUtils.byteArray2HexString(outcomeParSet) +
                ", status=" + (status & 0xFF) +
                ", start=" + (start & 0xFF) +
                ", CVM=" + (CVM & 0xFF) +
                ", UIRequestOnOutPresent=" + (UIRequestOnOutPresent & 0xFF) +
                ", UIRequestOnRestartPresent=" + (UIRequestOnRestartPresent & 0xFF) +
                ", DataRecordPresent=" + (DataRecordPresent & 0xFF) +
                ", DisDataPresent=" + (DisDataPresent & 0xFF) +
                ", ReceiptInoutParameter=" + (ReceiptInoutParameter & 0xFF) +
                ", AIPInoutParameter=" + (AIPInoutParameter & 0xFF) +
                ", FieldOffInoutParameter=" + (FieldOffInoutParameter & 0xFF) +
                ", RemovalTimeoutInoutParameter=" + ByteUtils.byteArray2HexString(RemovalTimeoutInoutParameter) +
                ", OnlineResDataInoutParameter=" + (OnlineResDataInoutParameter & 0xFF) +
                '}';
    }
}
