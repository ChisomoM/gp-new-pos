package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

public class PINResult extends BaseParcelable implements Parcelable {

    /**
     * Online Pin
     */
    public static final int PIN_MODE_ONLINE = 0;

    /**
     * Plaintext offline pin.
     */
    public static final int PIN_MODE__OFFLINE_PLAIN = 1;

    /**
     * Encryption offline pin.
     */
    public static final int PIN_MODE__OFFLINE_ENCRYPT = 2;

    /**
     * PIN input result success
     */
    public static final int PIN_Input_Success = 1;

    /**
     * PIN input result cancel
     */
    public static final int PIN_Input_Cancel = -1;

    /**
     * PIN input result fail
     */
    public static final int PIN_Input_Failure = -2;

    /**
     * PIN input result timeout
     */
    public static final int PIN_Input_Timeout = -3;

    @FieldNumber(1)
    private int resultCode;
    @FieldNumber(2)
    private byte[] pinBlock;


    /**
     * Get the Input pin result code
     * {@link #PIN_Input_Success} {@link #PIN_Input_Cancel} {@link #PIN_Input_Failure} {@link #PIN_Input_Timeout}
     *
     * @return result code
     */
    public int getResultCode() {
        return resultCode;
    }

    /**
     * Set the Input pin result code
     *
     * @param resultCode {@link #PIN_Input_Success} {@link #PIN_Input_Cancel} {@link #PIN_Input_Failure} {@link #PIN_Input_Timeout}
     */
    public void setResultCode(int resultCode) {
        this.resultCode = resultCode;
    }

    /**
     * Get the online pinBlock
     *
     * @return online pinBlock
     */
    public byte[] getPinBlock() {
        return pinBlock;
    }

    /**
     * Set the online pinBlock
     *
     * @param pinBlock online pinBlock
     */
    public void setPinBlock(byte[] pinBlock) {
        this.pinBlock = pinBlock;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public PINResult() {
    }

    protected PINResult(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<PINResult> CREATOR = new Parcelable.Creator<PINResult>() {
        @Override
        public PINResult createFromParcel(Parcel source) {
            return new PINResult(source);
        }

        @Override
        public PINResult[] newArray(int size) {
            return new PINResult[size];
        }
    };

    @Override
    public String toString() {
        return "PINResult{" + "resultCode=" + resultCode + ", pinBlock=" + ByteUtils.byteArray2HexString(pinBlock) + '}';
    }
}
