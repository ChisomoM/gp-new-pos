package com.trendit.basesdk.device.icc;



public class ICCCardConstants {

    /**
     * Unknown state
     */
    public static final int ICC_STATUS_UNKNOWN = -1;

    /**
     * No card
     */
    public static final int ICC_STATUS_NO_CARD = 1;

    /**
     * Card present, but not powered on
     */
    public static final int ICC_STATUS_NO_POWERED = 2;

    /**
     * Card present and powered on
     */
    public static final int ICC_STATUS_POWERED = 3;

    /**
     * Unknown type
     */
    public static final int TYPE_UNKNOWN = -1;

    /**
     * T0 Protocol Card
     */
    public static final int PROTOCOL_T_0 = 0;

    /**
     * T1 Protocol Card
     */
    public static final int PROTOCOL_T_1 = 1;

}
