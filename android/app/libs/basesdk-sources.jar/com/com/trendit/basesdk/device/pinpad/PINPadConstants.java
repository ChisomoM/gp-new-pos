package com.trendit.basesdk.device.pinpad;


public class PINPadConstants {

    /**
     * Key Algorithm Type - Single DES
     */
    public static final int KEY_ALGORITHM_TYPE_DES_1 = 1;
    /**
     * Key Algorithm Type - Double DES
     */
    public static final int KEY_ALGORITHM_TYPE_DES_2 = 2;
    /**
     * Key Algorithm Type - Triple DES
     */
    public static final int KEY_ALGORITHM_TYPE_DES_3 = 3;

    /**
     * Key Algorithm Type - AES128
     */
    public static final int KEY_ALGORITHM_TYPE_AES_128 = 4;
    /**
     * Key Algorithm Type - AES192
     */
    public static final int KEY_ALGORITHM_TYPE_AES_192 = 5;
    /**
     * Key Algorithm Type - AES256
     */
    public static final int KEY_ALGORITHM_TYPE_AES_256 = 6;

    /**
     * The private key of the acquirer or POS operator, which is directly written by the acquirer or POS operator in a secure environment.
     * There is only one key per PED terminal, and its index number is from 0 to 0
     */
    public static final int KEY_TYPE_TLK = 1;
    /**
     * Master key
     */
    public static final int KEY_TYPE_TMK = 2;
    /**
     * Pin key, used to calculate pinblock
     */
    public static final int KEY_TYPE_TPK = 3;
    /**
     * MAC secret key, used to calculate MAC
     */
    public static final int KEY_TYPE_TAK = 4;
    /**
     * Track secret key, used to encrypt track information
     */
    public static final int KEY_TYPE_TDK = 5;

    /**
     * DUKPT secret key, decrypted with TLK during download, or directly issued in plaintext
     */
    public static final int KEY_TYPE_TIK = 6;

    /**
     * Not verified
     */
    public static final int CHECK_VALUE_MODE_NULL = 0x00;
    /**
     * The secret key performs DES encryption on 0x00 of 8 bytes, and the first 4 bytes of the generated ciphertext are the returned CheckValue
     */
    public static final int CHECK_VALUE_MODE_DES_0 = 0x10;
    /**
     * The secret key performs AES encryption on 16 bytes of 0x00, and the first 4 bytes of the generated ciphertext are the returned CheckValue
     */
    public static final int CHECK_VALUE_MODE_AES_0 = 0x20;
    /**
     * The dukpt secret key performs DES encryption on 0x00 of 8 bytes, and the first 4 bytes of the generated ciphertext are the returned CheckValue
     */
    public static final int CHECK_VALUE_MODE_DUKPT_DES_0 = 0x30;
    /**
     * The dukpt key performs AES encryption on 16 bytes of 0x00, and the first 4 bytes of the generated ciphertext are the returned CheckValue
     */
    public static final int CHECK_VALUE_MODE_DUKPT_AES_0 = 0x40;

    /**
     * Only for PED_ TDES_ TPK and PED_ TDES_ TIK
     */
    public static final int PINBLOCK_MODE_ISO_9564_0 = 0x00;
    /**
     * IC card offline plaintext PIN
     */
    public static final int PINBLOCK_MODE_ISO_9564_1 = 0x01;
    /**
     * IC card offline ciphertext PIN
     */
    public static final int PINBLOCK_MODE_ISO_9564_2 = 0x02;
    /**
     * Only for PED_ TDES_ TPK and PED_ TDES_ TIK
     */
    public static final int PINBLOCK_MODE_ISO_9564_3 = 0x03;
    /**
     * Only for PED_ AES_ TPK and PED_ AES_ TIK
     */
    public static final int PINBLOCK_MODE_ISO_9564_4 = 0x04;

    /**
     * Use the MAC key to perform TDES/AES encryption on BLOCK1,
     * perform bitwise XOR on the encryption result with BLOCK2,
     * and then use TAK to perform TDES/AES encryption,
     * sequentially obtaining an encryption result of 8 bytes (or 16 bytes)
     */
    public static final int MAC_MODE_X99 = 0x00;
    /**
     * Hypercom Fast Mode
     * perform bitwise XOR on BLOCK1 and BLOCK2,
     * and perform bitwise XOR on the XOR result and BLOCK3,
     * sequentially, to obtain an 8-byte (or 16-byte) XOR result.
     * Use TAK to perform TDES/AES encryption on this result
     */
    public static final int MAC_MODE_HFM = 0x01;
    /**
     * According to the ANSIX9.19 specification
     * BLOCK1 is encrypted using TAK for TDES/AES (only the first 8 bytes (or 16 bytes) of keys are taken),
     * and the encryption result is XOR bit by bit with BLOCK2, followed by TAK for DES encryption.
     * The encryption result is obtained in sequence of 8 bytes (or 16 bytes) until the last time TDES/AES encryption is used
     */
    public static final int MAC_MODE_X919 = 0x02;
    public static final int MAC_MODE_TDES_ECB = 0x03;
    public static final int MAC_MODE_AES_ECB = 0x04;

    /**
     * Use standard algorithms to disperse PINblock encryption keys, and AES DUKPTK uses ANSI X9.24 for dispersion.
     */
    public static final int DUKPT_AES_DERIVE_KEY_TYPE_DES2 = 0;
    public static final int DUKPT_AES_DERIVE_KEY_TYPE_DES3 = 1;
    public static final int DUKPT_AES_DERIVE_KEY_TYPE_AES128 = 2;
    public static final int DUKPT_AES_DERIVE_KEY_TYPE_AES192 = 3;
    public static final int DUKPT_AES_DERIVE_KEY_TYPE_AES256 = 4;

    /**
     * aes dukpt Key usage, please refer to the ANSI X9.24 specification document for more details
     */
    public static final int DUKPT_AES_USAGE_Key_Encryption_Key = 0x00;
    public static final int DUKPT_AES_USAGE_PIN_Encryption = 0x01;
    public static final int DUKPT_AES_USAGE_Message_Authentication_generation = 0x02;
    public static final int DUKPT_AES_USAGE_Message_Authentication_verification = 0x03;
    public static final int DUKPT_AES_USAGE_Message_Authentication_both_ways = 0x04;
    public static final int DUKPT_AES_USAGE_Data_Encryption_encrypt = 0x05;
    public static final int DUKPT_AES_USAGE_Data_Encryption_decrypt = 0x06;
    public static final int DUKPT_AES_USAGE_Data_Encryption_both_ways = 0x07;
    public static final int DUKPT_AES_USAGE_Key_Derivation = 0x08;
    public static final int DUKPT_AES_USAGE_Key_Derivation_Initial_Key = 0x09;

    /**
     * Des dukpt Key usage, please refer to the ANSI X9.24 specification document for more details
     */
    public static final int DUKPT_DES_USAGE_PIN_Encryption = 0x00;
    public static final int DUKPT_DES_USAGE_Message_Authentication_both_ways = 0x01;
    public static final int DUKPT_DES_USAGE_Message_Authentication_verification = 0x02;
    public static final int DUKPT_DES_USAGE_Data_Encryption_encrypt = 0x03;


    /**
     * No keys read
     */
    public static final byte KEYCODE_NULL = 0;
    /**
     * Key Cancel
     */
    public static final byte KEYCODE_CANCEL = 1;

    /**
     * Key Clear
     */
    public static final byte KEYCODE_CLEAR = 2;

    /**
     * Key Confirm
     */
    public static final byte KEYCODE_CONFIRM = 3;

    /**
     * Key 0-9
     */
    public static final byte KEYCODE_STAR = 4;

    /**
     * Press the confirm key to skip entering the password
     */
    public static final byte KEYCODE_BY_PASS_PIN = 5;

    /**
     * SUCCESS
     */
    public static final int RESULT_SUCCESS = 1;

    /**
     * CANCEL
     */
    public static final int RESULT_CANCEL = 2;

    /**
     * Pass to input password
     */
    public static final int RESULT_BY_PASS = 3;

    /**
     * ERROR
     */
    public static final int RESULT_GENERAL_ERROR = -3;

    /**
     * TIMEOUT
     */
    public static final int RESULT_ERR_TIMEOUT = -4;

    /**
     * ERROR PARAM
     */
    public static final int RESULT_ERR_PARAM = -5;


}
