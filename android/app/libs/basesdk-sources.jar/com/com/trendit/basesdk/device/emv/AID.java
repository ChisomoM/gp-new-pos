package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * application identifier；AID
 * It consists of a registered application providing a trademark (RID) and a special application identifier extension (Pix).
 * The AID parameters are stored in a file and will not be lost when the application is restarted.
 */
public class AID extends BaseParcelable implements Parcelable {
    /**
     * Pls refer to {enum TransType}
     */
    @FieldNumber(1)
    private int transType;
    /**
     * Application ID
     */
    @FieldNumber(2)
    private byte[] aid;
    /**
     * Application Selection Indicator if true, fullMatch else partMatch
     */
    @FieldNumber(3)
    private boolean fullMatch;
    /**
     * terminal application version
     */
    @FieldNumber(4)
    private byte[] appVerNum;
    /**
     * Terminal action code – default (It must be set if acquirer provides it.)
     */
    @FieldNumber(5)
    private byte[] tacDefault;
    /**
     * Terminal action code – online (It must be set if acquirer provides it.)
     */
    @FieldNumber(6)
    private byte[] tacOnline;
    /**
     * Terminal action code – denial (It must be set if acquirer provides it.)
     */
    @FieldNumber(7)
    private byte[] tacDecline;
    /**
     * Floor limit (provided by acquirer) (Refer to the risk management in EMV specification.)
     */
    @FieldNumber(8)
    private byte[] floorLimit;
    /**
     * Threshold (provided by acquirer) (Refer to the risk management in EMV specification)
     */
    @FieldNumber(9)
    private byte[] threshold;

    /**
     * Max target percent(0 – 99) (provided by acquirer) (Refer to the risk management in EMV specification.)
     */
    @FieldNumber(10)
    private int maxTargetPercent;

    /**
     * Target percent (0 – 99) (provided by acquirer) (Refer to the risk management in EMV specification.)
     */
    @FieldNumber(11)
    private int targetPercent;
    /**
     * Terminal default DDOL (example: “\x9F\x37\x04”) (It must be set if acquirer provides it.)
     */
    @FieldNumber(12)
    private byte[] termDDOL;
    /**
     * For the online only or offline only terminal , perform random transaction selection or not (1: perform, 0 : not perform)
     */
    @FieldNumber(13)
    private boolean randomTransSelect;
    /**
     * For the online only terminal , perform velocity check  or not (1 : perform, 0 not perform)
     */
    @FieldNumber(14)
    private boolean velocityCheck;

    /**
     * Reader contactless Param(when kernel support pre-processing),The default setting for this check shall be disabled
     */
    @FieldNumber(15)
    private boolean supportStatusCheck;
    /**
     * Reader contactless Param(when kernel support pre-processing) (refer to pre-processing in VCPS specification)
     */
    @FieldNumber(16)
    private boolean allowZeroAmountCheck;
    /**
     * Reader CVM Required Limit(refer to pre-processing in VCPS specification)
     */
    @FieldNumber(17)
    private byte[] cvmRequiredLimit;
    /**
     * Reader Contactless Transaction Limit (refer to pre-processing in VCPS specification)
     */
    @FieldNumber(18)
    private byte[] contactlessTransactionLimit;
    /**
     * Reader Contactless Floor Limit (refer to pre-processing in VCPS specification)
     */
    @FieldNumber(19)
    private byte[] contactlessFloorLimit;
    /**
     * Risk management data
     */
    @FieldNumber(20)
    private byte[] riskManData;

    /**
     * Allow offline transactions with an amount of 0
     */
    @FieldNumber(21)
    private boolean allowZeroAmountOfflineTrans;

    /**
     * get the aid trans type
     *
     * @return {@link TransType}
     */
    public TransType getTransType() {
        return TransType.valueOf(transType);
    }

    /**
     * set aid trans type
     * Examples:TRANS_TYPE_PURCHASE
     *
     * @param transType {@link TransType}
     */
    public void setTransType(TransType transType) {
        this.transType = transType.getType();
    }

    /**
     * get the Application ID
     *
     * @return Application ID
     */
    public byte[] getAid() {
        return aid;
    }

    /**
     * set the Application ID
     *
     * @param aid Application ID, The length of AID [5-16], Examples:{0xA0, 0x00, 0x00, 0x00, 0x04, 0x10, 0x10, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
     */
    public void setAid(byte[] aid) {
        this.aid = aid;
    }

    /**
     * get the Application Selection Indicator
     *
     * @return Application Selection Indicator, if true full match else part match
     */
    public boolean isFullMatch() {
        return fullMatch;
    }

    /**
     * set the Application Selection Indicator
     *
     * @param fullMatch is true full match else part match.
     */
    public void setFullMatch(boolean fullMatch) {
        this.fullMatch = fullMatch;
    }

    /**
     * get the terminal application version
     *
     * @return terminal application version
     */
    public byte[] getAppVerNum() {
        return appVerNum;
    }

    /**
     * set the terminal application version
     *
     * @param appVerNum application version, the length of version [2], Examples: {0x00, 0x02};
     */
    public void setAppVerNum(byte[] appVerNum) {
        this.appVerNum = appVerNum;
    }

    /**
     * get the Terminal action code – default
     *
     * @return Terminal action code
     */
    public byte[] getTacDefault() {
        return tacDefault;
    }

    /**
     * set the Terminal action code – default(It must be set if acquirer provides it.)
     *
     * @param tacDefault Terminal action code, the length of tac default is [5], Examples:{0x00, 0x00, 0x00, 0x00, 0x00};
     */
    public void setTacDefault(byte[] tacDefault) {
        this.tacDefault = tacDefault;
    }

    /**
     * get the Terminal action code – online
     *
     * @return Terminal action code
     */
    public byte[] getTacOnline() {
        return tacOnline;
    }

    /**
     * set the Terminal action code -online (It must be set if acquirer provides it.)
     *
     * @param tacOnline Terminal action code, the length of tac online is [5], Examples:{0x00, 0x00, 0x00, 0x00, 0x00};
     */
    public void setTacOnline(byte[] tacOnline) {
        this.tacOnline = tacOnline;
    }

    /**
     * get the Terminal action code – denial
     *
     * @return Terminal action code – denial
     */
    public byte[] getTacDecline() {
        return tacDecline;
    }

    /**
     * set the Terminal action code – denial ((It must be set if acquirer provides it. )
     *
     * @param tacDecline Terminal action code – denial , the length of tac decline is [5], Examples:{0x00, 0x00, 0x00, 0x00, 0x00};
     */
    public void setTacDecline(byte[] tacDecline) {
        this.tacDecline = tacDecline;
    }

    /**
     * get the Floor limit (provided by acquirer)
     *
     * @return Floor limit (provided by acquirer)
     */
    public byte[] getFloorLimit() {
        return floorLimit;
    }

    /**
     * set Floor limit (provided by acquirer)(Refer to the risk management in EMV specification.)
     *
     * @param floorLimit Floor limit the length of floor limit is [4],Examples:{0x00, 0x00, 0x00, 0x00}
     */
    public void setFloorLimit(byte[] floorLimit) {
        this.floorLimit = floorLimit;
    }

    /**
     * get the Threshold
     *
     * @return Threshold
     */
    public byte[] getThreshold() {
        return threshold;
    }

    /**
     * set the Threshold (provided by acquirer) (Refer to the risk management in EMV specification)
     *
     * @param threshold Threshold, the length of Threshold is [4], Examples:{0x00, 0x00, 0x00, 0x00}
     */
    public void setThreshold(byte[] threshold) {
        this.threshold = threshold;
    }

    /**
     * get the Max target percent(0 – 99) (provided by acquirer)
     *
     * @return Max target percent
     */
    public int getMaxTargetPercent() {
        return maxTargetPercent;
    }

    /**
     * set the Max target percent(0 – 99) (provided by acquirer, Refer to the risk management in EMV specification)
     *
     * @param maxTargetPercent (0 – 99)
     */
    public void setMaxTargetPercent(int maxTargetPercent) {
        this.maxTargetPercent = maxTargetPercent;
    }

    /**
     * get the Target percent
     *
     * @return percent(0 - 99)
     */
    public int getTargetPercent() {
        return targetPercent;
    }

    /**
     * set the Target percent (0 – 99) (provided by acquirer) (Refer to the risk management in EMV specification.)
     *
     * @param targetPercent (0-99)
     */
    public void setTargetPercent(int targetPercent) {
        this.targetPercent = targetPercent;
    }

    /**
     * get the Terminal default DDOL
     *
     * @return DDOL
     */
    public byte[] getTermDDOL() {
        return termDDOL;
    }

    /**
     * set the Terminal default DDOL (It must be set if acquirer provides it.)
     *
     * @param termDDOL Examples:“\x9F\x37\x04”, max len is 128
     */
    public void setTermDDOL(byte[] termDDOL) {
        this.termDDOL = termDDOL;
    }

    /**
     * Get the random trans select
     *
     * @return transSelect
     */
    public boolean isRandomTransSelect() {
        return randomTransSelect;
    }

    /**
     * Set the online only or offline only terminal , perform random transaction selection or not
     *
     * @param randomTransSelect (true: perform, false :not perform)
     */
    public void setRandomTransSelect(boolean randomTransSelect) {
        this.randomTransSelect = randomTransSelect;
    }

    /**
     * Get the velocity check
     *
     * @return the velocity check
     */
    public boolean isVelocityCheck() {
        return velocityCheck;
    }

    /**
     * Set the online only terminal , perform velocity check or not
     *
     * @param velocityCheck (true : perform, false not perform)
     */
    public void setVelocityCheck(boolean velocityCheck) {
        this.velocityCheck = velocityCheck;
    }

    /**
     * Velocity Checking?
     *
     * @return support status check
     */
    public boolean isSupportStatusCheck() {
        return supportStatusCheck;
    }

    /**
     * Reader contactless Param(when kernel support pre-processing),The default setting for this check shall be disabled
     * <p>
     * (refer to pre-processing in VCPS specification)
     *
     * @param supportStatusCheck (true : Velocity Checking, false not Checking)
     */
    public void setSupportStatusCheck(boolean supportStatusCheck) {
        this.supportStatusCheck = supportStatusCheck;
    }

    /**
     * Get the Reader contactless Param(when kernel support pre-processing)
     *
     * @return allow zero amount check
     */
    public boolean isAllowZeroAmountCheck() {
        return allowZeroAmountCheck;
    }

    /**
     * Set the Reader contactless Param(when kernel support pre-processing) (refer to pre-processing in VCPS specification)
     *
     * @param allowZeroAmountCheck (true : allow, false not allow)
     */
    public void setAllowZeroAmountCheck(boolean allowZeroAmountCheck) {
        this.allowZeroAmountCheck = allowZeroAmountCheck;
    }

    /**
     * Get the Reader CVM Required Limit (refer to pre-processing in VCPS specification)
     *
     * @return CVM Required Limit
     */
    public byte[] getCvmRequiredLimit() {
        return cvmRequiredLimit;
    }

    /**
     * Set the Reader CVM Required Limit (refer to pre-processing in VCPS specification)
     *
     * @param cvmRequiredLimit Cvm Required limit the length of limit is [6],Examples:{0x00, 0x00, 0x00, 0x00, 0x10, 0x00};
     */
    public void setCvmRequiredLimit(byte[] cvmRequiredLimit) {
        this.cvmRequiredLimit = cvmRequiredLimit;
    }

    /**
     * Get the Reader Contactless Transaction Limit (refer to pre-processing in VCPS specification)
     *
     * @return Transaction Limit
     */
    public byte[] getContactlessTransactionLimit() {
        return contactlessTransactionLimit;
    }

    /**
     * Set the Reader Contactless Transaction Limit (refer to pre-processing in VCPS specification)
     *
     * @param contactlessTransactionLimit the limit length is [6], Examples:{0x00, 0x00, 0x00, 0x03, 0x00, 0x00};
     */
    public void setContactlessTransactionLimit(byte[] contactlessTransactionLimit) {
        this.contactlessTransactionLimit = contactlessTransactionLimit;
    }

    /**
     * Get the Reader Contactless Floor Limit (refer to pre-processing in VCPS specification)
     *
     * @return Floor Limit
     */
    public byte[] getContactlessFloorLimit() {
        return contactlessFloorLimit;
    }

    /**
     * Set the Reader Contactless Floor Limit (refer to pre-processing in VCPS specification)
     *
     * @param contactlessFloorLimit the limit length is [6], Examples:{0x00, 0x00, 0x00, 0x01, 0x00, 0x00};
     */
    public void setContactlessFloorLimit(byte[] contactlessFloorLimit) {
        this.contactlessFloorLimit = contactlessFloorLimit;
    }

    /**
     * Get the Risk management data
     *
     * @return Risk management data
     */
    public byte[] getRiskManData() {
        return riskManData;
    }

    /**
     * Set the Risk management data
     *
     * @param riskManData the data length is [8], Examples:{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}, or set null;
     */
    public void setRiskManData(byte[] riskManData) {
        this.riskManData = riskManData;
    }

    /**
     *  Get whether offline transactions with an amount of 0 are allowed
     * @return If true, allowed, otherwise not allowed
     */
    public boolean isAllowZeroAmountOfflineTrans() {
        return allowZeroAmountOfflineTrans;
    }

    /**
     * Set whether offline transactions with an amount of 0 are allowed
     * @param allowZeroAmountOfflineTrans If true, allowed, otherwise not allowed
     */
    public void setAllowZeroAmountOfflineTrans(boolean allowZeroAmountOfflineTrans) {
        this.allowZeroAmountOfflineTrans = allowZeroAmountOfflineTrans;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public AID() {
    }

    protected AID(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<AID> CREATOR = new Parcelable.Creator<AID>() {
        @Override
        public AID createFromParcel(Parcel source) {
            return new AID(source);
        }

        @Override
        public AID[] newArray(int size) {
            return new AID[size];
        }
    };


    @Override
    public String toString() {
        return "AID{" +
                "transType=" + transType +
                ", aid=" + ByteUtils.byteArray2HexString(aid) +
                ", fullMatch=" + fullMatch +
                ", appVerNum=" + ByteUtils.byteArray2HexString(appVerNum) +
                ", tacDefault=" + ByteUtils.byteArray2HexString(tacDefault) +
                ", tacOnline=" + ByteUtils.byteArray2HexString(tacOnline) +
                ", tacDecline=" + ByteUtils.byteArray2HexString(tacDecline) +
                ", floorLimit=" + ByteUtils.byteArray2HexString(floorLimit) +
                ", threshold=" + ByteUtils.byteArray2HexString(threshold) +
                ", maxTargetPercent=" + maxTargetPercent +
                ", targetPercent=" + targetPercent +
                ", termDDOL=" + ByteUtils.byteArray2HexString(termDDOL) +
                ", randomTransSelect=" + randomTransSelect +
                ", velocityCheck=" + velocityCheck +
                ", supportStatusCheck=" + supportStatusCheck +
                ", allowZeroAmountCheck=" + allowZeroAmountCheck +
                ", cvmRequiredLimit=" + ByteUtils.byteArray2HexString(cvmRequiredLimit) +
                ", contactlessTransactionLimit=" + ByteUtils.byteArray2HexString(contactlessTransactionLimit) +
                ", contactlessFloorLimit=" + ByteUtils.byteArray2HexString(contactlessFloorLimit) +
                ", riskManData=" + ByteUtils.byteArray2HexString(riskManData) +
                ", allowZeroAmountOfflineTrans=" + allowZeroAmountOfflineTrans +
                '}';
    }
}
