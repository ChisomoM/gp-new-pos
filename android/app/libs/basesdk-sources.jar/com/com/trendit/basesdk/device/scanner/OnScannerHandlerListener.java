package com.trendit.basesdk.device.scanner;

/**
 * Scan code callback
 */
public abstract class OnScannerHandlerListener {
    /**
     * Callback for successful code scanning
     *
     * @param barcode code content（barCode content or qrcode content）
     */
    public abstract void onScanResult(String barcode);

    /**
     * Scan code ended (or no code data was read within the timeout period)
     *
     * @param code {@link ScannerConstants#READ_TIMEOUT} {@link ScannerConstants#READ_FAIL} {@link ScannerConstants#READ_CANCEL}
     */
    public abstract void onError(int code);
}
