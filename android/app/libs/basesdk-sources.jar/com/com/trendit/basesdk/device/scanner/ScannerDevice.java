package com.trendit.basesdk.device.scanner;

/**
 * <b>ScannerDevice</b>Defined interfaces for scanning devices
 * <pre>
 * ScannerDevice device = POSDeviceManager.getInstance().getScannerDevice();
 * </pre>
 * The caller cannot create the object through new
 */
public abstract class ScannerDevice {

    /**
     * Start scanning code
     *
     * @param scanType Scan Code Type：{@link ScannerConstants#BACK}{@link ScannerConstants#FRONT}
     * @param timeout  Time out, in ms
     * @param listener Scan code callback
     */
    public abstract void startScan(int scanType, long timeout, final OnScannerHandlerListener listener);

    /**
     * Stop scanning code
     */
    public abstract void stopScan();

}
