package com.trendit.basesdk.device.picc;

import com.trendit.basesdk.card.CPUCard;
import com.trendit.basesdk.card.MifareCard;

/**
 * <b>PICCCardDevice</b>Defined the interface of PICC devices
 * <pre>
 * PICCCardDevice device = POSDeviceManager.getInstance().getPICCCardDevice();
 * </pre>
 * The caller cannot create the object through new
 */
public abstract class PICCCardDevice {

    /**
     * Detecting picc cards
     *
     * @param listener Card search callback
     * @param timeout  Time out (milliseconds)
     */
    public abstract void listenForCard(final OnPICCCardHandleListener listener, int timeout);


    /**
     * Detect picc card movement
     *
     * @param listener Card search callback
     * @param timeout  Time out (milliseconds)
     */
    public abstract void listenForCardAbsent(final OnPICCCardAbsentHandleListener listener, int timeout);

    /**
     * Does the rf card exist
     *
     * @return true or false
     */
    public abstract boolean isCardExist();

    /**
     * Cancel search card
     */
    public abstract void cancel();

    /**
     * Get CPU card operation object
     *
     * @return cpu card operation object
     * @see CPUCard
     */
    public abstract CPUCard getCPUCard();


    /**
     * Get Mifare card operation object
     *
     * @return Mifare card operation object
     * @see MifareCard
     */
    public abstract MifareCard getMifareCard();

}
