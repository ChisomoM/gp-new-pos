package com.trendit.basesdk.card;


import com.trendit.basesdk.device.picc.PICCCardConstants;
import com.trendit.basesdk.device.icc.ICCCardConstants;

/**
 * <b>CPUCard</b>Defined the interface for CPUCard operations.
 * <pre>
 * CPUCard card = POSDeviceManager.getInstance().getPICCCardDevice().getCPUCardHandler();
 * CPUCard card = POSDeviceManager.getInstance().getICCCardDevice().getCPUCardHandler();
 * </pre>
 */
public abstract class CPUCard {

    /**
     * Connect the card and return the ATR information of the card.
     * <p>
     *
     * @return ATR information of the card
     */
    public abstract ATR connect();


    /**
     * Disconnect the card.
     */
    public abstract void disconnect();


    /**
     * Transfer information between the CPU card and the CPU card reader.
     * <p> APDU--ApplicationProtocolDataUnit--Application protocol data unit is the information unit transmitted between smart cards and smart card readers
     * <p> If card selection, wake-up, and other operations are required before sending commands, they will be automatically implemented by the bottom layer.
     * <p> If the connection with the card reader is disconnected, the APDU command cannot be executed.
     *
     * @param apdu apdu data in
     * @return apdu data out
     */
    public abstract byte[] transmit(byte[] apdu);


    /**
     * Return the ID of the card
     * <p>
     *
     * @return Byte stream of card ID
     */
    public abstract byte[] getID();


    /**
     * Returns a constant that represents the current card slot and card communication protocol
     * <p>
     * This method is a synchronous method. When a card exists in the card slot and is successfully opened, the card object can be read at any time.
     * {@link PICCCardConstants#PROTOCOL_RFCARD_TYPE_A} {@link PICCCardConstants#PROTOCOL_RFCARD_TYPE_B}
     * {@link ICCCardConstants#PROTOCOL_T_0} {@link ICCCardConstants#PROTOCOL_T_1}
     * <p>
     *
     * @return Constant for card communication protocol
     */
    public abstract int getProtocol();

    /**
     * Returns the status of the card operation result object
     * {@link CardConstants}
     *
     * @return card status
     */
    public abstract int getCardStatus();
}
