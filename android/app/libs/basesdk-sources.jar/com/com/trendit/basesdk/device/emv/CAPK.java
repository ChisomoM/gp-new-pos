package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * Public key parameters
 * The CAPK parameters are stored in a file and will not be lost when the application is restarted.
 */
public class CAPK extends BaseParcelable implements Parcelable {
    /**
     * Registered Application Provider Identifier
     */
    @FieldNumber(1)
    private byte[] rid;
    /**
     * key index
     */
    @FieldNumber(2)
    private byte capkIndex;
    /**
     * HASH arithmetic index
     */
    @FieldNumber(3)
    private byte hashIndex;
    /**
     * RSA arithmetic index
     */
    @FieldNumber(4)
    private byte arithIndex;
    /**
     * module
     */
    @FieldNumber(5)
    private byte[] module;
    /**
     * exponent ("\x03" or "\x01\x00\x01")
     */
    @FieldNumber(6)
    private byte[] exponent;
    /**
     * key check sum
     */
    @FieldNumber(7)
    private byte[] checkSum;
    /**
     * the expire date of the key (format : YYYYMMDD)
     */
    @FieldNumber(8)
    private String expireDate;


    /**
     * Get the Registered Application Provider Identifier
     *
     * @return Registered Application Provider Identifier
     */
    public byte[] getRid() {
        return rid;
    }

    /**
     * Set the Registered Application Provider Identifier
     *
     * @param rid the rid len is [5] Samples:{0xA0, 0x00, 0x00, 0x03, 0x33};
     */
    public void setRid(byte[] rid) {
        this.rid = rid;
    }

    /**
     * Get the capk key index
     *
     * @return key index
     */
    public byte getCapkIndex() {
        return capkIndex;
    }

    /**
     * Set the capk key index
     *
     * @param capkIndex key index
     */
    public void setCapkIndex(byte capkIndex) {
        this.capkIndex = capkIndex;
    }

    /**
     * Get the capk hash arithmetic index
     *
     * @return hash index
     */
    public byte getHashIndex() {
        return hashIndex;
    }

    /**
     * Set the capk hash arithmetic index
     *
     * @param hashIndex hash index
     */
    public void setHashIndex(byte hashIndex) {
        this.hashIndex = hashIndex;
    }

    /**
     * Get the capk RSA arithmetic index
     *
     * @return RSA arithmetic index
     */
    public byte getArithIndex() {
        return arithIndex;
    }

    /**
     * Set the capk RSA arithmetic index
     *
     * @param arithIndex capk RSA arithmetic index
     */
    public void setArithIndex(byte arithIndex) {
        this.arithIndex = arithIndex;
    }

    /**
     * Get the capk RSA module
     *
     * @return RSA module
     */
    public byte[] getModule() {
        return module;
    }

    /**
     * Set the capk RSA module
     *
     * @param module the module max len is [248]
     */
    public void setModule(byte[] module) {
        this.module = module;
    }

    /**
     * Get the capk RSA exponent
     *
     * @return exponent
     */
    public byte[] getExponent() {
        return exponent;
    }

    /**
     * Set the capk RSA exponent
     *
     * @param exponent {0x03} or {0x01, 0x00, 0x01}
     */
    public void setExponent(byte[] exponent) {
        this.exponent = exponent;
    }

    /**
     * Get the capk key check sum
     *
     * @return key check sum
     */
    public byte[] getCheckSum() {
        return checkSum;
    }

    /**
     * Set the capk key check sum
     *
     * @param checkSum max len is [20]
     */
    public void setCheckSum(byte[] checkSum) {
        this.checkSum = checkSum;
    }

    /**
     * Get the capk expire date
     *
     * @return expire date
     */
    public String getExpireDate() {
        return expireDate;
    }

    /**
     * Set the capk expire date
     *
     * @param expireDate (format : YYYYMMDD)
     */
    public void setExpireDate(String expireDate) {
        this.expireDate = expireDate;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public CAPK() {
    }

    protected CAPK(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<CAPK> CREATOR = new Parcelable.Creator<CAPK>() {
        @Override
        public CAPK createFromParcel(Parcel source) {
            return new CAPK(source);
        }

        @Override
        public CAPK[] newArray(int size) {
            return new CAPK[size];
        }
    };

    @Override
    public String toString() {
        return "CAPK{" +
                "rid=" + ByteUtils.byteArray2HexString(rid) +
                ", capkIndex=" + (capkIndex & 0xFF) +
                ", hashIndex=" + (hashIndex & 0xFF) +
                ", arithIndex=" + (arithIndex & 0xFF) +
                ", module=" + ByteUtils.byteArray2HexString(module) +
                ", exponent=" + ByteUtils.byteArray2HexString(exponent) +
                ", checkSum=" + ByteUtils.byteArray2HexString(checkSum) +
                ", expireDate='" + expireDate + '\'' +
                '}';
    }
}
