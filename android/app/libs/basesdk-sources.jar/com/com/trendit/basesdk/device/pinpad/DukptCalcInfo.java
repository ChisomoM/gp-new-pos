package com.trendit.basesdk.device.pinpad;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

import java.util.Arrays;

/**
 * dukpt calc result
 */
public class DukptCalcInfo extends BaseParcelable implements Parcelable {
    @FieldNumber(1)
    private byte[] data;
    @FieldNumber(2)
    private byte[] ksn;


    /**
     * @param data calc result
     * @param ksn  Key Serial Number
     */
    public DukptCalcInfo(byte[] data, byte[] ksn) {
        this.data = data;
        this.ksn = ksn;
    }

    /**
     * @return dukpt algorithm calc result
     */
    public byte[] getData() {
        return data;
    }

    /**
     * @return dukpt Key Serial Number
     */
    public byte[] getKsn() {
        return ksn;
    }

    private static int byte4ToInt(byte[] byte4) {
        int ret = 0;
        ret += (byte4[0] & 0xff) << 24;
        ret += (byte4[1] & 0xff) << 16;
        ret += (byte4[2] & 0xff) << 8;
        ret += (byte4[3] & 0xff);
        return ret;
    }

    private static byte[] intTo4Bytes(int len) {
        byte[] b = new byte[4];
        b[0] = (byte) ((len >> 24) & 0xFF);
        b[1] = (byte) ((len >> 16) & 0xFF);
        b[2] = (byte) ((len >> 8) & 0xFF);
        b[3] = (byte) (len & 0xFF);
        return b;
    }

    public static DukptCalcInfo form(byte[] bytes) {
        if (bytes == null || bytes.length < 8) {
            return null;
        }
        int calcDataLen = byte4ToInt(Arrays.copyOfRange(bytes, 0, 4));
        byte[] calcData = Arrays.copyOfRange(bytes, 4, 4 + calcDataLen);
        int ksnLen = byte4ToInt(Arrays.copyOfRange(bytes, 4 + calcDataLen, 4 + calcDataLen + 4));
        byte[] ksn = Arrays.copyOfRange(bytes, calcDataLen + 8, calcDataLen + 8 + ksnLen);
        return new DukptCalcInfo(calcData, ksn);
    }

    public byte[] toBytes() {
        byte[] out = new byte[data.length + ksn.length + 8];
        byte[] dataLens = intTo4Bytes(data.length);
        byte[] ksnLens = intTo4Bytes(ksn.length);
        System.arraycopy(dataLens, 0, out, 0, 4);
        System.arraycopy(data, 0, out, 4, data.length);
        System.arraycopy(ksnLens, 0, out, 4 + data.length, 4);
        System.arraycopy(ksn, 0, out, 8 + data.length, ksn.length);
        return out;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    protected DukptCalcInfo(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<DukptCalcInfo> CREATOR = new Parcelable.Creator<DukptCalcInfo>() {
        @Override
        public DukptCalcInfo createFromParcel(Parcel source) {
            return new DukptCalcInfo(source);
        }

        @Override
        public DukptCalcInfo[] newArray(int size) {
            return new DukptCalcInfo[size];
        }
    };

    @Override
    public String toString() {
        return "DukptCalcInfo{" +
                "data=" + ByteUtils.byteArray2HexString(data) +
                ", ksn=" + ByteUtils.byteArray2HexString(ksn) +
                '}';
    }
}
