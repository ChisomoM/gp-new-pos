package com.trendit.basesdk.device.printer.format;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * Text Printing Format
 */
public class TextFormat extends BaseParcelable implements Parcelable {

    @FieldNumber(1)
    private PrintAlign align = PrintAlign.FORMAT_ALIGN_LEFT;
    @FieldNumber(2)
    private PrintFontLineThrough lineThrough = PrintFontLineThrough.FORMAT_NORMAL;
    @FieldNumber(3)
    private int fontSize = PrintFontSize.FORMAT_FONT_SIZE_MEDIUM;
    @FieldNumber(4)
    private boolean isBold = false;
    @FieldNumber(5)
    private boolean isItalic = false;
    @FieldNumber(6)
    private boolean isReverse = false;

    /**
     * Obtain printing location
     *
     * @return printing location
     */
    public PrintAlign getAlign() {
        return align;
    }

    /**
     * Set printing location
     *
     * @param align printing location
     */
    public void setAlign(PrintAlign align) {
        this.align = align;
    }

    /**
     * Get printed text and add lines
     *
     * @return printed text and add lines
     */
    public PrintFontLineThrough getLineThrough() {
        return lineThrough;
    }

    /**
     * Set printed text and add lines
     *
     * @param lineThrough printed text and add lines
     */
    public void setLineThrough(PrintFontLineThrough lineThrough) {
        this.lineThrough = lineThrough;
    }

    /**
     * Get Print Font Size
     *
     * @return Print Font Size
     */
    public int getFontSize() {
        return fontSize;
    }

    /**
     * Set Print Font Size
     *
     * @param fontSize Print Font Size
     */
    public void setFontSize(int fontSize) {
        this.fontSize = fontSize;
    }

    /**
     * Returns whether it is bold text
     *
     * @return whether it is bold text
     */
    public boolean isBold() {
        return isBold;
    }

    /**
     * Set whether it is bold text
     *
     * @param bold whether it is bold text
     */
    public void setBold(boolean bold) {
        isBold = bold;
    }

    /**
     * Returns whether it is italic text
     *
     * @return whether it is italic text
     */
    public boolean isItalic() {
        return isItalic;
    }

    /**
     * Set whether it is italic text
     *
     * @param italic whether it is italic text
     */
    public void setItalic(boolean italic) {
        isItalic = italic;
    }

    /**
     * Returns whether to invert the color
     *
     * @return whether to invert the color
     */
    public boolean isReverse() {
        return isReverse;
    }

    /**
     * Set whether to invert the color
     *
     * @param reverse whether to invert the color
     */
    public void setReverse(boolean reverse) {
        isReverse = reverse;
    }


    @Override
    public String toString() {
        return "TextFormat{" +
                "align=" + align +
                ", lineThrough=" + lineThrough +
                ", fontSize=" + fontSize +
                ", isBold=" + isBold +
                ", isItalic=" + isItalic +
                ", isReverse=" + isReverse +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
       writeFromParcel(dest, flags);
    }

    public TextFormat() {
    }

    protected TextFormat(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<TextFormat> CREATOR = new Parcelable.Creator<TextFormat>() {
        @Override
        public TextFormat createFromParcel(Parcel source) {
            return new TextFormat(source);
        }

        @Override
        public TextFormat[] newArray(int size) {
            return new TextFormat[size];
        }
    };
}
