package com.trendit.basesdk.device.picc;

/**
 * rf card remove card callback
 */
public abstract class OnPICCCardAbsentHandleListener {
    /**
     * Call back this interface when card search is successful or error occurs
     *
     * @param retCode result {@link com.trendit.basesdk.card.CardConstants}
     */
    public abstract void handleCardReaderResult(int retCode);
}
