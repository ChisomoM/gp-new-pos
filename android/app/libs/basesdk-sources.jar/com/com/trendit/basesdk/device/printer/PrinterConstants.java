package com.trendit.basesdk.device.printer;


public class PrinterConstants {

    /**
     * Printer idle
     */
    public static final int STATUS_IDLE = 0;

    /**
     * Printing
     */
    public static final int STATUS_BUSY = 1;

    /**
     * Printer out of paper
     */
    public static final int STATUS_OUT_OF_PAPER = 2;

    /**
     * Printer overheating
     */
    public static final int STATUS_OVER_HEAT = 3;

    /**
     * Printer lower power
     */
    public static final int STATUS_LOW_POWER = 4;

    /**
     * Printer error
     */
    public static final int STATUS_GENERAL_ERROR = 0xFF;

    /**
     * Unknown printer error
     */
    public static final int STATUS_UNKNOWN = 5;

    /**
     * Printer printing task error
     */
    public static final int TASK_STATUS_FAIL = -1;

    /**
     * Printer printing task successful
     */
    public static final int TASK_STATUS_SUCCESS = 0;

    /**
     * Printer Print Task Cancellation
     */
    public static final int TASK_STATUS_CANCEL = 1;

    /**
     * Printer print task out of paper
     */
    public static final int TASK_STATUS_OUT_OF_PAPER = 2;

    /**
     * Printer printing task overheating
     */
    public static final int TASK_STATUS_OVER_HEAT = 3;

    /**
     * Printer printing task low power
     */
    public static final int TASK_STATUS_LOW_POWER = 4;

    /**
     * Printer error
     */
    public static final int TASK_STATUS_ERR = 0xFF;

}
