package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * Script processing result
 */
public class ScriptResult extends BaseParcelable implements Parcelable {

    @FieldNumber(1)
    private byte[] data;

    /**
     * Get the Script processing result
     *
     * @return Script processing result
     */
    public byte[] getData() {
        return data;
    }

    /**
     * Set the Script processing result
     *
     * @param data Script processing result
     */
    public void setData(byte[] data) {
        this.data = data;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public ScriptResult() {
    }

    protected ScriptResult(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<ScriptResult> CREATOR = new Parcelable.Creator<ScriptResult>() {
        @Override
        public ScriptResult createFromParcel(Parcel source) {
            return new ScriptResult(source);
        }

        @Override
        public ScriptResult[] newArray(int size) {
            return new ScriptResult[size];
        }
    };

    @Override
    public String toString() {
        return "ScriptResult{" +
                "data=" + ByteUtils.byteArray2HexString(data) +
                '}';
    }
}
