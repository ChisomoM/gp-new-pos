package com.trendit.basesdk.device.emv;

import com.trendit.basesdk.device.msr.MSRTrackData;

import java.util.List;

/**
 * emv process callback
 */
public abstract class EMVTransListener {

    /**
     *
     */
    public static final int REFER_TYPE_ICC = 0;

    /**
     *
     */
    public static final int REFER_TYPE_ISSUER = 1;

    /**
     * Pls Wait
     */
    public static final int PROMPT_TYPE_ICC_WAIT = 0x00;

    /**
     * PIN Err!
     */
    public static final int PROMPT_TYPE_ICC_OFFLINE_PIN_ERR = 0x01;

    /**
     * PIN Success
     */
    public static final int PROMPT_TYPE_ICC_OFFLINE_PIN_SUC = 0x02;

    /**
     * PIN Err! Pls Try Again
     */
    public static final int PROMPT_TYPE_ICC_INPUT_PIN_AGAIN = 0x03;

    /**
     * Magnetic card found during reading process
     *
     * @param msrTrackData Magnetic card info
     */
    public void onFindMagCard(MSRTrackData msrTrackData) {

    }

    /**
     * cpu card found during reading process
     *
     * @param channelType {@link EMVTransData#Channel_Type_IC} {@link EMVTransData#Channel_Type_RF}
     */
    public void onFindCPUCard(int channelType) {

    }

    /**
     * card found error
     *
     * @param errorCode error code
     * @see com.trendit.basesdk.card.CardConstants
     */
    public void onReadCardError(int errorCode) {

    }

    /**
     * Prompt to cardholder to remove contactless card, and power off the RF field.
     * The call back function need doing as following steps:
     * 1.call sdkSysBeepRfRemoveCard to play card operate complete sound.
     * 2.call show led status of card operate complete.
     * 3.call sdkPiccClose to power off RF field.
     * 4.Display in LCD to cardholder to remove contactless card.
     *
     * @return {@link EmvConstants#App_Confirm_OK} {@link EmvConstants#App_Confirm_Cancel} {@link EmvConstants#App_Confirm_Failure}
     */
    public abstract int onRFCardRemove();

    /**
     * EMV cvm verify,Prompt to cardholder to enter PIN.
     *
     * @param pinRetryCount If the pinMode is {@link PINResult#PIN_MODE__OFFLINE_PLAIN} {@link PINResult#PIN_MODE__OFFLINE_ENCRYPT}, this value is PIN retry times for offine PIN.
     * @param pinMode       pin mode {@link PINResult#PIN_MODE_ONLINE} {@link PINResult#PIN_MODE__OFFLINE_PLAIN} {@link PINResult#PIN_MODE__OFFLINE_ENCRYPT}
     * @param arith         when pinMode is {@link PINResult#PIN_MODE__OFFLINE_ENCRYPT} the pheCreditPwd store data for PIN_ISO_9564_2 arith.
     * @return pinBlock {@link PINResult}
     */
    public abstract PINResult onInputPwd(int pinRetryCount, int pinMode, byte[] arith);

    /**
     * EMV kernel provide the aid list for the cardholder to select
     * If this call back function is not exist ,the kernel will use the default function to cardholder to select application. The language is to use English.
     *
     * @param appList the aid list.
     * @return If the return value is greater than or equal to zero the value is The AID index selected；-1 {@link EmvConstants#App_Confirm_Cancel} -2 {@link EmvConstants#App_Confirm_Failure}
     */
    public abstract int onWaitAppSelect(List<AIDSelect> appList);

    /**
     * EMV kernel prompt some information to cardholder.
     *
     * @param promptType {@link #PROMPT_TYPE_ICC_WAIT} {@link #PROMPT_TYPE_ICC_OFFLINE_PIN_ERR} {@link #PROMPT_TYPE_ICC_OFFLINE_PIN_SUC} {@link #PROMPT_TYPE_ICC_INPUT_PIN_AGAIN}
     * @return {@link EmvConstants#App_Confirm_OK} {@link EmvConstants#App_Confirm_Cancel} {@link EmvConstants#App_Confirm_Failure}
     */
    public abstract int onShowPrompt(int promptType);

    /**
     * The unionpay PBOC cvm verify mode, credential verify
     * 1. Get the TAG_CardHoldIdType and TAG_CardHoldIdNo tag value to display,and verify the credential information.
     * 2. You can return value not 0 directly.
     *
     * @return {@link EmvConstants#App_Confirm_OK} {@link EmvConstants#App_Confirm_Cancel} {@link EmvConstants#App_Confirm_Failure}
     */
    public abstract int onCredentialVerify();

    /**
     * EMV refers processing flow when the issuer return refer response.
     * 1. prompt card pan and "PLS CALL YOUR BANK" information.
     * 2. When the bank accept the transaction , run setTLV(0x8A000000, "Y2".getBytes());  setTLV(0xDF811400, new byte[]{0x40});
     * 3. When the bank reject the transaction , run setTLV(0x8A000000, "Z2".getBytes()); setTLV(0xDF811400, new byte[]{0x00});
     *
     * @param referType {@link #REFER_TYPE_ICC} {@link #REFER_TYPE_ISSUER}
     * @return {@link EmvConstants#App_Confirm_OK} {@link EmvConstants#App_Confirm_Cancel} {@link EmvConstants#App_Confirm_Failure}
     */
    public abstract int onEmvProcessRefer(int referType);

    /**
     * If the app need to support paypass torn transaction,the app need to define the callback function to check if the torn transaction information is changed.
     *
     * @param transData torn transaction
     * @return {@link EmvConstants#App_Confirm_OK} {@link EmvConstants#App_Confirm_Cancel} {@link EmvConstants#App_Confirm_Failure}
     */
    public abstract int onTornTransRecoverData(TornTransData transData);

    /**
     *
     */
    public int onDiscoverOperatorSpecExtendLog() {
        return EmvConstants.App_Confirm_OK;
    }

    /**
     *
     */
    public int onDiscoverDPasOperatorSpecProcessBeforeGPO() {
        return EmvConstants.App_Confirm_OK;
    }

    /**
     *
     */
    public int onDiscoverOperatorSpecPostComplete() {
        return EmvConstants.App_Confirm_OK;
    }

    /**
     *
     */
    public int onAppConfigTagSets() {
        return EmvConstants.App_Confirm_OK;
    }

    /**
     * EMV process execution results
     *
     * @param code result code @see EmvConstants
     */
    public abstract void onTransResult(int code);

}
