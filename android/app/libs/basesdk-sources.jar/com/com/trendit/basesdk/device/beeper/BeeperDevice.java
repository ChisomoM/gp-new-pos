package com.trendit.basesdk.device.beeper;

/**
 * <b>BeeperDevice</b>Defined the interface for the buzzer device
 * <pre>
 * BeeperDevice beeperDevice = POSDeviceManager.getInstance().getBeeperDevice();
 * </pre>
 * The caller cannot create the object through new
 */
public abstract class BeeperDevice {

    /**
     * Buzzer sounds
     *
     * @param count       Number of vocalizations
     * @param beepOnTime  The duration of sound production, in milliseconds
     * @param beepOffTime The duration of silence, in milliseconds
     * @param frequency   Phonation frequency
     * @return Success or Failure
     */
    public abstract boolean beeps(int count, int beepOnTime, int beepOffTime, int frequency);

}
