package com.trendit.basesdk.card;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

public class MoneyValue extends BaseParcelable implements Parcelable {
    @FieldNumber(1)
    private byte[] userData;
    @FieldNumber(2)
    private int money;

    /**
     * Electronic wallet constructor.
     *
     * @param userData user data
     * @param money    money
     */
    public MoneyValue(byte[] userData, int money) {
        this.userData = userData;
        this.money = money;
    }

    /**
     * Get the user data。
     *
     * @return userdata
     */
    public byte[] getUserData() {
        return userData;
    }

    /**
     * Get the money。
     *
     * @return money
     */
    public int getMoney() {
        return money;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    protected MoneyValue(Parcel in) {
        readFromParcelable(in);
    }

    public static final Creator<MoneyValue> CREATOR = new Creator<MoneyValue>() {
        @Override
        public MoneyValue createFromParcel(Parcel source) {
            return new MoneyValue(source);
        }

        @Override
        public MoneyValue[] newArray(int size) {
            return new MoneyValue[size];
        }
    };

    @Override
    public String toString() {
        return "MoneyValue{" +
                "userData=" + ByteUtils.byteArray2HexString(userData) +
                ", money=" + money +
                '}';
    }
}
