package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * Bank card electronic cash balance
 * {@link EMVDevice#queryECBalance(int)}
 */
public class Balance extends BaseParcelable implements Parcelable {

    /**
     * First Currency Code
     */
    @FieldNumber(1)
    private String firstCurrencyCode;
    /**
     * First balance
     */
    @FieldNumber(2)
    private long firstCurrencyBalance;
    /**
     * Second Currency Code
     */
    @FieldNumber(3)
    private String secondCurrencyCode;
    /**
     * Second balance
     */
    @FieldNumber(4)
    private long secondCurrencyBalance;

    /**
     * Get the First Currency Code
     *
     * @return First Currency Code
     */
    public String getFirstCurrencyCode() {
        return firstCurrencyCode;
    }

    /**
     * Set the First Currency Code
     *
     * @param firstCurrencyCode First Currency Code
     */
    public void setFirstCurrencyCode(String firstCurrencyCode) {
        this.firstCurrencyCode = firstCurrencyCode;
    }

    /**
     * Get the First balance
     *
     * @return First balance
     */
    public long getFirstCurrencyBalance() {
        return firstCurrencyBalance;
    }

    /**
     * Set the First balance
     *
     * @param firstCurrencyBalance First balance
     */
    public void setFirstCurrencyBalance(long firstCurrencyBalance) {
        this.firstCurrencyBalance = firstCurrencyBalance;
    }

    /**
     * Get the Second Currency Code
     *
     * @return Second Currency Code
     */
    public String getSecondCurrencyCode() {
        return secondCurrencyCode;
    }

    /**
     * Set the Second Currency Code
     *
     * @param secondCurrencyCode Second Currency Code
     */
    public void setSecondCurrencyCode(String secondCurrencyCode) {
        this.secondCurrencyCode = secondCurrencyCode;
    }

    /**
     * Get the Second balance
     *
     * @return Second balance
     */
    public long getSecondCurrencyBalance() {
        return secondCurrencyBalance;
    }

    /**
     * Set the Second balance
     *
     * @param secondCurrencyBalance Second balance
     */
    public void setSecondCurrencyBalance(long secondCurrencyBalance) {
        this.secondCurrencyBalance = secondCurrencyBalance;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public Balance() {
    }

    protected Balance(Parcel in) {
        readFromParcelable(in);
    }

    public static final Creator<Balance> CREATOR = new Creator<Balance>() {
        @Override
        public Balance createFromParcel(Parcel source) {
            return new Balance(source);
        }

        @Override
        public Balance[] newArray(int size) {
            return new Balance[size];
        }
    };

    @Override
    public String toString() {
        return "Balance{" +
                "firstCurrencyCode='" + firstCurrencyCode + '\'' +
                ", firstCurrencyBalance=" + firstCurrencyBalance +
                ", secondCurrencyCode='" + secondCurrencyCode + '\'' +
                ", secondCurrencyBalance=" + secondCurrencyBalance +
                '}';
    }
}
