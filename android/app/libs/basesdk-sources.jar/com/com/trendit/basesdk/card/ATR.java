package com.trendit.basesdk.card;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

public class ATR extends BaseParcelable implements Parcelable {
    @FieldNumber(1)
    private byte[] atr;
    @FieldNumber(2)
    private byte[] histBytes;

    public ATR(byte[] atr, byte[] histBytes){
        this.atr = atr;
        this.histBytes = histBytes;
    }

    /**
     * Obtain all ATR data
     *
     * @return ATR data buffer.
     */
    public byte[] getAtr() {
        return atr;
    }

    /**
     * Obtain data in TLV format containing information such as issuer, card type, operating system, etc. If the communication protocol does not support it, return null.
     * <p>Historical Bytes It is used to describe the physical characteristics or additional information of a card, such as manufacturer or chip type or card serial number.
     * ISO/IEC 7816-4 Defined the structure and meaning of Historical Bytes, which is a variable length byte array within 15 bytes.
     * Although the structure of Historical Bytes is specified in EMV, not all cards will return this data.
     * In addition, the original NFC interface of Android currently includes this interface.
     * For specific parsing, please refer to EMV 4.3 Book 1
     * Application Independent ICC to
     * Terminal Interface Requirements。
     * @return buffer
     */
    public byte[] getHistBytes() {
        return histBytes;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    protected ATR(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<ATR> CREATOR = new Parcelable.Creator<ATR>() {
        @Override
        public ATR createFromParcel(Parcel source) {
            return new ATR(source);
        }

        @Override
        public ATR[] newArray(int size) {
            return new ATR[size];
        }
    };

    @Override
    public String toString() {
        return "ATR{" +
                "atr=" + ByteUtils.byteArray2HexString(atr) +
                ", histBytes=" + ByteUtils.byteArray2HexString(histBytes) +
                '}';
    }
}
