package com.trendit.basesdk.device.picc;

/**
 * rf card find callback
 */
public abstract class OnPICCCardHandleListener {
    /**
     * all back this interface when card search is successful or error occurs
     *
     * @param retCode result {@link com.trendit.basesdk.card.CardConstants}
     * @param result  rf card info
     * @see PICCCardSearchResult
     */
    public abstract void handleCardReaderResult(int retCode, PICCCardSearchResult result);
}
