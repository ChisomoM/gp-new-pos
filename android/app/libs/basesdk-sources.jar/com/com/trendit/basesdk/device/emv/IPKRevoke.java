package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * revoked issuer public key certification
 */
public class IPKRevoke extends BaseParcelable implements Parcelable {
    /**
     * Registered Application
     */
    @FieldNumber(1)
    private byte[] RID;

    /**
     * Certification Authenticate Public Key Index.
     */
    @FieldNumber(2)
    private byte capkIndex;

    /**
     * Issuer Certificate Serial Number.
     */
    @FieldNumber(3)
    private byte[] CERTSerial;

    /**
     * Get the Registered Application
     *
     * @return Registered Application
     */
    public byte[] getRID() {
        return RID;
    }

    /**
     * Set the Registered Application
     *
     * @param RID Registered Application
     */
    public void setRID(byte[] RID) {
        this.RID = RID;
    }

    /**
     * Get the Certification Authenticate Public Key Index.
     *
     * @return Certification Authenticate Public Key Index.
     */
    public byte getCapkIndex() {
        return capkIndex;
    }

    /**
     * Set the Certification Authenticate Public Key Index.
     *
     * @param capkIndex Certification Authenticate Public Key Index.
     */
    public void setCapkIndex(byte capkIndex) {
        this.capkIndex = capkIndex;
    }

    /**
     * Get the Issuer Certificate Serial Number.
     *
     * @return Issuer Certificate Serial Number.
     */
    public byte[] getCERTSerial() {
        return CERTSerial;
    }

    /**
     * Set the Issuer Certificate Serial Number.
     *
     * @param CERTSerial Issuer Certificate Serial Number.
     */
    public void setCERTSerial(byte[] CERTSerial) {
        this.CERTSerial = CERTSerial;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public IPKRevoke() {
    }

    protected IPKRevoke(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<IPKRevoke> CREATOR = new Parcelable.Creator<IPKRevoke>() {
        @Override
        public IPKRevoke createFromParcel(Parcel source) {
            return new IPKRevoke(source);
        }

        @Override
        public IPKRevoke[] newArray(int size) {
            return new IPKRevoke[size];
        }
    };

    @Override
    public String toString() {
        return "IPKRevoke{" +
                "RID=" + ByteUtils.byteArray2HexString(RID) +
                ", capkIndex=" + (capkIndex & 0xFF) +
                ", CERTSerial=" + ByteUtils.byteArray2HexString(CERTSerial) +
                '}';
    }
}
