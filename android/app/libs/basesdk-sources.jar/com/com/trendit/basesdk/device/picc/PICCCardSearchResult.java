package com.trendit.basesdk.device.picc;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;


/**
 * When the data returned by the PICC card is detected
 */
public class PICCCardSearchResult extends BaseParcelable implements Parcelable {

    @FieldNumber(1)
    private int cardType;
    @FieldNumber(2)
    private byte[] cardCsn;
    @FieldNumber(3)
    private byte sak;

    /**
     * Obtain Card Type
     *
     * @return Card Type
     * @see PICCCardConstants#PROTOCOL_RFCARD_TYPE_A
     * @see PICCCardConstants#PROTOCOL_RFCARD_TYPE_B
     * @see PICCCardConstants#TYPE_RFCARD_TYPE_M1
     * @see PICCCardConstants#TYPE_RFCARD_MULTI
     */
    public int getCardType() {
        return cardType;
    }

    /**
     * Set Card Type
     *
     * @param cardType Card Type
     */
    public void setCardType(int cardType) {
        this.cardType = cardType;
    }

    /**
     * Obtain Card CSN
     *
     * @return csn
     */
    public byte[] getCardCsn() {
        return cardCsn;
    }

    /**
     * Set Card CSN
     *
     * @param cardCsn csn
     */
    public void setCardCsn(byte[] cardCsn) {
        this.cardCsn = cardCsn;
    }

    /**
     * Obtain Card Sak
     *
     * @return sak
     */
    public byte getSak() {
        return sak;
    }

    /**
     * Set Card Sak
     *
     * @param sak sak
     */
    public void setSak(byte sak) {
        this.sak = sak;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public PICCCardSearchResult() {
    }

    protected PICCCardSearchResult(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<PICCCardSearchResult> CREATOR = new Parcelable.Creator<PICCCardSearchResult>() {
        @Override
        public PICCCardSearchResult createFromParcel(Parcel source) {
            return new PICCCardSearchResult(source);
        }

        @Override
        public PICCCardSearchResult[] newArray(int size) {
            return new PICCCardSearchResult[size];
        }
    };

    @Override
    public String toString() {
        return "PICCCardSearchResult{" +
                "cardType=" + cardType +
                ", cardCsn=" + ByteUtils.byteArray2HexString(cardCsn) +
                ", sak=" + (sak & 0xFF) +
                '}';
    }
}
