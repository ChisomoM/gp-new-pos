package com.trendit.basesdk.device.icc;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * When the data returned by the ICC card is detected
 */
public class ICCCardSearchResult extends BaseParcelable implements Parcelable {

    @FieldNumber(1)
    private int cardStatus;

    /**
     * Return card search results
     *
     * @return card search results {@link ICCCardConstants#ICC_STATUS_NO_CARD} {@link ICCCardConstants#ICC_STATUS_NO_POWERED} {@link ICCCardConstants#ICC_STATUS_POWERED} {@link ICCCardConstants#ICC_STATUS_UNKNOWN}
     */
    public int getCardStatus() {
        return cardStatus;
    }

    /**
     * Set card search results
     *
     * @param cardStatus status
     */
    public void setCardStatus(int cardStatus) {
        this.cardStatus = cardStatus;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public ICCCardSearchResult() {
    }

    protected ICCCardSearchResult(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<ICCCardSearchResult> CREATOR = new Parcelable.Creator<ICCCardSearchResult>() {
        @Override
        public ICCCardSearchResult createFromParcel(Parcel source) {
            return new ICCCardSearchResult(source);
        }

        @Override
        public ICCCardSearchResult[] newArray(int size) {
            return new ICCCardSearchResult[size];
        }
    };

    @Override
    public String toString() {
        return "ICCCardSearchResult{" +
                "cardStatus=" + cardStatus +
                '}';
    }
}
