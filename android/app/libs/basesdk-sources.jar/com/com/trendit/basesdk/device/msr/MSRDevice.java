package com.trendit.basesdk.device.msr;

/**
 * <b>MsrDevice</b>Defined the interface for led devices.
 * <pre>
 * MsrDevice device = POSDeviceManager.getInstance().getMsrDevice();
 * </pre>
 * The caller cannot create the object through new
 */
public abstract class MSRDevice {

    /**
     * Listen for magnetic stripe card swiping
     *
     * @param listener card swiping callback
     * @param timeout  Time out (milliseconds)
     */
    public abstract void listenForSwipe(final OnMSRCardHandlerListener listener, int timeout);

    /**
     * Cancel search card
     */
    public abstract void cancel();

}
