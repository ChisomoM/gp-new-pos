package com.trendit.basesdk.device.printer.format;


import android.os.Parcel;
import android.os.Parcelable;

/**
 * print density
 */
public enum PrintDensity implements Parcelable {

    /**
     * Density：Lighter
     */
    FORMAT_DENSITY_LIGHTER(0),
    /**
     * Density：Light
     */
    FORMAT_DENSITY_LIGHT(1),

    /**
     * Density：Medium
     */
    FORMAT_DENSITY_MEDIUM(2),

    /**
     * Density：Dark
     */
    FORMAT_DENSITY_DARK(3),

    /**
     * Density：Darker
     */
    FORMAT_DENSITY_DARKER(4);

    private int density;


    PrintDensity(int density) {
        this.density = density;
    }

    public int getDensity() {
        return this.density;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeInt(ordinal());
    }

    public static final Parcelable.Creator<PrintDensity> CREATOR = new Parcelable.Creator<PrintDensity>() {

        @Override
        public PrintDensity createFromParcel(Parcel parcel) {
            int ordinal = parcel.readInt();
            for (PrintDensity printDensity : PrintDensity.values()) {
                if (printDensity.ordinal() == ordinal) {
                    return printDensity;
                }
            }
            return null;
        }

        @Override
        public PrintDensity[] newArray(int size) {
            return new PrintDensity[size];
        }
    };
}
