package com.trendit.basesdk.device.icc;

import com.trendit.basesdk.card.CPUCard;

/**
 * <b>ICCCardDevice</b>Defined the interface of IC devices
 * <pre>
 * ICCCardDevice device = POSDeviceManager.getInstance().getICCCardDevice();
 * </pre>
 * The caller cannot create the object through new
 */
public abstract class ICCCardDevice {


    /**
     * Detecting cpu cards
     *
     * @param listener Card search callback
     * @param timeout  Time out (milliseconds)
     */
    public abstract void listenForCard(final OnICCCardHandlerListener listener, int timeout);

    /**
     * Detect cpu card movement
     *
     * @param listener Card search callback
     * @param timeout  Time out (milliseconds)
     */
    public abstract void listenForCardAbsent(final OnICCCardAbsentHandlerListener listener, int timeout);

    /**
     * Does the IC card exist
     *
     * @return true or false
     */
    public abstract boolean isCardExist();

    /**
     * Cancel search card
     */
    public abstract void cancel();

    /**
     * Get CPU card operation object
     *
     * @return cpu card operation object
     * @see CPUCard
     */
    public abstract CPUCard getCPUCardHandler();

}
