package com.trendit.basesdk.device.pinpad;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * The area location information of the password keyboard
 */
public class KeyboardPosition extends BaseParcelable implements Parcelable {
    @FieldNumber(1)
    private int xStart;
    @FieldNumber(2)
    private int yStart;
    @FieldNumber(3)
    private int keyWidth;
    @FieldNumber(4)
    private int keyHeight;
    @FieldNumber(5)
    private int keyXGap;
    @FieldNumber(6)
    private int keyYGap;
    @FieldNumber(7)
    private int rowNum;
    @FieldNumber(8)
    private int colNum;

    /**
     * Building password keyboard area location information
     *
     * @param xStart    The X coordinate of the upper left corner of the password keyboard
     * @param yStart    The Y coordinate of the upper left corner of the password keyboard
     * @param keyWidth  The width of each button in the password keyboard
     * @param keyHeight The height of each button in the password keyboard
     * @param keyXGap   The interval between the x-axis of each button in the password keyboard
     * @param keyYGap   The interval between the y-axis of each button in the password keyboard
     * @param rowNum    Number of password keyboard lines
     * @param colNum    Number of password keyboard columns
     */
    public KeyboardPosition(int xStart, int yStart, int keyWidth, int keyHeight, int keyXGap, int keyYGap, int rowNum, int colNum) {
        this.xStart = xStart;
        this.yStart = yStart;
        this.keyWidth = keyWidth;
        this.keyHeight = keyHeight;
        this.keyXGap = keyXGap;
        this.keyYGap = keyYGap;
        this.rowNum = rowNum;
        this.colNum = colNum;
    }

    /**
     * @return the X coordinate of the upper left corner of the password keyboard
     */
    public int getxStart() {
        return xStart;
    }

    /**
     * @return Y coordinate of the upper left corner of the password keyboard
     */
    public int getyStart() {
        return yStart;
    }

    /**
     * @return The width of each button in the password keyboard
     */
    public int getKeyWidth() {
        return keyWidth;
    }

    /**
     * @return The height of each button in the password keyboard
     */
    public int getKeyHeight() {
        return keyHeight;
    }

    /**
     * @return The interval between the x-axis of each button in the password keyboard
     */
    public int getKeyXGap() {
        return keyXGap;
    }

    /**
     * @return The interval between the y-axis of each button in the password keyboard
     */
    public int getKeyYGap() {
        return keyYGap;
    }

    /**
     * @return Number of password keyboard lines
     */
    public int getRowNum() {
        return rowNum;
    }

    /**
     * @return Number of password keyboard columns
     */
    public int getColNum() {
        return colNum;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public KeyboardPosition() {
    }

    protected KeyboardPosition(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<KeyboardPosition> CREATOR = new Parcelable.Creator<KeyboardPosition>() {
        @Override
        public KeyboardPosition createFromParcel(Parcel source) {
            return new KeyboardPosition(source);
        }

        @Override
        public KeyboardPosition[] newArray(int size) {
            return new KeyboardPosition[size];
        }
    };

    @Override
    public String toString() {
        return "KeyboardPosition{" +
                "xStart=" + xStart +
                ", yStart=" + yStart +
                ", keyWidth=" + keyWidth +
                ", keyHeight=" + keyHeight +
                ", keyXGap=" + keyXGap +
                ", keyYGap=" + keyYGap +
                ", rowNum=" + rowNum +
                ", colNum=" + colNum +
                '}';
    }
}
