package com.trendit.basesdk.device.printer.format;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Print Position
 */
public enum PrintAlign implements Parcelable {

    /**
     * Print Left
     */
    FORMAT_ALIGN_LEFT(0),

    /**
     * Print center
     */
    FORMAT_ALIGN_CENTER(1),

    /**
     * Print right
     */
    FORMAT_ALIGN_RIGHT(2);

    private int align;


    PrintAlign(int align) {
        this.align = align;
    }

    public int getAlign() {
        return this.align;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeInt(ordinal());
    }

    public static final Creator<PrintAlign> CREATOR = new Creator<PrintAlign>() {

        @Override
        public PrintAlign createFromParcel(Parcel parcel) {
            int ordinal = parcel.readInt();
            for (PrintAlign printAlign : PrintAlign.values()) {
                if (printAlign.ordinal() == ordinal) {
                    return printAlign;
                }
            }
            return null;
        }

        @Override
        public PrintAlign[] newArray(int size) {
            return new PrintAlign[size];
        }
    };
}
