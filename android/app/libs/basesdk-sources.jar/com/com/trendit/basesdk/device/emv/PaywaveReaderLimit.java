package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * paywave dynamic limit
 */
public class PaywaveReaderLimit extends BaseParcelable implements Parcelable {
    /**
     * Application Program ID
     */
    @FieldNumber(1)
    private byte[] appProgramID;

    /**
     * Status Check enable flag
     */
    @FieldNumber(2)
    private byte statusCheckSupFlag;

    /**
     * Amount, Authorized of Zero Check
     * 0 – disabled
     * 1 – Option 1
     * 2 – Option 2
     */
    @FieldNumber(3)
    private byte zeroAmtAllowedFlag;

    /**
     * Reader Contactless Transaction Limit Check enable flag
     */
    @FieldNumber(4)
    private byte clsTransLimitEnableFlag;

    /**
     * Reader CVM Required Limit Check enable flag
     */
    @FieldNumber(5)
    private byte clsCVMLimitEnableFlag;

    /**
     * Reader Contactless Floor Limit Check enable flag
     */
    @FieldNumber(6)
    private byte clsFloorLimitEnableFlag;

    /**
     * Reader Contactless Transaction Limit
     */
    @FieldNumber(7)
    private byte[] clsTransLimit;

    /**
     * Reader CVM Required Limit
     */
    @FieldNumber(8)
    private byte[] clsCVMLimit;

    /**
     * Reader Contactless Floor Limit
     */
    @FieldNumber(9)
    private byte[] clsFloorLimit;

    /**
     * Get the Application Program ID
     *
     * @return Application Program ID
     */
    public byte[] getAppProgramID() {
        return appProgramID;
    }

    /**
     * Set the Application Program ID
     *
     * @param appProgID Application Program ID
     */
    public void setAppProgramID(byte[] appProgID) {
        this.appProgramID = appProgID;
    }

    /**
     * Get the Status Check enable flag
     *
     * @return Status Check enable flag
     */
    public byte getStatusCheckSupFlag() {
        return statusCheckSupFlag;
    }

    /**
     * Set the Status Check enable flag
     *
     * @param statusCheckSupFlag Status Check enable flag
     */
    public void setStatusCheckSupFlag(byte statusCheckSupFlag) {
        this.statusCheckSupFlag = statusCheckSupFlag;
    }

    /**
     * Get the Amount, Authorized of Zero Check
     * 0 – disabled
     * 1 – Option 1
     * 2 – Option 2
     *
     * @return flag
     */
    public byte getZeroAmtAllowedFlag() {
        return zeroAmtAllowedFlag;
    }

    /**
     * Set the Amount, Authorized of Zero Check
     * 0 – disabled
     * 1 – Option 1
     * 2 – Option 2
     *
     * @param zeroAmtAllowedFlag flag
     */
    public void setZeroAmtAllowedFlag(byte zeroAmtAllowedFlag) {
        this.zeroAmtAllowedFlag = zeroAmtAllowedFlag;
    }

    /**
     * Get the Reader Contactless Transaction Limit Check enable flag
     *
     * @return Reader Contactless Transaction Limit Check enable flag
     */
    public byte getClsTransLimitEnableFlag() {
        return clsTransLimitEnableFlag;
    }

    /**
     * Set the Reader Contactless Transaction Limit Check enable flag
     *
     * @param clsTransLimitEnableFlag Reader Contactless Transaction Limit Check enable flag
     */
    public void setClsTransLimitEnableFlag(byte clsTransLimitEnableFlag) {
        this.clsTransLimitEnableFlag = clsTransLimitEnableFlag;
    }

    /**
     * Get the Reader CVM Required Limit Check enable flag
     *
     * @return Reader CVM Required Limit Check enable flag
     */
    public byte getClsCVMLimitEnableFlag() {
        return clsCVMLimitEnableFlag;
    }

    /**
     * Set the Reader CVM Required Limit Check enable flag
     *
     * @param clsCVMLimitEnableFlag Reader CVM Required Limit Check enable flag
     */
    public void setClsCVMLimitEnableFlag(byte clsCVMLimitEnableFlag) {
        this.clsCVMLimitEnableFlag = clsCVMLimitEnableFlag;
    }

    /**
     * Get the Reader Contactless Floor Limit Check enable flag
     *
     * @return Reader Contactless Floor Limit Check enable flag
     */
    public byte getClsFloorLimitEnableFlag() {
        return clsFloorLimitEnableFlag;
    }

    /**
     * Set the Reader Contactless Floor Limit Check enable flag
     *
     * @param clsFloorLimitEnableFlag Reader Contactless Floor Limit Check enable flag
     */
    public void setClsFloorLimitEnableFlag(byte clsFloorLimitEnableFlag) {
        this.clsFloorLimitEnableFlag = clsFloorLimitEnableFlag;
    }

    /**
     * Get the  Reader Contactless Transaction Limit
     *
     * @return Reader Contactless Transaction Limit
     */
    public byte[] getClsTransLimit() {
        return clsTransLimit;
    }

    /**
     * Set the  Reader Contactless Transaction Limit 6bytes
     *
     * @param clsTransLimit Reader Contactless Transaction Limit
     */
    public void setClsTransLimit(byte[] clsTransLimit) {
        this.clsTransLimit = clsTransLimit;
    }

    /**
     * Get the Reader CVM Required Limit
     *
     * @return Reader CVM Required Limit
     */
    public byte[] getClsCVMLimit() {
        return clsCVMLimit;
    }

    /**
     * Set the Reader CVM Required Limit 6bytes
     *
     * @param clsCVMLimit Reader CVM Required Limit
     */
    public void setClsCVMLimit(byte[] clsCVMLimit) {
        this.clsCVMLimit = clsCVMLimit;
    }

    /**
     * Get the Reader Contactless Floor Limit
     *
     * @return Reader Contactless Floor Limit
     */
    public byte[] getClsFloorLimit() {
        return clsFloorLimit;
    }

    /**
     * Set the Reader Contactless Floor Limit 6bytes
     *
     * @param clsFloorLimit Reader Contactless Floor Limit
     */
    public void setClsFloorLimit(byte[] clsFloorLimit) {
        this.clsFloorLimit = clsFloorLimit;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public PaywaveReaderLimit() {
    }

    protected PaywaveReaderLimit(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<PaywaveReaderLimit> CREATOR = new Parcelable.Creator<PaywaveReaderLimit>() {
        @Override
        public PaywaveReaderLimit createFromParcel(Parcel source) {
            return new PaywaveReaderLimit(source);
        }

        @Override
        public PaywaveReaderLimit[] newArray(int size) {
            return new PaywaveReaderLimit[size];
        }
    };

    @Override
    public String toString() {
        return "PaywaveReaderLimit{" +
                "appProgramID=" + ByteUtils.byteArray2HexString(appProgramID) +
                ", statusCheckSupFlag=" + (statusCheckSupFlag & 0xFF) +
                ", zeroAmtAllowedFlag=" + (zeroAmtAllowedFlag & 0xFF) +
                ", clsTransLimitEnableFlag=" + (clsTransLimitEnableFlag & 0xFF) +
                ", clsCVMLimitEnableFlag=" + (clsCVMLimitEnableFlag & 0xFF) +
                ", clsFloorLimitEnableFlag=" + (clsFloorLimitEnableFlag & 0xFF) +
                ", clsTransLimit=" + ByteUtils.byteArray2HexString(clsTransLimit) +
                ", clsCVMLimit=" + ByteUtils.byteArray2HexString(clsCVMLimit) +
                ", clsFloorLimit=" + ByteUtils.byteArray2HexString(clsFloorLimit) +
                '}';
    }
}
