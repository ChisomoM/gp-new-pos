package com.trendit.basesdk.device.led;


/**
 * <b>LedDevice</b>Defined the interface for led devices.
 * <pre>
 * LedDevice device = POSDeviceManager.getInstance().getLedDevice();
 * </pre>
 * The caller cannot create the object through new
 */
public abstract class LedDevice {

    /**
     * Turn on the LED light
     *
     * @param colors LED light color {@link LedConstants#COLOR_YELLOW} {@link LedConstants#COLOR_GREEN} {@link LedConstants#COLOR_RED} {@link LedConstants#COLOR_BLUE}
     * @return Success or Failure
     */
    public abstract boolean turnOn(int[] colors);


    /**
     * Turn off the LED light
     *
     * @param colors LED light color {@link LedConstants#COLOR_YELLOW} {@link LedConstants#COLOR_GREEN} {@link LedConstants#COLOR_RED} {@link LedConstants#COLOR_BLUE}
     * @return Success or Failure
     */
    public abstract boolean turnOff(int[] colors);


    /**
     * LED flashing
     *
     * @param colors       LED light color {@link LedConstants#COLOR_YELLOW} {@link LedConstants#COLOR_GREEN} {@link LedConstants#COLOR_RED} {@link LedConstants#COLOR_BLUE}
     * @param turnOnTimes  Time to light up when flashing
     * @param turnOffTimes Time to turn off the light when flashing
     * @param blinkCounts  Number of flashes
     * @return Success or Failure
     */
    public abstract boolean blink(int[] colors, int[] turnOnTimes, int[] turnOffTimes, int[] blinkCounts);

}
