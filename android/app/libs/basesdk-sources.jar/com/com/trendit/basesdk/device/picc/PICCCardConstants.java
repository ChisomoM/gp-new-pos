package com.trendit.basesdk.device.picc;

public class PICCCardConstants {

    /**
     * unknown type
     */
    public static final int PROTOCOL_RFCARD_TYPE_UNKNOWN = -1;

    /**
     * A Protocol Card
     */
    public static final int PROTOCOL_RFCARD_TYPE_A = 0;

    /**
     * B Protocol Card
     */
    public static final int PROTOCOL_RFCARD_TYPE_B = 1;

    /**
     * M1 Card
     */
    public static final int TYPE_RFCARD_TYPE_M1 = 2;

    /**
     * Multi card
     */
    public static final int TYPE_RFCARD_MULTI = 3;

}
