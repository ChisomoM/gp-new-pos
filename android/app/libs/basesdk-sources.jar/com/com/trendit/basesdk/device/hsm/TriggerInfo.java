package com.trendit.basesdk.device.hsm;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * Terminal trigger information
 */
public class TriggerInfo extends BaseParcelable implements Parcelable {

    /**
     * Trigger level-Trigger not turned on
     */
    public final static byte TRIGGER_LEVEL_DISABLED = 0x00;
    /**
     * Trigger level-Online release the trigger
     */
    public final static byte TRIGGER_LEVEL_REMOVE_BY_BACKEND = 0x01;
    /**
     * Trigger level-Local release the trigger
     */
    public final static byte TRIGGER_LEVEL_REMOVE_BY_ANY_DATA = 0x02;

    @FieldNumber(1)
    private int mTriggeringRegisterValue;
    @FieldNumber(2)
    private int mCurrentRegisterValue;
    @FieldNumber(3)
    private int mTriggerCount;
    @FieldNumber(4)
    private int mTriggerMode;

    public TriggerInfo(int triggeringRegisterValue, int currentRegisterValue, int triggerCount, int triggerMode) {
        this.mTriggeringRegisterValue = triggeringRegisterValue;
        this.mCurrentRegisterValue = currentRegisterValue;
        this.mTriggerCount = triggerCount;
        this.mTriggerMode = triggerMode;
    }

    /**
     * @return Trigger register value
     */
    public int getTriggeringRegisterValue() {
        return mTriggeringRegisterValue;
    }

    /**
     * @return The value of the current trigger register
     */
    public int getCurrentRegisterValue() {
        return mCurrentRegisterValue;
    }

    /**
     * @return The number of times the terminal has been triggered
     */
    public int getTriggerCount() {
        return mTriggerCount;
    }

    /**
     * @return Terminal trigger type  {@link #TRIGGER_LEVEL_DISABLED} {@link #TRIGGER_LEVEL_REMOVE_BY_BACKEND} {@link #TRIGGER_LEVEL_REMOVE_BY_ANY_DATA}
     */
    public int getTriggerMode() {
        return mTriggerMode;
    }

    /**
     * @return Is the terminal being triggered
     */
    public boolean isTriggering() {
        return (mCurrentRegisterValue != 0 && mTriggeringRegisterValue != 0);
    }

    /**
     * @return Is the terminal enabled for triggering
     */
    public boolean isTriggerEnabled() {
        return mTriggerMode != TRIGGER_LEVEL_DISABLED;
    }

    /**
     * @return Does the terminal need to release the trigger
     */
    public boolean needRemoveTrigger() {
        return mTriggerMode != TRIGGER_LEVEL_DISABLED && mCurrentRegisterValue == 0 && mTriggeringRegisterValue != 0;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    protected TriggerInfo(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<TriggerInfo> CREATOR = new Parcelable.Creator<TriggerInfo>() {
        @Override
        public TriggerInfo createFromParcel(Parcel source) {
            return new TriggerInfo(source);
        }

        @Override
        public TriggerInfo[] newArray(int size) {
            return new TriggerInfo[size];
        }
    };

    @Override
    public String toString() {
        return "TriggerInfo{" +
                "mTriggeringRegisterValue=" + mTriggeringRegisterValue +
                ", mCurrentRegisterValue=" + mCurrentRegisterValue +
                ", mTriggerCount=" + mTriggerCount +
                ", mTriggerMode=" + mTriggerMode +
                '}';
    }
}
