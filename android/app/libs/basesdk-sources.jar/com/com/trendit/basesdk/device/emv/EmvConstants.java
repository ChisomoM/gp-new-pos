package com.trendit.basesdk.device.emv;

public class EmvConstants {

    /**
     * Confirm OK
     */
    public static final int App_Confirm_OK = 1;
    /**
     * Confirm Cancel
     */
    public static final int App_Confirm_Cancel = -1;
    /**
     * Confirm Fail
     */
    public static final int App_Confirm_Failure = -2;

    /**
     * result base
     */
    private static final int EMV_Result_ERR_BASE = -200;

    /**
     * See Phone For Instructions
     */
    public static final int EMV_Result_SeePhoneErr = (EMV_Result_ERR_BASE - 36);

    /**
     * script timeout
     */
    public static final int EMV_Result_Script72TimeOut = (EMV_Result_ERR_BASE - 35);
    /**
     * qpboc reader is not mutual authentication
     */
    public static final int EMV_Result_QpbocAuthNoPerformed = (EMV_Result_ERR_BASE - 34);
    /**
     * qpboc detect multiple cards
     */
    public static final int EMV_Result_QpbocMoreCards = (EMV_Result_ERR_BASE - 33);
    /**
     * qpboc detect no card
     */
    public static final int EMV_Result_QpbocNoCard = (EMV_Result_ERR_BASE - 32);
    /**
     * qpboc data authentication error
     */
    public static final int EMV_Result_QpbocDDAAuthFail = (EMV_Result_ERR_BASE - 31);
    /**
     * e-cash balance lack
     */
    public static final int EMV_Result_EcLackBalanceErr = (EMV_Result_ERR_BASE - 30);
    /**
     * qpboc failed to read last record
     */
    public static final int EMV_Result_QpbocReadLastLogErr = (EMV_Result_ERR_BASE - 29);
    /**
     * the specificed AID not exist
     */
    public static final int EMV_Result_FixedAidAbsentErr = (EMV_Result_ERR_BASE - 28);
    /**
     * e-cash load error
     */
    public static final int EMV_Result_ECLoadErr = (EMV_Result_ERR_BASE - 27);
    /**
     * not support e-cash trade
     */
    public static final int EMV_Result_ECNotSupportErr = (EMV_Result_ERR_BASE - 26);
    /**
     * application expired
     */
    public static final int EMV_Result_AppExpiredErr = (EMV_Result_ERR_BASE - 25);
    /**
     * application is not effective
     */
    public static final int EMV_Result_AppEffectErr = (EMV_Result_ERR_BASE - 24);
    /**
     * use PBOC to handle
     */
    public static final int EMV_Result_UsePbocErr = (EMV_Result_ERR_BASE - 23);
    /**
     * transaction is not accept
     */
    public static final int EMV_Result_TransNotAcceptErr = (EMV_Result_ERR_BASE - 22);
    /**
     * transaction terminated
     */
    public static final int EMV_Result_TransTerminateErr = (EMV_Result_ERR_BASE - 21);
    /**
     * transaction offline decline
     */
    public static final int EMV_Result_TransOfflineDeclineErr = (EMV_Result_ERR_BASE - 20);
    /**
     * transaction online decline
     */
    public static final int EMV_Result_TransOnlineDeclineErr = (EMV_Result_ERR_BASE - 19);
    /**
     * CDA data format error
     */
    public static final int EMV_Result_CDAFormatErr = (EMV_Result_ERR_BASE - 18);
    /**
     * no record
     */
    public static final int EMV_Result_NoLogErr = (EMV_Result_ERR_BASE - 17);
    /**
     * reselect application
     */
    public static final int EMV_Result_AppSelectTryAgainErr = (EMV_Result_ERR_BASE - 16);
    /**
     * application initialization is not accepted
     */
    public static final int EMV_Result_InitAppNotAcceptErr = (EMV_Result_ERR_BASE - 15);
    /**
     * application is locked
     */
    public static final int EMV_Result_AppBlockErr = (EMV_Result_ERR_BASE - 14);
    /**
     * need magnetic card; fallback workflow
     */
    public static final int EMV_Result_NeedMagCardErr = (EMV_Result_ERR_BASE - 13);
    /**
     * read card overtime
     */
    public static final int EMV_Result_AppTimeOutErr = (EMV_Result_ERR_BASE - 12);
    /**
     * card lock
     */
    public static final int EMV_Result_CardBlockErr = (EMV_Result_ERR_BASE - 11);
    /**
     * cancel transaction
     */
    public static final int EMV_Result_CancelTransErr = (EMV_Result_ERR_BASE - 10);
    /**
     * not accept service
     */
    public static final int EMV_Result_NotAcceptErr = (EMV_Result_ERR_BASE - 9);
    /**
     * returned data reduplicated
     */
    public static final int EMV_Result_IccDataRedundErr = (EMV_Result_ERR_BASE - 8);
    /**
     * no application to choose
     */
    public static final int EMV_Result_NoAppSelErr = (EMV_Result_ERR_BASE - 7);
    /**
     * return data error
     */
    public static final int EMV_Result_IccReturnErr = (EMV_Result_ERR_BASE - 6);
    /**
     * return command error
     */
    public static final int EMV_Result_IccCommandErr = (EMV_Result_ERR_BASE - 5);
    /**
     * data format error
     */
    public static final int EMV_Result_IccDataFormatErr = (EMV_Result_ERR_BASE - 4);
    /**
     * online reject
     */
    public static final int EMV_Result_OnlineDecline = (EMV_Result_ERR_BASE - 3);
    /**
     * offline reject
     */
    public static final int EMV_Result_OfflineDecline = (EMV_Result_ERR_BASE - 2);
    /**
     * no PSE directory
     */
    public static final int EMV_Result_PSENotFoundErr = (EMV_Result_ERR_BASE - 1);

    private static final int EMV_Result_OK_BASE = 200;

    /**
     * offline approve
     */
    public static final int EMV_Result_OfflineApprove = (EMV_Result_OK_BASE + 1);
    /**
     * online approve
     */
    public static final int EMV_Result_OnlineApprove = (EMV_Result_OK_BASE + 2);
    /**
     * online wait
     */
    public static final int EMV_Result_OnlineWait = (EMV_Result_OK_BASE + 3);
    /**
     * select user
     */
    public static final int EMV_Result_UserSelect = (EMV_Result_OK_BASE + 4);
    /**
     * display random number
     */
    public static final int EMV_Result_ShowRandNum = (EMV_Result_OK_BASE + 5);
    /**
     * need reference
     */
    public static final int EMV_Result_NeedRefer = (EMV_Result_OK_BASE + 6);
    /**
     * need reversal
     */
    public static final int EMV_Result_NeedReversal = (EMV_Result_OK_BASE + 7);
    /**
     * display log
     */
    public static final int EMV_Result_DispLog = (EMV_Result_OK_BASE + 8);
    /**
     * read the end of log
     */
    public static final int EMV_Result_ReadLogEnd = (EMV_Result_OK_BASE + 9);
    /**
     * transaction online approved
     */
    public static final int EMV_Result_TransOnlineApprove = (EMV_Result_OK_BASE + 10);
    /**
     * transaction offline approved
     */
    public static final int EMV_Result_TransOfflineApprove = (EMV_Result_OK_BASE + 11);
    /**
     * simplify flow
     */
    public static final int EMV_Result_IccEasyFlow = (EMV_Result_OK_BASE + 12);
    /**
     * read e-cash balance
     */
    public static final int EMV_Result_ReadECBalance = (EMV_Result_OK_BASE + 13);
    /**
     * APRC error; but the card allow transaction success
     */
    public static final int EMV_Result_TransOK_ARPCErr = (EMV_Result_OK_BASE + 14);
    /**
     * qpboc trans no CAPK
     */
    public static final int EMV_Result_ICCNoCapk = (EMV_Result_OK_BASE + 15);
    /**
     * not support offline
     */
    public static final int EMV_Result_OfflineNotSupport = (EMV_Result_OK_BASE + 16);
    /**
     * paywave IUP need try again
     */
    public static final int EMV_Result_PAYWAVEIUPTRYAGAIN = (EMV_Result_OK_BASE + 17);

}
