package com.trendit.basesdk.device.icc;

/**
 * IC card insertion callback
 */
public abstract class OnICCCardHandlerListener {
    /**
     * Call back this interface when card search is successful or error occurs
     *
     * @param retCode 检测结果 {@link com.trendit.basesdk.card.CardConstants}
     * @param result  Card search data
     */
    public abstract void handleCardReaderResult(int retCode, ICCCardSearchResult result);
}
