package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

import java.util.Arrays;

/**
 * Express Pay Dynamic Reader Limits
 */
public class ExpressPayDRLParam extends BaseParcelable implements Parcelable {

    @FieldNumber(1)
    private byte setID;
    @FieldNumber(2)
    private byte[] transLimit;
    @FieldNumber(3)
    private byte[] floorLimit;
    @FieldNumber(4)
    private byte[] CVMLimit;


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public ExpressPayDRLParam() {

    }

    protected ExpressPayDRLParam(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<ExpressPayDRLParam> CREATOR = new Parcelable.Creator<ExpressPayDRLParam>() {
        @Override
        public ExpressPayDRLParam createFromParcel(Parcel source) {
            return new ExpressPayDRLParam(source);
        }

        @Override
        public ExpressPayDRLParam[] newArray(int size) {
            return new ExpressPayDRLParam[size];
        }
    };

    /**
     * Get the set id
     *
     * @return the set id
     */
    public byte getSetID() {
        return setID;
    }

    /**
     * Set the set id
     *
     * @param setID set id
     */
    public void setSetID(byte setID) {
        this.setID = setID;
    }

    /**
     * Get the Reader Contactless Transaction Limit (6 bytes)
     *
     * @return Reader Contactless Transaction Limit
     */
    public byte[] getTransLimit() {
        return transLimit;
    }

    /**
     * Set the Reader Contactless Transaction Limit (6 bytes)
     *
     * @param transLimit Reader Contactless Transaction Limit
     */
    public void setTransLimit(byte[] transLimit) {
        this.transLimit = transLimit;
    }

    /**
     * Get the Reader Contactless Floor Limit  (6 bytes)
     *
     * @return Reader Contactless Floor Limit
     */
    public byte[] getFloorLimit() {
        return floorLimit;
    }

    /**
     * Set the Reader Contactless Floor Limit  (6 bytes)
     *
     * @param floorLimit Reader Contactless Floor Limit
     */
    public void setFloorLimit(byte[] floorLimit) {
        this.floorLimit = floorLimit;
    }

    /**
     * Get the Reader CVM Required Limit (6 bytes)
     *
     * @return the Reader CVM Required Limit
     */
    public byte[] getCVMLimit() {
        return CVMLimit;
    }

    /**
     * Set the Reader CVM Required Limit (6 bytes)
     *
     * @param CVMLimit the Reader CVM Required Limit
     */
    public void setCVMLimit(byte[] CVMLimit) {
        this.CVMLimit = CVMLimit;
    }

    @Override
    public String toString() {
        return "ExpressPayDRLParam{" +
                "setID=" + (setID & 0xFF) +
                ", transLimit=" + ByteUtils.byteArray2HexString(transLimit) +
                ", floorLimit=" + ByteUtils.byteArray2HexString(floorLimit) +
                ", CVMLimit=" + ByteUtils.byteArray2HexString(CVMLimit) +
                '}';
    }
}
