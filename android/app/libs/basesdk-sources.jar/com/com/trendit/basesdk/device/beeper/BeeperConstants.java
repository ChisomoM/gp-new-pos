package com.trendit.basesdk.device.beeper;


public class BeeperConstants {

    /**
     * Buzzer sound frequency (for reference)
     */
    public static final int DEFAULT_FREQUENCY = 1050;

    /**
     * The duration of sound production (for reference)
     */
    public static final int DEFAULT_BEEP_ON_TIME = 200;

    /**
     * The duration of silence (for reference)
     */
    public static final int DEFAULT_BEEP_OFF_TIME = 100;

}
