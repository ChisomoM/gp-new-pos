package com.trendit.basesdk.device.msr;

public class MSRConstants {

    /**
     * There are no errors.
     * <p>
     * This constant is passed through<code>{@link MSRTrackData#getTrack1ErrorCode()} </code> return.
     */
    public static final int NO_ERROR = 1;

    /**
     * Unknown reason error.
     * <p>
     * This constant is passed through<code>{@link MSRTrackData#getTrack1ErrorCode()} </code> return.
     */
    public static final int NON_SPECIFIC_ERROR = 2;

    /**
     * Unsupported track.
     * <p>
     * This constant is passed through<code>{@link MSRTrackData#getTrack1ErrorCode()} </code> return.
     */
    public static final int TRACK_NOT_SUPPORTED = 3;

    /**
     * This track is reading incorrectly.
     * <p>
     * This constant is passed through<code>{@link MSRTrackData#getTrack1ErrorCode()} </code> return.
     */
    public static final int READ_ERROR = 4;

    /**
     * Parity error on this track.
     * <p>
     * This constant is passed through<code>{@link MSRTrackData#getTrack1ErrorCode()} </code> return.
     */
    public static final int PARITY_ERROR = 5;

    /**
     * LRC error on this track.
     * <p>
     * This constant is passed through<code>{@link MSRTrackData#getTrack1ErrorCode()} </code> return.
     */
    public static final int LRC_ERROR = 6;

    /**
     * This track has no data information body, only the start bit.
     * <p>
     * This constant is passed through<code>{@link MSRTrackData#getTrack1ErrorCode()} </code> return.
     */
    public static final int NO_DATA = 7;

    /**
     * This track does not have any data, including the start bit.
     * <p>
     * This constant is passed through<code>{@link MSRTrackData#getTrack1ErrorCode()} </code> return.
     */
    public static final int NO_STRIPE = 8;
}
