package com.trendit.basesdk.device.printer.format;


import android.os.Parcel;
import android.os.Parcelable;

/**
 * Barcode text display position
 */
public enum PrintBarCodeHriLocation implements Parcelable {

    /**
     * Barcode does not contain hri
     */
    FORMAT_BARCODE_HRI_LOCATION_NONE(0),
    /**
     * Hri is located above
     */
    FORMAT_BARCODE_HRI_LOCATION_UP(1),
    /**
     * Hri located below
     */
    FORMAT_BARCODE_HRI_LOCATION_DOWN(2),
    /**
     * Hri located above and below
     */
    FORMAT_BARCODE_HRI_LOCATION_UP_DOWN(3);


    private int barcodeHriLocation;


    PrintBarCodeHriLocation(int barcodeHriLocation) {
        this.barcodeHriLocation = barcodeHriLocation;
    }

    public int getBarcodeHriLocation() {
        return this.barcodeHriLocation;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeInt(ordinal());
    }

    public static final Creator<PrintBarCodeHriLocation> CREATOR = new Creator<PrintBarCodeHriLocation>() {

        @Override
        public PrintBarCodeHriLocation createFromParcel(Parcel parcel) {
            int ordinal = parcel.readInt();
            for (PrintBarCodeHriLocation barcodeHriLocation : PrintBarCodeHriLocation.values()) {
                if (barcodeHriLocation.ordinal() == ordinal) {
                    return barcodeHriLocation;
                }
            }
            return null;
        }

        @Override
        public PrintBarCodeHriLocation[] newArray(int size) {
            return new PrintBarCodeHriLocation[size];
        }
    };
}
