package com.trendit.basesdk.device.printer.format;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.FieldNumber;


/**
 * Barcode printing format
 */
public class BarCodeFormat extends BaseParcelable implements Parcelable {
    @FieldNumber(1)
    private PrintAlign align = PrintAlign.FORMAT_ALIGN_LEFT;
    @FieldNumber(2)
    private PrintBarCodeHriLocation hriLocation = PrintBarCodeHriLocation.FORMAT_BARCODE_HRI_LOCATION_DOWN;
    @FieldNumber(3)
    private PrintBarCodeType barCodeType = PrintBarCodeType.BARCODE_TYPE_CODE39;
    @FieldNumber(4)
    private int width;
    @FieldNumber(5)
    private int height;

    /**
     * Obtain printing location
     *
     * @return printing location
     */
    public PrintAlign getAlign() {
        return align;
    }

    /**
     * Set printing location
     *
     * @param align printing location
     */
    public void setAlign(PrintAlign align) {
        this.align = align;
    }

    /**
     * Obtain the display position of barcode text content for printing
     *
     * @return the display position of barcode text content for printing
     */
    public PrintBarCodeHriLocation getHriLocation() {
        return hriLocation;
    }

    /**
     * Set the display position of barcode text content for printing
     *
     * @param hriLocation the display position of barcode text content for printing
     */
    public void setHriLocation(PrintBarCodeHriLocation hriLocation) {
        this.hriLocation = hriLocation;
    }


    /**
     * Obtain barcode type
     *
     * @return barcode type
     */
    public PrintBarCodeType getBarCodeType() {
        return barCodeType;
    }

    /**
     * Set barcode type
     *
     * @param barCodeType barcode type
     */
    public void setBarCodeType(PrintBarCodeType barCodeType) {
        this.barCodeType = barCodeType;
    }

    /**
     * Obtain the width of barcode printing
     *
     * @return Width of barcode printing
     */
    public int getWidth() {
        return width;
    }

    /**
     * Set the width of barcode printing
     *
     * @param width Width of barcode printing
     */
    public void setWidth(int width) {
        this.width = width;
    }

    /**
     * Obtain the height of barcode printing
     *
     * @return Height of barcode printing
     */
    public int getHeight() {
        return height;
    }

    /**
     * Set the height of barcode printing
     *
     * @param height Height of barcode printing
     */
    public void setHeight(int height) {
        this.height = height;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }

    public BarCodeFormat() {
    }

    protected BarCodeFormat(Parcel in) {
        readFromParcelable(in);
    }

    public static final Creator<BarCodeFormat> CREATOR = new Creator<BarCodeFormat>() {
        @Override
        public BarCodeFormat createFromParcel(Parcel source) {
            return new BarCodeFormat(source);
        }

        @Override
        public BarCodeFormat[] newArray(int size) {
            return new BarCodeFormat[size];
        }
    };

    @Override
    public String toString() {
        return "BarCodeFormat{" +
                "align=" + align +
                ", hriLocation=" + hriLocation +
                ", barCodeType=" + barCodeType +
                ", width=" + width +
                ", height=" + height +
                '}';
    }
}
