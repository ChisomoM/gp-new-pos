package com.trendit.basesdk.utils;

import android.os.Parcel;
import android.os.Parcelable;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class BaseParcelable {

    private static class FieldComparator implements Comparator<Field> {

        @Override
        public int compare(Field field1, Field field2) {
            FieldNumber annotation1 = field1.getAnnotation(FieldNumber.class);
            FieldNumber annotation2 = field2.getAnnotation(FieldNumber.class);

            if (annotation1 != null && annotation2 != null) {
                int value1 = annotation1.value();
                int value2 = annotation2.value();
                return (value1 < value2) ? -1 : ((value1 == value2) ? 0 : 1);
            }
            // If one of the fields has the annotation and the other doesn't, prioritize the one with the annotation.
            return (annotation1 != null) ? -1 : ((annotation2 != null) ? 1 : 0);
        }
    }

    private Field[] getInstanceFields(Class<?> clazz) {
        List<Field> instanceFields = new ArrayList<Field>();
        Field[] fields = clazz.getDeclaredFields();

        for (Field field : fields) {
            boolean isStaticField = java.lang.reflect.Modifier.isStatic(field.getModifiers());
            FieldNumber fieldNumber = field.getAnnotation(FieldNumber.class);
            boolean isAnnotationField = fieldNumber != null && fieldNumber.value() > 0;
            if (!isStaticField && isAnnotationField) {
                instanceFields.add(field);
            }
        }
        return instanceFields.toArray(new Field[0]);
    }

    private boolean isType(Field field, Class<?>... classes) {
        if (field == null) {
            return false;
        }

        Class<?> fieldType = field.getType();
        for (Class<?> cls : classes) {
            if (cls.isAssignableFrom(fieldType)) {
                return true;
            }
        }
        return false;
    }

    private boolean isArrayType(Field field, Class<?>... classes) {
        if (field == null || !field.getType().isArray()) {
            return false;
        }

        Class<?> componentType = field.getType().getComponentType();
        for (Class<?> cls : classes) {
            if (cls.isAssignableFrom(componentType)) {
                return true;
            }
        }
        return false;
    }

    private boolean isParcelableClass(Field field) {
        if (field == null) {
            return false;
        }
        Class<?> cls = field.getType();
        return !cls.isEnum() && !cls.isArray() && Parcelable.class.isAssignableFrom(field.getType());
    }

    private boolean isParcelableClassArray(Field field) {
        if (field == null) {
            return false;
        }
        Class<?> cls = field.getType();
        return !cls.isEnum() && cls.isArray() && Parcelable.class.isAssignableFrom(field.getType().getComponentType());
    }

    private boolean isEnum(Field field) {
        return field != null && field.getType().isEnum();
    }

    public void readFromParcelable(Parcel in) {
        try {
            int dataSize = in.readInt();
            int position = in.dataPosition();
            Field[] fields = getInstanceFields(this.getClass());
            Arrays.sort(fields, new FieldComparator());
            for (Field field : fields) {
                int readSize = in.dataPosition() - position;
                if (readSize >= dataSize) {
                    break;
                }
                field.setAccessible(true);
                if (isType(field, int.class, Integer.class)) {
                    int value = in.readInt();
                    field.set(this, value);
                } else if (isArrayType(field, int.class, Integer.class)) {
                    int[] value = in.createIntArray();
                    field.set(this, value);
                } else if (isType(field, long.class, Long.class)) {
                    long value = in.readLong();
                    field.set(this, value);
                } else if (isArrayType(field, long.class, Long.class)) {
                    long[] value = in.createLongArray();
                    field.set(this, value);
                } else if (isType(field, String.class)) {
                    String value = in.readString();
                    field.set(this, value);
                } else if (isArrayType(field, String.class)) {
                    String[] value = in.createStringArray();
                    field.set(this, value);
                } else if (isType(field, boolean.class, Boolean.class)) {
                    boolean value = in.readByte() != 0;
                    field.set(this, value);
                } else if (isArrayType(field, boolean.class, Boolean.class)) {
                    boolean[] value = in.createBooleanArray();
                    field.set(this, value);
                } else if (isType(field, byte.class, Byte.class)) {
                    byte value = in.readByte();
                    field.set(this, value);
                } else if (isArrayType(field, byte.class, Byte.class)) {
                    byte[] value = in.createByteArray();
                    field.set(this, value);
                } else if (isParcelableClass(field)) {
                    Parcelable value = in.readParcelable(field.getDeclaringClass().getClassLoader());
                    field.set(this, value);
                } else if (isParcelableClassArray(field)) {
                    Class<?> cls = field.getType().getComponentType();
                    Field creatorField = cls.getDeclaredField("CREATOR");
                    Parcelable.Creator<?> creator = (Parcelable.Creator<?>) creatorField.get(null);
                    field.set(this, in.createTypedArray(creator));
                } else if (isEnum(field)) {
                    int value = in.readInt();
                    Object[] enumConstants = field.getType().getEnumConstants();
                    field.set(this, value == -1 ? null : enumConstants[value]);
                } else {
                    android.util.Log.e("POS &&&", "read unknown type : " + field.getType());
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void writeFromParcel(Parcel dest, int flags) {
        try {
            int dataSizePosition = dest.dataPosition();
            dest.writeInt(0);
            Field[] fields = getInstanceFields(this.getClass());
            Arrays.sort(fields, new FieldComparator());
            for (Field field : fields) {
                field.setAccessible(true);
                Object value = field.get(this);
                if (isType(field, int.class, Integer.class)) {
                    dest.writeInt((Integer) value);
                } else if (isArrayType(field, int.class, Integer.class)) {
                    dest.writeIntArray((int[]) value);
                } else if (isType(field, long.class, Long.class)) {
                    dest.writeLong((Long) value);
                } else if (isArrayType(field, long.class, Long.class)) {
                    dest.writeLongArray((long[]) value);
                } else if (isType(field, String.class)) {
                    dest.writeString((String) value);
                } else if (isArrayType(field, String.class)) {
                    dest.writeStringArray((String[]) value);
                } else if (isType(field, boolean.class, Boolean.class)) {
                    dest.writeByte((byte) (((Boolean) value) ? 1 : 0));
                } else if (isArrayType(field, boolean.class, Boolean.class)) {
                    dest.writeBooleanArray((boolean[]) value);
                } else if (isType(field, byte.class, Byte.class)) {
                    dest.writeByte((Byte) value);
                } else if (isArrayType(field, byte.class, Byte.class)) {
                    dest.writeByteArray((byte[]) value);
                } else if (isParcelableClass(field)) {
                    dest.writeParcelable((Parcelable) value, flags);
                } else if (isParcelableClassArray(field)) {
                    dest.writeTypedArray((Parcelable[]) value, flags);
                } else if (isEnum(field)) {
                    int ordinal = value == null ? -1 : ((Enum<?>) value).ordinal();
                    dest.writeInt(ordinal);
                } else {
                    android.util.Log.e("POS &&&", "write unknown type : " + field.getType());
                    break;
                }
            }
            int dataSize = dest.dataPosition() - dataSizePosition - 4;
            dest.setDataPosition(dataSizePosition);
            dest.writeInt(dataSize);
            dest.setDataPosition(dataSizePosition + dataSize + 4);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
