package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

/**
 * EMV processing result
 */
public class TradeResult extends BaseParcelable implements Parcelable {
    @FieldNumber(1)
    private int channelType;
    @FieldNumber(2)
    private byte[] TVR;
    @FieldNumber(3)
    private byte[] TSI;
    @FieldNumber(4)
    private int kernelID;
    @FieldNumber(5)
    private int currentTransType;
    @FieldNumber(6)
    private boolean needSignature;


    /**
     * Get the channel type
     * {@link EMVTransData#Channel_Type_IC} {@link EMVTransData#Channel_Type_RF}
     *
     * @return channel type
     */
    public int getChannelType() {
        return channelType;
    }

    /**
     * Set the channel type
     *
     * @param channelType channel type
     */
    public void setChannelType(int channelType) {
        this.channelType = channelType;
    }

    /**
     * Get the TVR ((Refer to EMV Book 3)
     *
     * @return TVR
     */
    public byte[] getTVR() {
        return TVR;
    }

    /**
     * Set the TVR (Refer to EMV Book 3)
     *
     * @param TVR TVR
     */
    public void setTVR(byte[] TVR) {
        this.TVR = TVR;
    }

    /**
     * Get the TSI (Refer to EMV Book 3)
     *
     * @return TSI
     */
    public byte[] getTSI() {
        return TSI;
    }

    /**
     * Set the TSI (Refer to EMV Book 3)
     *
     * @param TSI tsi
     */
    public void setTSI(byte[] TSI) {
        this.TSI = TSI;
    }

    /**
     * Get the KernelID
     *
     * @return kernelID
     */
    public KernelID getKernelID() {
        return KernelID.valueOf(kernelID);
    }

    /**
     * Set the kernelID
     *
     * @param kernelID kernelID
     */
    public void setKernelID(KernelID kernelID) {
        this.kernelID = kernelID.getId();
    }

    /**
     * Get the trans type
     *
     * @return trans type
     */
    public TransType getCurrentTransType() {
        return TransType.valueOf(currentTransType);
    }

    /**
     * Set the trans type
     *
     * @param currentTransType trans type
     */
    public void setCurrentTransType(TransType currentTransType) {
        this.currentTransType = currentTransType.getType();
    }

    /**
     * return If Signature need this transaction
     *
     * @return need or not
     */
    public boolean isNeedSignature() {
        return needSignature;
    }

    /**
     * Set If Signature need this transaction
     *
     * @param needSignature need or not
     */
    public void setNeedSignature(boolean needSignature) {
        this.needSignature = needSignature;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        writeFromParcel(dest, flags);
    }
    public TradeResult() {
    }

    protected TradeResult(Parcel in) {
        readFromParcelable(in);
    }

    public static final Parcelable.Creator<TradeResult> CREATOR = new Parcelable.Creator<TradeResult>() {
        @Override
        public TradeResult createFromParcel(Parcel source) {
            return new TradeResult(source);
        }

        @Override
        public TradeResult[] newArray(int size) {
            return new TradeResult[size];
        }
    };

    @Override
    public String toString() {
        return "TradeResult{" +
                "channelType=" + channelType +
                ", TVR=" + ByteUtils.byteArray2HexString(TVR) +
                ", TSI=" + ByteUtils.byteArray2HexString(TSI) +
                ", kernelID=" + kernelID +
                ", currentTransType=" + currentTransType +
                ", needSignature=" + needSignature +
                '}';
    }
}
