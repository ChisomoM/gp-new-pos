package com.trendit.basesdk.device.printer.format;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Print the line attribute of text
 */
public enum PrintFontLineThrough implements Parcelable {
    /**
     * Normal
     */
    FORMAT_NORMAL(0),
    /**
     * Continuous strikethrough
     */
    FORMAT_STRIKE_THROUGH(1),
    /**
     * Break strikethrough
     */
    FORMAT_STRIKE_THROUGH_BROKEN(2),
    /**
     * underline
     */
    FORMAT_UNDERLINE(3);

    private int lineThrough;

    PrintFontLineThrough(int lineThrough) {
        this.lineThrough = lineThrough;
    }

    public int getLineThrough() {
        return this.lineThrough;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeInt(ordinal());
    }

    public static final Parcelable.Creator<PrintFontLineThrough> CREATOR = new Parcelable.Creator<PrintFontLineThrough>() {

        @Override
        public PrintFontLineThrough createFromParcel(Parcel parcel) {
            int ordinal = parcel.readInt();
            for (PrintFontLineThrough fontLineThrough : PrintFontLineThrough.values()) {
                if (fontLineThrough.ordinal() == ordinal) {
                    return fontLineThrough;
                }
            }
            return null;
        }

        @Override
        public PrintFontLineThrough[] newArray(int size) {
            return new PrintFontLineThrough[size];
        }
    };
}
