package com.trendit.basesdk.device.printer;

import android.graphics.Bitmap;

import com.trendit.basesdk.device.printer.format.BarCodeFormat;
import com.trendit.basesdk.device.printer.format.BitmapFormat;
import com.trendit.basesdk.device.printer.format.PrintDensity;
import com.trendit.basesdk.device.printer.format.QrCodeFormat;
import com.trendit.basesdk.device.printer.format.TextFormat;

/**
 * <b>PrinterDevice</b>Define the interface of the printer device
 * <pre>
 * PrinterDevice device = POSDeviceManager.getInstance().getPrinterDevice();
 * </pre>
 * The caller cannot create the object through new
 */
public abstract class PrinterDevice {


    /**
     * Set Print Density
     *
     * @param density Print Density
     * @see com.trendit.basesdk.device.printer.format.PrintDensity
     */
    public abstract void setPrintDensity(PrintDensity density);

    /**
     * Get Print Density
     *
     * @return Print density
     * @see com.trendit.basesdk.device.printer.format.PrintDensity
     */
    public abstract PrintDensity getPrintDensity();

    /**
     * Print Text
     *
     * @param format  print format
     * @param message print contents
     * @see TextFormat
     */
    public abstract void printText(TextFormat format, String message);


    /**
     * Print left right aligned text
     *
     * @param format    print format
     * @param textLeft  Left content
     * @param textRight Right content
     * @see TextFormat
     */
    public abstract void printMultiText(TextFormat format, String textLeft, String textRight);


    /**
     * Print dashed lines
     *
     * @param format print format
     * @param lines  Number of dashed lines to be printed
     */
    public abstract void printDottedLines(TextFormat format, int lines);


    /**
     * print a picture
     *
     * @param format Format of images
     * @param bitmap Picture content
     * @see BitmapFormat
     */
    public abstract void printBitmap(BitmapFormat format, Bitmap bitmap);


    /**
     * Print barcode
     *
     * @param format  Barcode format
     * @param barcode Barcode content
     * @see BarCodeFormat
     */
    public abstract void printBarCode(BarCodeFormat format, String barcode);


    /**
     * Print QR code
     *
     * @param format QR code format
     * @param qrcode QR code content
     * @see QrCodeFormat
     */
    public abstract void printQrCode(QrCodeFormat format, String qrcode);


    /**
     * Start printing task
     *
     * @param listener printing task callback
     */
    public abstract void startPrint(final OnPrintTaskListener listener);


    /**
     * Cancel the current printing task
     */
    public abstract void cancel();


    /**
     * Clear the set print content
     */
    public abstract void clear();


    /**
     * Send printer instructions to the printer
     *
     * @param esc instructions
     * @return true or false
     */
    public abstract boolean sendESCCommand(byte[] esc);


    /**
     * Query printer status
     *
     * @return printer status
     * @see PrinterConstants
     */
    public abstract int queryStatus();


    /**
     * Printer paper cutting
     *
     * @return true or false
     */
    public abstract boolean cutPaper();


    /**
     * Obtain the default printer printing text format
     *
     * @return default printer printing text format
     * @see TextFormat
     */
    public abstract TextFormat getDefaultTextFormat();

    /**
     * Obtain the default printer print image format
     *
     * @return default printer print image format
     * @see BitmapFormat
     */
    public abstract BitmapFormat getDefaultBitmapFormat();


    /**
     * Obtain the default printer printing barcode format
     *
     * @return default printer printing barcode format
     * @see BarCodeFormat
     */
    public abstract BarCodeFormat getDefaultBarCodeFormat();


    /**
     * Obtain the default printer printing QR code format
     *
     * @return default printer printing QR code format
     * @see QrCodeFormat
     */
    public abstract QrCodeFormat getDefaultQrCodeFormat();


}
