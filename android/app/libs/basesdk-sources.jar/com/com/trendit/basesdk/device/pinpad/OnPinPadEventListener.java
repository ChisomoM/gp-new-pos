package com.trendit.basesdk.device.pinpad;

/**
 * The Input PIN Callback
 */
public abstract class OnPinPadEventListener {
    /**
     * Input password end callback
     *
     * @param retCode {@link PINPadConstants#RESULT_SUCCESS} {@link PINPadConstants#RESULT_CANCEL} {@link PINPadConstants#RESULT_BY_PASS} {@link PINPadConstants#RESULT_GENERAL_ERROR} {@link PINPadConstants#RESULT_ERR_TIMEOUT} {@link PINPadConstants#RESULT_ERR_PARAM}
     * @param data    pinBlock
     */
    public abstract void onInputResult(int retCode, byte[] data);

    /**
     * Callback when key click
     *
     * @param len     The length of the currently input password
     * @param keyCode {@link PINPadConstants#KEYCODE_CANCEL} {@link PINPadConstants#KEYCODE_CLEAR} {@link PINPadConstants#KEYCODE_CONFIRM} {@link PINPadConstants#KEYCODE_STAR} {@link PINPadConstants#KEYCODE_BY_PASS_PIN}
     */
    public abstract void onSendKey(int len, byte keyCode);
}
