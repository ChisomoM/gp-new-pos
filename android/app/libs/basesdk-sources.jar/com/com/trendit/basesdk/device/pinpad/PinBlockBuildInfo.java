package com.trendit.basesdk.device.pinpad;

import android.os.Parcel;
import android.os.Parcelable;

import com.trendit.basesdk.utils.BaseParcelable;
import com.trendit.basesdk.utils.ByteUtils;
import com.trendit.basesdk.utils.FieldNumber;

public class PinBlockBuildInfo extends BaseParcelable implements Parcelable {
    @FieldNumber(1)
    private int keyAlgorithmType;
    @FieldNumber(2)
    private int keyIndex;
    @FieldNumber(3)
    private int pinBlockMode;
    @FieldNumber(4)
    private String cardNO;
    @FieldNumber(5)
    private long amount;
    @FieldNumber(6)
    private boolean dukptKey;
    @FieldNumber(7)
    private int deriveType;
    @FieldNumber(8)
    private int minInputLen;
    @FieldNumber(9)
    private int maxInputLen;
    @FieldNumber(10)
    private boolean enableByPass;
    @FieldNumber(11)
    private boolean voicePrompt;
    @FieldNumber(12)
    private byte[] panBlock;
    @FieldNumber(13)
    private int pinRetryCount;

    /**
     * @param keyAlgorithmType key algorithm type form {@link PINPadConstants#KEY_ALGORITHM_TYPE_DES_1} to {@link PINPadConstants#KEY_ALGORITHM_TYPE_AES_256}
     * @param keyIndex         key index (0-9)
     * @param pinBlockMode     pinBlock mode form {@link PINPadConstants#PINBLOCK_MODE_ISO_9564_0} to {@link PINPadConstants#PINBLOCK_MODE_ISO_9564_4}
     * @param cardNO           card no
     * @param panBlock         the pan block
     * @param minInputLen      min input password len
     * @param maxInputLen      max input password len
     */
    public PinBlockBuildInfo(int keyAlgorithmType, int keyIndex, int pinBlockMode, String cardNO, byte[] panBlock, int minInputLen, int maxInputLen) {
        this.keyAlgorithmType = keyAlgorithmType;
        this.keyIndex = keyIndex;
        this.pinBlockMode = pinBlockMode;
        this.cardNO = cardNO;
        this.panBlock = panBlock;
        this.minInputLen = minInputLen;
        this.maxInputLen = maxInputLen;
    }

    protected PinBlockBuildInfo(Parcel in) {
        readFromParcelable(in);
    }

    public static final Creator<PinBlockBuildInfo> CREATOR = new Creator<PinBlockBuildInfo>() {
        @Override
        public PinBlockBuildInfo createFromParcel(Parcel in) {
            return new PinBlockBuildInfo(in);
        }

        @Override
        public PinBlockBuildInfo[] newArray(int size) {
            return new PinBlockBuildInfo[size];
        }
    };

    /**
     * @param minInputLen the min input password len
     */
    public void setMinInputLen(int minInputLen) {
        this.minInputLen = minInputLen;
    }

    /**
     * @param maxInputLen the max input password len
     */
    public void setMaxInputLen(int maxInputLen) {
        this.maxInputLen = maxInputLen;
    }

    /**
     * @param enableByPass enable to pass input password
     */
    public void setEnableByPass(boolean enableByPass) {
        this.enableByPass = enableByPass;
    }

    /**
     * @param amount trans amount
     */
    public void setAmount(long amount) {
        this.amount = amount;
    }

    /**
     * @param voicePrompt need voice prompt when input password
     */
    public void setVoicePrompt(boolean voicePrompt) {
        this.voicePrompt = voicePrompt;
    }

    /**
     * @param dukptKey set the pin key type is dukpt ?
     */
    public void setDukptKey(boolean dukptKey) {
        this.dukptKey = dukptKey;
    }

    /**
     * when the pin key tpye is dukpt, need to set derive type
     *
     * @param deriveType derive type form {@link PINPadConstants#DUKPT_AES_DERIVE_KEY_TYPE_DES2} to {@link PINPadConstants#DUKPT_AES_DERIVE_KEY_TYPE_AES256}
     */
    public void setDeriveType(int deriveType) {
        this.deriveType = deriveType;
    }

    public void setPinRetryCount(int pinRetryCount) {
        this.pinRetryCount = pinRetryCount;
    }

    /**
     * @return key algorithm type form {@link PINPadConstants#KEY_ALGORITHM_TYPE_DES_1} to {@link PINPadConstants#KEY_ALGORITHM_TYPE_AES_256}
     */
    public int getKeyAlgorithmType() {
        return keyAlgorithmType;
    }

    /**
     * @return key index (0-9)
     */
    public int getKeyIndex() {
        return keyIndex;
    }

    /**
     * @return pin block mode form {@link PINPadConstants#PINBLOCK_MODE_ISO_9564_0} to {@link PINPadConstants#PINBLOCK_MODE_ISO_9564_4}
     */
    public int getPinBlockMode() {
        return pinBlockMode;
    }

    /**
     * @return derive type form {@link PINPadConstants#DUKPT_AES_DERIVE_KEY_TYPE_DES2} to {@link PINPadConstants#DUKPT_AES_DERIVE_KEY_TYPE_AES256}
     */
    public int getDeriveType() {
        return deriveType;
    }

    /**
     * @return min input password len
     */
    public int getMinInputLen() {
        return minInputLen;
    }

    /**
     * @return max input password len
     */
    public int getMaxInputLen() {
        return maxInputLen;
    }

    /**
     * @return is enable to pass input password when click confirm button
     */
    public boolean isEnableByPass() {
        return enableByPass;
    }

    /**
     * @return Is it a dukpt key
     */
    public boolean isDukptKey() {
        return dukptKey;
    }

    /**
     * @return card no
     */
    public String getCardNO() {
        return cardNO;
    }

    /**
     * @return trans amount
     */
    public long getAmount() {
        return amount;
    }

    /**
     * @return Is has voice prompt when input password.
     */
    public boolean isVoicePrompt() {
        return voicePrompt;
    }

    /**
     * @return pan block
     */
    public byte[] getPanBlock() {
        return panBlock;
    }

    public int getPinRetryCount() {
        return pinRetryCount;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        writeFromParcel(parcel, i);
    }
    @Override
    public String toString() {
        return "PinBlockBuildInfo{" +
                "keyAlgorithmType=" + keyAlgorithmType +
                ", keyIndex=" + keyIndex +
                ", pinBlockMode=" + pinBlockMode +
                ", cardNO='" + cardNO + '\'' +
                ", amount=" + amount +
                ", dukptKey=" + dukptKey +
                ", deriveType=" + deriveType +
                ", minInputLen=" + minInputLen +
                ", maxInputLen=" + maxInputLen +
                ", enableByPass=" + enableByPass +
                ", voicePrompt=" + voicePrompt +
                ", panBlock=" + ByteUtils.byteArray2HexString(panBlock) +
                '}';
    }
}
