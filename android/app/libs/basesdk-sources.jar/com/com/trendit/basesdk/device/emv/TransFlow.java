package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

public enum TransFlow implements Parcelable {

    /**
     * intact flow
     */
    SDK_ICC_ALL_FLOW(0x01),

    /**
     * simplified flow
     */
    SDK_ICC_EASY_FLOW(0x02),

    /**
     * query e-cash balance
     */
    SDK_ICC_EC_QUERY(0x03),

    /**
     * load
     */
    SDK_ICC_EC_LOAD(0x04),

    /**
     * read log
     */
    SDK_ICC_READLOG(0x05);

    private final int flow;

    TransFlow(int flow) {
        this.flow = flow;
    }

    public int getFlow() {
        return flow;
    }


    public static TransFlow valueOf(int value) {
        TransFlow[] transFlows = TransFlow.values();
        for (TransFlow transFlow : transFlows) {
            if (transFlow.getFlow() == value) {
                return transFlow;
            }
        }
        return null;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(ordinal());
    }

    public static final Parcelable.Creator<TransFlow> CREATOR = new Parcelable.Creator<TransFlow>() {
        @Override
        public TransFlow createFromParcel(Parcel parcel) {
            int ordinal = parcel.readInt();
            for (TransFlow flow : TransFlow.values()) {
                if (flow.ordinal() == ordinal) {
                    return flow;
                }
            }
            return null;
        }

        @Override
        public TransFlow[] newArray(int size) {
            return new TransFlow[size];
        }
    };
}
