package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Environment:                     Operating Control
 * Financial Institution(F)  Merchant(M)  Cardholder(C)
 * All Server (SERVER):
 * Only online(ON)                        11      21          --
 * The offline have the ability to online(ON_OFF) 12    22        --
 * Only offline(OFF)               13     23          --
 * <p>
 * Self-service(SELF):
 * Only online(ON)                 14     24      34
 * The offline have the ability to online(ON_OFF) 15  25      35
 * Only offline(OFF)                16        26      36
 * Remarks: The terminals which type is '14','15','16' and have cash payment ability(subjoin terminal performance byte 1, 'cash' bit = '1') can be regard as ATM
 * other type terminals cannot be regard as ATM
 */
public enum TerminalType implements Parcelable {

    TYPE_F_SERVER_ON(0x11),
    TYPE_F_SERVER_ON_OFF(0x12),
    TYPE_F_SERVER_OFF(0x13),
    TYPE_F_SELF_ON(0x14),
    TYPE_F_SELF_ON_OFF(0x15),
    TYPE_F_SELF_OFF(0x16),
    TYPE_M_SERVER_ON(0x21),
    TYPE_M_SERVER_ON_OFF(0x22),
    TYPE_M_SERVER_OFF(0x23),
    TYPE_M_SELF_ON(0x24),
    TYPE_M_SELF_ON_OFF(0x25),
    TYPE_M_SELF_OFF(0x26),
    TYPE_C_SELF_ON(0x34),
    TYPE_C_SELF_ON_OFF(0x35),
    TYPE_C_SELF_OFF(0x36);


    private int type;

    TerminalType(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public static TerminalType valueOf(int value) {
        TerminalType[] terminalTypes = TerminalType.values();
        for (TerminalType terminalType : terminalTypes) {
            if (terminalType.getType() == value) {
                return terminalType;
            }
        }
        return null;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(ordinal());
    }

    public static final Parcelable.Creator<TerminalType> CREATOR = new Parcelable.Creator<TerminalType>() {
        @Override
        public TerminalType createFromParcel(Parcel parcel) {
            int ordinal = parcel.readInt();
            for (TerminalType flow : TerminalType.values()) {
                if (flow.ordinal() == ordinal) {
                    return flow;
                }
            }
            return null;
        }

        @Override
        public TerminalType[] newArray(int size) {
            return new TerminalType[size];
        }
    };
}
