package com.trendit.basesdk.device.emv;


import java.util.List;

/**
 * <b>EmvDevice</b>Define the interface for the Emv operation.
 * <pre>
 * EmvDevice device = POSDeviceManager.getInstance().getEmvDevice();
 * </pre>
 * The caller cannot create the object through new
 */

public abstract class EMVDevice {

    /**
     * Set the Terminal Config,
     * It needs to be set before each transaction
     *
     * @param config {@link EMVTermConfig}
     * @return true : set success, false : set fail.
     */
    public abstract boolean setTermConfig(EMVTermConfig config);


    /**
     * Get the Terminal Config
     *
     * @return config {@link EMVTermConfig}
     */
    public abstract EMVTermConfig getTermConfig();


    /**
     * start emv process （This process without card search function）
     *
     * @param transData trans data {@link EMVTransData}
     * @param listener  emv process callback {@link EMVTransListener}
     */
    public abstract void process(EMVTransData transData, final EMVTransListener listener);


    /**
     * start emv process （This process includes card search function）
     *
     * @param transData         trans data {@link EMVTransData}
     * @param searchCardTimeout the timeout（millisecond） of search card.
     * @param listener          emv process callback {@link EMVTransListener}
     */
    public abstract void process(EMVTransData transData, int searchCardTimeout, final EMVTransListener listener);

    /**
     * EMV processing flow for contacting card second GAC
     *
     * @param transData trans data {@link EMVTransData}
     * @param listener  emv process callback {@link EMVTransListener}
     */
    public abstract void processSecondGAC(EMVTransData transData, final EMVTransListener listener);

    /**
     * Paywave issuer script processing flow
     *
     * @param transData trans data {@link EMVTransData}
     * @param listener  emv process callback {@link EMVTransListener}
     */
    public abstract void processPaywaveIUP(EMVTransData transData, final EMVTransListener listener);

    /**
     * Check if Contactless card need do second tap after online.(for example, paywave issuer
     * script process、discover dpas issuer script process and/or update card data、pure pay
     * online tap process)
     *
     * @return need or not
     */
    public abstract boolean isNeedSecondTap();

    /**
     * Contactless EMV processing flow for Second Tap Process Flow.(for example,
     * paywave issuer script process、discover dpas issuer script process and/or update card
     * data、pure pay online tap process)
     *
     * @param transData trans data {@link EMVTransData}
     * @param listener emv process callback {@link EMVTransListener}
     */
    public abstract void processSecondTap(EMVTransData transData, final EMVTransListener listener);

    /**
     * (Important) After completing the EMV-related processes, it is necessary to call this function.
     * Purpose 1: Close the respective card device (not closing it may affect the device's power consumption).
     * Purpose 2: Release the resources associated with EMV.
     */
    public abstract void processEnd();

    /**
     * Set relative data for contacting card second GAC or paywave IUP processing
     *
     * @param response receive online data
     * @return true : set success false :set fail
     */
    public abstract boolean setOnlineResponse(OnlineResponse response);

    /**
     * Get the icc card track info when emv processing
     *
     * @return icc card info {@link IccCardInfo}
     */
    public abstract IccCardInfo getIccCardInfo();

    /**
     * Get Script processing result
     *
     * @return Script result {@link ScriptResult}
     */
    public abstract ScriptResult getScriptResult();

    /**
     * Get processing TVR and TSI
     *
     * @return {@link TradeResult}
     */
    public abstract TradeResult getTradeResult();

    /**
     * set tlv to emv
     *
     * @param tag   tag
     * @param value value
     * @return success or fail
     */
    public abstract boolean setTLV(int tag, byte[] value);

    /**
     * Get TLV list data
     *
     * @param tags tags, samples:new int[]{0x57, 0x9F27, ......};
     * @return tlv list data
     */
    public abstract byte[] getTLVList(int[] tags);

    /**
     * Get TLV data
     *
     * @param tag tag
     * @return tlv
     */
    public abstract byte[] getTLV(int tag);

    /**
     * Query the balance for obtaining the corresponding cache after completing the EMV processing
     *
     * @param channelType {@link EMVTransData#Channel_Type_IC} : IC  {@link EMVTransData#Channel_Type_RF} : RF
     * @return balance
     */
    public abstract Balance queryECBalance(int channelType);

    /**
     * add aid before emv process (the aid will be saved to the terminal device)
     *
     * @param aid application identifier
     * @return true or false
     */
    public abstract boolean addAID(AID aid);

    /**
     * remove terminal aid
     *
     * @param aid application identifier
     * @return true or false
     */
    public abstract boolean removeAID(AID aid);

    /**
     * remove all terminal aid
     *
     * @return true or false
     */
    public abstract boolean removeAllAID();

    /**
     * get the terminal saved aid list
     *
     * @return list of application identifier
     */
    public abstract List<AID> getAID();

    /**
     * add the Public key parameters (the capk will be saved to the terminal device)
     *
     * @param capk Public key parameters
     * @return true or false
     */
    public abstract boolean addCAPK(CAPK capk);

    /**
     * remove the terminal capk
     *
     * @param capk Public key parameters
     * @return true or false
     */
    public abstract boolean removeCAPK(CAPK capk);

    /**
     * remove the all terminal capk
     *
     * @return true or false
     */
    public abstract boolean removeAllCAPK();

    /**
     * get the terminal saved capk list
     *
     * @return list of capk
     */
    public abstract List<CAPK> getCAPK();

    /**
     * Add a revoked issuer public key certification to revoked certification list.
     *
     * @param revoke revoked issuer public key certification
     * @return true or false
     */
    public abstract boolean addIPKRevoke(IPKRevoke revoke);

    /**
     * Delete a revoked issuer public key certification from revoked certification list.
     *
     * @param revoke revoked issuer public key certification
     * @return true or false
     */
    public abstract boolean removeIPKRevoke(IPKRevoke revoke);

    /**
     * Delete all revoked issuer public key certification from revoked certification list.
     *
     * @return true or false
     */
    public abstract boolean removeAllIPKRevoke();

    /**
     * Add a dynamic limit set to DRL list.
     *
     * @param limit dynamic limit
     * @return true or false
     */
    public abstract boolean addPaywareReaderLimit(PaywaveReaderLimit limit);

    /**
     * Delete a dynamic limit set from paywave DRL list.
     *
     * @param limit dynamic limit
     * @return true or false
     */
    public abstract boolean removePaywareReaderLimit(PaywaveReaderLimit limit);

    /**
     * Delete all dynamic limit set from paywave DRL list.
     *
     * @return true or false
     */
    public abstract boolean removeAllPaywareReaderLimit();


    /**
     * Express Pay Dynamic Reader Limits parameters init,If this function is call ,the kernel
     * will disable the ExpressPAY DRL support
     */
    public abstract void expressPayDRLReset();

    /**
     * If DRL need support,Pls call this function to enable the DRL support
     *
     * @param expressPayParam Dynamic Reader Limits parameters  {@link ExpressPayDRLParam}
     * @return true or false
     */
    public abstract boolean expressPaySetDefaultDRL(ExpressPayDRLParam expressPayParam);

    /**
     * If add sets of DRL need,Pls call this function to set, and Pls call
     * expressPaySetDefaultDRL function also to enable the DRL support.
     *
     * @param paramList DRL list {@link ExpressPayDRLParam}
     * @return true or false
     */
    public abstract boolean expressPaySetsDRLList(List<ExpressPayDRLParam> paramList);

    /**
     * Get Outcome Parameter Set Information
     *
     * @return Outcome Parameter Set Information {@link EntryPointOutcomeParam}
     */
    public abstract EntryPointOutcomeParam entryPointGetOutcome();

    /**
     * Get User Interface Request on Outcome Information
     *
     * @return User Interface Request Information {@link EntryPointUserInterfaceReqData}
     */
    public abstract EntryPointUserInterfaceReqData entryPointGetUIRequestOnOut();

    /**
     * Get User Interface Request on Restart Information
     *
     * @return User Interface Request Information {@link EntryPointUserInterfaceReqData}
     */
    public abstract EntryPointUserInterfaceReqData entryPointGetUIRequestOnRestart();

    /**
     * If Purepay requires a second tap, it is necessary to determine whether the transaction
     * is approved, rejected, or terminated based on the processing results of the pure kernel.
     * So after online response the app need get the purepay transaction result from kernel
     *
     * @return  {-1, When the emv does not perform the second tap process}
     * {@link EmvConstants#EMV_Result_TransOnlineApprove online approved}, {@link EmvConstants#EMV_Result_TransOnlineDeclineErr online declined}
     * {@link EmvConstants#EMV_Result_OfflineApprove offline approved}, {@link EmvConstants#EMV_Result_OfflineDecline offline declined}
     * {@link EmvConstants#EMV_Result_TransTerminateErr terminate}
     */
    public abstract int purePayGetSecondTapFlowTransResult();
}
