package com.trendit.basesdk.device.msr;

/**
 * magnetic card swipe callback
 */
public abstract class OnMSRCardHandlerListener {
    /**
     * The function is called back when there is a magnetic stripe card swiping or card searching error
     *
     * @param retCode swipe result {@link com.trendit.basesdk.card.CardConstants}
     * @param result  magnetic card info
     * @see MSRTrackData
     */
    public abstract void handleCardReaderResult(int retCode, MSRTrackData result);


}
