package com.trendit.basesdk.device.emv;

import android.os.Parcel;
import android.os.Parcelable;

public enum KernelID implements Parcelable {

    ICC_KERNEL_ID_0_EMV(0x00),

    ICC_KERNEL_ID_2_PAYPASS(0x02),

    ICC_KERNEL_ID_3_PAYWAVE(0x03),

    ICC_KERNEL_ID_4_AMEX(0x04),

    ICC_KERNEL_ID_5_JCB(0x05),

    ICC_KERNEL_ID_6_DISCOVER(0x06),

    ICC_KERNEL_ID_7_UNIONPAY(0x07),

    ICC_KERNEL_ID_9_PURE(0x09);
    private final int id;

    KernelID(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public static KernelID valueOf(int value) {
        KernelID[] kernelIDS = KernelID.values();
        for (KernelID kernelID : kernelIDS) {
            if (kernelID.getId() == value) {
                return kernelID;
            }
        }
        return null;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(ordinal());
    }

    public static final Parcelable.Creator<KernelID> CREATOR = new Parcelable.Creator<KernelID>() {
        @Override
        public KernelID createFromParcel(Parcel parcel) {
            int ordinal = parcel.readInt();
            for (KernelID kernelID : KernelID.values()) {
                if (kernelID.ordinal() == ordinal) {
                    return kernelID;
                }
            }
            return null;
        }

        @Override
        public KernelID[] newArray(int size) {
            return new KernelID[size];
        }
    };
}
