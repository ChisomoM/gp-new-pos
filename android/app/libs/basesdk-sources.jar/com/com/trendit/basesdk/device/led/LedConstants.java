package com.trendit.basesdk.device.led;

public class LedConstants {

    /**
     * red light
     */
    public static final int COLOR_RED = 1;

    /**
     * Yellow
     */
    public static final int COLOR_YELLOW = 2;

    /**
     * green light
     */
    public static final int COLOR_GREEN = 4;

    /**
     * blue light
     */
    public static final int COLOR_BLUE = 8;

    /**
     * all lights
     */
    public static final int COLOR_ALL = 15;

}
